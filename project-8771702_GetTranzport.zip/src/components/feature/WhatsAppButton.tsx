import { useState } from 'react';

export default function WhatsAppButton() {
  const [open, setOpen] = useState(false);

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-2">
      {/* Tooltip / expanded options */}
      {open && (
        <div className="bg-white border border-gray-100 rounded-2xl shadow-lg p-4 mb-2 w-64 animate-in fade-in slide-in-from-bottom-2 duration-200">
          <p className="text-xs font-semibold text-gray-700 mb-3">Chat with us on WhatsApp</p>
          <a
            href="https://wa.me/14313342841"
            target="_blank"
            rel="nofollow noopener"
            className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-semibold px-4 py-2.5 rounded-xl transition-colors cursor-pointer whitespace-nowrap w-full justify-center"
          >
            <i className="ri-whatsapp-line text-lg"></i>
            Start Chat
          </a>
          <p className="text-[10px] text-gray-400 mt-2 text-center">Avg response time: under 3 min</p>
        </div>
      )}

      {/* Main button */}
      <button
        onClick={() => setOpen(!open)}
        className="w-14 h-14 flex items-center justify-center bg-emerald-500 hover:bg-emerald-600 text-white rounded-full shadow-lg transition-all duration-200 cursor-pointer hover:scale-105"
        aria-label="Open WhatsApp chat"
      >
        <i className={`${open ? 'ri-close-line' : 'ri-whatsapp-line'} text-2xl`}></i>
      </button>
    </div>
  );
}