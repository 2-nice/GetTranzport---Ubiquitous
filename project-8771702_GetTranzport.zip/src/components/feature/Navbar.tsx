import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';

const NAV_LINKS = [
  { label: 'Services',         href: '/services' },
  { label: 'Pricing',          href: '/pricing' },
  { label: 'Destinations',     href: '/destinations' },
  { label: 'How It Works',     href: '/how-it-works' },
  { label: 'For Drivers',      href: '/for-drivers' },
  { label: 'For Business',     href: '/for-business' },
  { label: 'For Agents',       href: '/for-agents' },
  { label: 'Blog',             href: '/blog' },
  { label: 'Careers',          href: '/careers' },
  { label: 'Press',            href: '/press' },
  { label: 'FAQ',              href: '/faq' },
  { label: 'Support',          href: '/support' },
  { label: 'Contact',          href: '/contact' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-white border-b border-gray-200' : 'bg-transparent'}`}>

      {/* ── Top utility bar ── */}
      {!scrolled && (
        <div className="bg-black/50 backdrop-blur-md border-b border-white/10">
          <div className="max-w-7xl mx-auto px-6 h-9 flex items-center justify-between">
            <div className="flex items-center gap-6">
              {['City-to-City Rides', 'Airport Transfers', 'Cross-Border', 'State / Province'].map((s) => (
                <span key={s} className="text-white/70 text-xs hidden lg:block">{s}</span>
              ))}
            </div>
            <div className="flex items-center gap-4 text-xs text-white/70">
              <span className="flex items-center gap-1"><i className="ri-global-line text-emerald-400"></i>EN</span>
              <span className="flex items-center gap-1"><i className="ri-money-dollar-circle-line text-emerald-400"></i>USD</span>
              <Link to="/support" className="flex items-center gap-1 hover:text-white transition-colors">
                <i className="ri-customer-service-2-line text-emerald-400"></i>24/7 Support
              </Link>
            </div>
          </div>
        </div>
      )}

      {/* ── Main nav ── */}
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between h-14">

          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 flex-shrink-0">
            <img
              src="https://storage.readdy-site.link/project_files/2f77d222-cd48-4fcf-b09d-5b6904c3fbdd/57438424-a74c-47ae-9eda-4c633ac1fd05_GetTranzport-Official-logo.jpeg?v=54456dcff3e06ef19161c84429e27556"
              alt="GetTranzport"
              className="h-8 w-auto object-contain"
            />
          </Link>

          {/* Desktop nav links */}
          <nav className="hidden lg:flex items-center gap-5">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.label}
                to={link.href}
                className={`text-[13px] font-medium whitespace-nowrap transition-colors duration-200 hover:text-emerald-400 ${scrolled ? 'text-gray-600' : 'text-white/80'}`}
              >
                {link.label}
              </Link>
            ))}
          </nav>

          {/* Right CTA */}
          <div className="hidden md:flex items-center gap-3">
            <button
              onClick={() => navigate('/login')}
              className={`text-[13px] font-medium whitespace-nowrap cursor-pointer transition-colors ${scrolled ? 'text-gray-700 hover:text-gray-900' : 'text-white/85 hover:text-white'}`}
            >
              Log in
            </button>
            <button
              onClick={() => navigate('/signup')}
              className="bg-emerald-500 hover:bg-emerald-600 text-white text-[13px] font-semibold px-4 py-2 rounded-lg whitespace-nowrap transition-colors cursor-pointer"
            >
              Sign up free
            </button>
          </div>

          {/* Mobile burger */}
          <button
            className={`md:hidden w-9 h-9 flex items-center justify-center rounded-lg cursor-pointer ${scrolled ? 'text-gray-700' : 'text-white'}`}
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            <i className={`text-xl ${mobileOpen ? 'ri-close-line' : 'ri-menu-line'}`}></i>
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 px-6 py-4 flex flex-col gap-1">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.label}
              to={link.href}
              className="text-gray-700 text-sm py-2.5 border-b border-gray-50 hover:text-emerald-500 transition-colors font-medium"
              onClick={() => setMobileOpen(false)}
            >
              {link.label}
            </Link>
          ))}
          <div className="flex gap-3 pt-3">
            <Link to="/login" onClick={() => setMobileOpen(false)} className="flex-1 border border-gray-200 text-gray-700 text-sm font-medium py-2.5 rounded-lg cursor-pointer hover:border-emerald-300 transition-colors whitespace-nowrap text-center">Log in</Link>
            <Link to="/signup" onClick={() => setMobileOpen(false)} className="flex-1 bg-emerald-500 text-white text-sm font-semibold py-2.5 rounded-lg cursor-pointer hover:bg-emerald-600 transition-colors whitespace-nowrap text-center">Sign up free</Link>
          </div>
        </div>
      )}
    </header>
  );
}
