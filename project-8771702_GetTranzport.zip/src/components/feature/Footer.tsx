import { Link } from 'react-router-dom';

const SERVICES = [
  'Airport Transfer', 'City-to-City Rides', 'Cross-Border Transfer',
  'State / Province Rides', 'VIP Transfer', 'Group & Minibus', 'Delivery',
];
const SITEMAP = [
  { label: 'Support',          href: '/support' },
  { label: 'Pricing',          href: '/pricing' },
  { label: 'Our Destinations', href: '/destinations' },
  { label: 'How It Works',     href: '/how-it-works' },
  { label: 'For Drivers',      href: '/for-drivers' },
  { label: 'For Business',     href: '/for-business' },
  { label: 'For Agents',       href: '/for-agents' },
  { label: 'Blog',             href: '/blog' },
  { label: 'Careers',          href: '/careers' },
  { label: 'Press',            href: '/press' },
  { label: 'FAQ',              href: '/faq' },
  { label: 'Contact',          href: '/contact' },
  { label: 'Terms of Service', href: '/terms' },
  { label: 'Privacy Policy',   href: '/privacy' },
];

export default function Footer() {
  return (
    <footer className="bg-white border-t border-gray-100">
      <div className="max-w-6xl mx-auto px-6 pt-12 pb-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 mb-10">

          {/* Services */}
          <div>
            <h4 className="text-sm font-bold text-gray-900 mb-4">
              <Link to="/services" className="hover:text-emerald-500 transition-colors">Services</Link>
            </h4>
            <ul className="flex flex-col gap-2">
              {SERVICES.map((s) => (
                <li key={s}>
                  <Link to="/services" className="text-sm text-gray-500 hover:text-emerald-500 transition-colors">{s}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Sitemap */}
          <div>
            <h4 className="text-sm font-bold text-gray-900 mb-4">Sitemap</h4>
            <ul className="flex flex-col gap-2">
              {SITEMAP.map((l) => (
                <li key={l.label}>
                  <Link to={l.href} className="text-sm text-gray-500 hover:text-emerald-500 transition-colors">{l.label}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Address */}
          <div>
            <h4 className="text-sm font-bold text-gray-900 mb-4">Our Offices</h4>
            <div className="flex flex-col gap-4 text-sm text-gray-500 leading-relaxed">
              <div>
                <strong className="text-gray-700 font-semibold block text-xs mb-0.5">Headquarters — Canada</strong>
                GeTTranzport.com - Ubiquitous Ride<br />
                635 St. James Street,<br />Winnipeg, MB R3G 3R4, Canada
              </div>
              <div>
                <strong className="text-gray-700 font-semibold block text-xs mb-0.5">United Kingdom Office</strong>
                GeTTranzport.com - Ubiquitous Ride<br />
                One Canada Square, Canary Wharf,<br />London, E14 5AB, United Kingdom
              </div>
              <div>
                <strong className="text-gray-700 font-semibold block text-xs mb-0.5">United States Office</strong>
                GeTTranzport.com - Ubiquitous Ride<br />
                350 Fifth Avenue, Suite 4100,<br />New York, NY 10118, USA
              </div>
              <div>
                <strong className="text-gray-700 font-semibold block text-xs mb-0.5">Africa Office — Nigeria</strong>
                GeTTranzport.com - Ubiquitous Ride<br />
                Plot 1, Adeola Odeku Street,<br />Victoria Island, Lagos, Nigeria
              </div>
            </div>
          </div>

          {/* App + Social */}
          <div>
            <h4 className="text-sm font-bold text-gray-900 mb-4">Get The App</h4>
            <div className="flex flex-col gap-2 mb-6">
              {[
                { icon: 'ri-apple-line', top: 'Download on the', bottom: 'App Store' },
                { icon: 'ri-google-play-line', top: 'Get it on', bottom: 'Google Play' },
              ].map((btn) => (
                <a
                  key={btn.bottom}
                  href="https://gettransfer.onelink.me/swC4/f0209212"
                  target="_blank"
                  rel="nofollow noopener"
                  className="flex items-center gap-2.5 bg-gray-900 text-white px-4 py-2.5 rounded-xl text-xs font-medium hover:bg-gray-800 transition-colors cursor-pointer w-fit"
                >
                  <i className={`${btn.icon} text-base`}></i>
                  <div>
                    <div className="text-gray-400 text-[10px] leading-none">{btn.top}</div>
                    <div className="font-bold text-xs leading-tight">{btn.bottom}</div>
                  </div>
                </a>
              ))}
            </div>

            <div className="flex items-center gap-2">
              {[
                { icon: 'ri-twitter-x-line', href: 'https://twitter.com' },
                { icon: 'ri-facebook-line',  href: 'https://facebook.com' },
                { icon: 'ri-instagram-line', href: 'https://instagram.com' },
                { icon: 'ri-linkedin-line',  href: 'https://linkedin.com' },
              ].map((s) => (
                <a
                  key={s.icon}
                  href={s.href}
                  target="_blank"
                  rel="nofollow noopener"
                  className="w-8 h-8 flex items-center justify-center rounded-lg border border-gray-200 text-gray-500 hover:text-emerald-500 hover:border-emerald-300 transition-colors cursor-pointer"
                >
                  <i className={`${s.icon} text-sm`}></i>
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-gray-100 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <img
              src="https://storage.readdy-site.link/project_files/2f77d222-cd48-4fcf-b09d-5b6904c3fbdd/57438424-a74c-47ae-9eda-4c633ac1fd05_GetTranzport-Official-logo.jpeg?v=54456dcff3e06ef19161c84429e27556"
              alt="GetTranzport"
              className="h-5 w-auto object-contain"
            />
            <span className="text-gray-200">|</span>
            <img
              src="https://storage.readdy-site.link/project_files/2f77d222-cd48-4fcf-b09d-5b6904c3fbdd/3a98e49d-9b57-45a3-96ca-4e955260d506_2nice-Logo.jpg?v=08585cd6ed3ffd5ef7004483e839bded"
              alt="2-Nice Rideshare & Carpooling Transport Services Inc."
              className="h-5 w-auto object-contain"
            />
            <span className="text-xs text-gray-400">© 2026 2-Nice Rideshare &amp; Carpooling Transport Services Inc. All rights reserved. GetTranzport® is a registered trademark.</span>
          </div>
          <div className="flex items-center gap-4">
            {[
              { label: 'Terms', href: '/terms' },
              { label: 'Privacy', href: '/privacy' },
              { label: 'Support', href: '/support' },
            ].map((l) => (
              <Link key={l.label} to={l.href} className="text-xs text-gray-400 hover:text-emerald-500 transition-colors whitespace-nowrap">{l.label}</Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
