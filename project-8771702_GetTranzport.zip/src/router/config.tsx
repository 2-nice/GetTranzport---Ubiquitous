import type { RouteObject } from "react-router-dom";
import NotFound from "../pages/NotFound";
import Home from "../pages/home/page";
import ServicesPage from "../pages/services/page";
import HowItWorksPage from "../pages/how-it-works/page";
import ForDriversPage from "../pages/for-drivers/page";
import ForBusinessPage from "../pages/for-business/page";
import FAQPage from "../pages/faq/page";
import DestinationsPage from "../pages/destinations/page";
import SupportPage from "../pages/support/page";
import ForAgentsPage from "../pages/for-agents/page";
import BlogPage from "../pages/blog/page";
import TermsPage from "../pages/terms/page";
import PrivacyPage from "../pages/privacy/page";
import LoginPage from "../pages/login/page";
import SignupPage from "../pages/signup/page";
import BookPage from "../pages/book/page";
import ContactPage from "../pages/contact/page";
import CareersPage from "../pages/careers/page";
import PressPage from "../pages/press/page";
import PricingPage from "../pages/pricing/page";

const routes: RouteObject[] = [
  { path: "/",             element: <Home /> },
  { path: "/services",     element: <ServicesPage /> },
  { path: "/how-it-works", element: <HowItWorksPage /> },
  { path: "/for-drivers",  element: <ForDriversPage /> },
  { path: "/for-business", element: <ForBusinessPage /> },
  { path: "/for-agents",   element: <ForAgentsPage /> },
  { path: "/faq",          element: <FAQPage /> },
  { path: "/destinations", element: <DestinationsPage /> },
  { path: "/support",      element: <SupportPage /> },
  { path: "/blog",         element: <BlogPage /> },
  { path: "/terms",        element: <TermsPage /> },
  { path: "/privacy",      element: <PrivacyPage /> },
  { path: "/login",        element: <LoginPage /> },
  { path: "/signup",       element: <SignupPage /> },
  { path: "/book",         element: <BookPage /> },
  { path: "/contact",      element: <ContactPage /> },
  { path: "/careers",      element: <CareersPage /> },
  { path: "/press",        element: <PressPage /> },
  { path: "/pricing",      element: <PricingPage /> },
  { path: "*",             element: <NotFound /> },
];

export default routes;
