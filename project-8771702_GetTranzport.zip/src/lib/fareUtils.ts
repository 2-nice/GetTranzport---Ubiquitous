export type VehicleClass =
  | 'economy'
  | 'comfort'
  | 'business'
  | 'premium'
  | 'vip'
  | 'suv'
  | 'van'
  | 'minibus'
  | 'bus'
  | 'delivery';

export interface FareRange {
  id: number;
  continent: string;
  country: string;
  currency: string;
  economy_min: number;
  economy_max: number;
  comfort_min: number;
  comfort_max: number;
  business_min: number;
  business_max: number;
  premium_min: number;
  premium_max: number;
  vip_min: number;
  vip_max: number;
  suv_min: number;
  suv_max: number;
  van_min: number;
  van_max: number;
  minibus_min: number;
  minibus_max: number;
  bus_min: number;
  bus_max: number;
  delivery_min: number;
  delivery_max: number;
}

export interface FareBand {
  color: 'red-low' | 'green' | 'blue' | 'yellow' | 'light-red' | 'red-high';
  label: string;
  message: string;
  position: number;
}

export const VEHICLE_CLASSES: { key: VehicleClass; label: string; icon: string; pax: string }[] = [
  { key: 'economy',  label: 'Economy',  icon: 'ri-car-line',           pax: 'Up to 3' },
  { key: 'comfort',  label: 'Comfort',  icon: 'ri-car-washing-line',   pax: 'Up to 3' },
  { key: 'business', label: 'Business', icon: 'ri-car-fill',           pax: 'Up to 3' },
  { key: 'premium',  label: 'Premium',  icon: 'ri-vip-crown-line',     pax: 'Up to 3' },
  { key: 'vip',      label: 'VIP',      icon: 'ri-vip-diamond-line',   pax: 'Up to 3' },
  { key: 'suv',      label: 'SUV',      icon: 'ri-truck-line',         pax: 'Up to 5' },
  { key: 'van',      label: 'Van',      icon: 'ri-bus-line',           pax: 'Up to 8' },
  { key: 'minibus',  label: 'Minibus',  icon: 'ri-bus-2-line',         pax: 'Up to 16' },
  { key: 'bus',      label: 'Bus',      icon: 'ri-bus-fill',           pax: 'Up to 50' },
  { key: 'delivery', label: 'Delivery', icon: 'ri-e-bike-2-line',      pax: 'Cargo' },
];

export function getMinMax(row: FareRange, vehicle: VehicleClass): { min: number; max: number } {
  return {
    min: row[`${vehicle}_min`] as number,
    max: row[`${vehicle}_max`] as number,
  };
}

export function getFareBand(fare: number, L: number): FareBand {
  const D = 0.90;
  if (fare < L) {
    return { color: 'red-low', label: 'Too Low', message: 'Too low fare - enter a realistic fare', position: 0 };
  }
  const position = (fare - L) / D;
  if (position <= 0.2) {
    return { color: 'green',     label: 'Excellent',  message: 'Excellent fare - high chances',       position };
  }
  if (position <= 0.4) {
    return { color: 'blue',      label: 'Good',       message: 'Good fare - medium chances',          position };
  }
  if (position <= 0.6) {
    return { color: 'yellow',    label: 'Fair',       message: 'Fair fare - moderate chances',        position };
  }
  if (position <= 0.8) {
    return { color: 'light-red', label: 'High',       message: 'High fare - low chances',             position };
  }
  return { color: 'red-high',  label: 'Very High',  message: 'Very high fare - very low chances',   position };
}

export const BAND_STYLES: Record<FareBand['color'], { bg: string; text: string; bar: string; border: string }> = {
  'red-low':   { bg: 'bg-red-50',       text: 'text-red-600',       bar: 'bg-red-500',       border: 'border-red-200' },
  'green':     { bg: 'bg-emerald-50',   text: 'text-emerald-600',   bar: 'bg-emerald-500',   border: 'border-emerald-200' },
  'blue':      { bg: 'bg-sky-50',       text: 'text-sky-600',       bar: 'bg-sky-500',       border: 'border-sky-200' },
  'yellow':    { bg: 'bg-yellow-50',    text: 'text-yellow-600',    bar: 'bg-yellow-400',    border: 'border-yellow-200' },
  'light-red': { bg: 'bg-orange-50',    text: 'text-orange-600',    bar: 'bg-orange-400',    border: 'border-orange-200' },
  'red-high':  { bg: 'bg-red-50',       text: 'text-red-600',       bar: 'bg-red-500',       border: 'border-red-200' },
};
