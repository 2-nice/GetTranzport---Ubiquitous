import { useState } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '@/components/feature/Navbar';

type AccountType = 'passenger' | 'driver' | 'business';

export default function SignupPage() {
  const [accountType, setAccountType] = useState<AccountType>('passenger');
  const [step, setStep] = useState(1);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  const [form, setForm] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    password: '',
    company: '',
    country: '',
  });

  const update = (field: string, value: string) => setForm((f) => ({ ...f, [field]: value }));

  const handleNext = (e: React.FormEvent) => {
    e.preventDefault();
    if (step === 1) { setStep(2); return; }
    setLoading(true);
    setTimeout(() => { setLoading(false); setDone(true); }, 1400);
  };

  const ACCOUNT_TYPES: { id: AccountType; icon: string; label: string; desc: string }[] = [
    { id: 'passenger', icon: 'ri-user-line', label: 'Passenger', desc: 'Book private transfers worldwide' },
    { id: 'driver', icon: 'ri-steering-2-line', label: 'Driver', desc: 'Earn by offering transfer services' },
    { id: 'business', icon: 'ri-building-line', label: 'Business', desc: 'Manage corporate travel bookings' },
  ];

  if (done) {
    return (
      <div className="min-h-screen flex flex-col bg-white" style={{ fontFamily: 'Inter, sans-serif' }}>
        <Navbar />
        <div className="flex-1 flex items-center justify-center px-4 py-24">
          <div className="text-center max-w-sm">
            <div className="w-16 h-16 flex items-center justify-center bg-emerald-100 rounded-full mx-auto mb-5">
              <i className="ri-checkbox-circle-fill text-emerald-500 text-3xl"></i>
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>Account Created!</h2>
            <p className="text-gray-500 text-sm mb-6">Welcome to GetTranzport. Check your email to verify your account and start booking.</p>
            <Link
              to="/"
              className="inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white font-bold px-7 py-3 rounded-xl text-sm transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-home-line"></i>
              Go to Homepage
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-white" style={{ fontFamily: 'Inter, sans-serif' }}>
      <Navbar />

      <div className="flex-1 flex items-center justify-center px-4 py-24">
        <div className="w-full max-w-md">

          {/* Logo */}
          <div className="text-center mb-8">
            <Link to="/" className="inline-flex items-center gap-2 mb-6">
              <img
                src="https://storage.readdy-site.link/project_files/2f77d222-cd48-4fcf-b09d-5b6904c3fbdd/57438424-a74c-47ae-9eda-4c633ac1fd05_GetTranzport-Official-logo.jpeg?v=54456dcff3e06ef19161c84429e27556"
                alt="GetTranzport"
                className="h-10 w-auto object-contain"
              />
            </Link>
            <h1 className="text-2xl font-bold text-gray-900 mb-1" style={{ fontFamily: 'Syne, sans-serif' }}>Create your account</h1>
            <p className="text-gray-500 text-sm">Join 2.4 million passengers worldwide</p>
          </div>

          {/* Step indicator */}
          <div className="flex items-center gap-2 mb-7">
            {[1, 2].map((s) => (
              <div key={s} className="flex items-center gap-2 flex-1">
                <div className={`w-7 h-7 flex items-center justify-center rounded-full text-xs font-bold flex-shrink-0 ${step >= s ? 'bg-emerald-500 text-white' : 'bg-gray-100 text-gray-400'}`}>
                  {step > s ? <i className="ri-check-line text-xs"></i> : s}
                </div>
                <span className={`text-xs ${step >= s ? 'text-gray-700 font-medium' : 'text-gray-400'}`}>
                  {s === 1 ? 'Account Type' : 'Your Details'}
                </span>
                {s < 2 && <div className={`flex-1 h-px ${step > s ? 'bg-emerald-300' : 'bg-gray-100'}`}></div>}
              </div>
            ))}
          </div>

          <form onSubmit={handleNext} className="flex flex-col gap-4">
            {step === 1 && (
              <>
                <p className="text-sm font-semibold text-gray-700 mb-1">I want to join as a...</p>
                <div className="flex flex-col gap-3">
                  {ACCOUNT_TYPES.map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setAccountType(t.id)}
                      className={`flex items-center gap-4 border-2 rounded-xl p-4 text-left transition-all cursor-pointer ${
                        accountType === t.id
                          ? 'border-emerald-500 bg-emerald-50'
                          : 'border-gray-100 hover:border-gray-300'
                      }`}
                    >
                      <div className={`w-10 h-10 flex items-center justify-center rounded-xl flex-shrink-0 ${accountType === t.id ? 'bg-emerald-500' : 'bg-gray-100'}`}>
                        <i className={`${t.icon} text-lg ${accountType === t.id ? 'text-white' : 'text-gray-500'}`}></i>
                      </div>
                      <div>
                        <div className="text-sm font-bold text-gray-900">{t.label}</div>
                        <div className="text-xs text-gray-500">{t.desc}</div>
                      </div>
                      {accountType === t.id && (
                        <i className="ri-checkbox-circle-fill text-emerald-500 text-lg ml-auto"></i>
                      )}
                    </button>
                  ))}
                </div>
                <button
                  type="submit"
                  className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-3.5 rounded-xl text-sm transition-colors cursor-pointer whitespace-nowrap mt-2"
                >
                  Continue
                </button>
              </>
            )}

            {step === 2 && (
              <>
                {/* Social */}
                <div className="flex flex-col gap-3 mb-2">
                  <button type="button" className="w-full flex items-center justify-center gap-3 border border-gray-200 rounded-xl py-3 text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap">
                    <i className="ri-google-line text-base text-red-500"></i>
                    Continue with Google
                  </button>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex-1 h-px bg-gray-100"></div>
                  <span className="text-xs text-gray-400">or fill in details</span>
                  <div className="flex-1 h-px bg-gray-100"></div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1.5">First Name</label>
                    <input type="text" required value={form.firstName} onChange={(e) => update('firstName', e.target.value)} placeholder="John" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition" />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1.5">Last Name</label>
                    <input type="text" required value={form.lastName} onChange={(e) => update('lastName', e.target.value)} placeholder="Doe" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition" />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">Email Address</label>
                  <input type="email" required value={form.email} onChange={(e) => update('email', e.target.value)} placeholder="john@example.com" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition" />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">Phone Number</label>
                  <input type="tel" required value={form.phone} onChange={(e) => update('phone', e.target.value)} placeholder="+1 431-334-2841" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition" />
                </div>

                {accountType === 'business' && (
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1.5">Company Name</label>
                    <input type="text" required value={form.company} onChange={(e) => update('company', e.target.value)} placeholder="Acme Corp" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition" />
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">Password</label>
                  <div className="relative">
                    <input type={showPassword ? 'text' : 'password'} required value={form.password} onChange={(e) => update('password', e.target.value)} placeholder="Min. 8 characters" className="w-full border border-gray-200 rounded-xl px-4 py-3 pr-11 text-sm focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition" />
                    <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 cursor-pointer">
                      <i className={`${showPassword ? 'ri-eye-off-line' : 'ri-eye-line'} text-base`}></i>
                    </button>
                  </div>
                </div>

                <p className="text-xs text-gray-400">
                  By signing up, you agree to our{' '}
                  <Link to="/terms" className="text-emerald-500 hover:underline">Terms of Service</Link>
                  {' '}and{' '}
                  <Link to="/privacy" className="text-emerald-500 hover:underline">Privacy Policy</Link>.
                </p>

                <div className="flex gap-3">
                  <button type="button" onClick={() => setStep(1)} className="flex-1 border border-gray-200 text-gray-700 font-semibold py-3.5 rounded-xl text-sm hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap">
                    Back
                  </button>
                  <button type="submit" disabled={loading} className="flex-1 bg-emerald-500 hover:bg-emerald-600 disabled:bg-emerald-300 text-white font-bold py-3.5 rounded-xl text-sm transition-colors cursor-pointer whitespace-nowrap flex items-center justify-center gap-2">
                    {loading ? <><i className="ri-loader-4-line animate-spin"></i> Creating...</> : 'Create Account'}
                  </button>
                </div>
              </>
            )}
          </form>

          <p className="text-center text-xs text-gray-500 mt-6">
            Already have an account?{' '}
            <Link to="/login" className="text-emerald-500 font-semibold hover:text-emerald-600 transition-colors">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
