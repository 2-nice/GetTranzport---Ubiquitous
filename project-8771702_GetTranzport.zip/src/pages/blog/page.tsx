import { useState } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';

const CATEGORIES = ['All', 'Travel Tips', 'Industry News', 'Driver Stories', 'Destinations', 'Safety'];

const POSTS = [
  {
    id: 1,
    category: 'Travel Tips',
    title: '10 Things to Know Before Your First Cross-Border Transfer',
    excerpt: 'From visa requirements to border wait times — here\'s everything first-time cross-border passengers need to know before booking.',
    author: 'Sarah Mitchell',
    date: 'Apr 18, 2026',
    readTime: '6 min read',
    img: 'https://readdy.ai/api/search-image?query=passport%20and%20travel%20documents%20on%20a%20clean%20white%20desk%20with%20a%20car%20key%2C%20travel%20planning%20concept%2C%20minimalist%20photography%2C%20soft%20natural%20lighting&width=600&height=380&seq=blog-1&orientation=landscape',
    featured: true,
  },
  {
    id: 2,
    category: 'Industry News',
    title: 'GetTranzport Expands to 12 New African Markets in 2026',
    excerpt: 'We\'re thrilled to announce our expansion into 12 new African countries, bringing verified long-distance transfers to millions of new passengers.',
    author: 'GetTranzport Team',
    date: 'Apr 12, 2026',
    readTime: '4 min read',
    img: 'https://readdy.ai/api/search-image?query=Africa%20map%20with%20glowing%20city%20connection%20points%2C%20modern%20digital%20visualization%2C%20dark%20background%20with%20emerald%20green%20highlights%2C%20technology%20concept&width=600&height=380&seq=blog-2&orientation=landscape',
    featured: true,
  },
  {
    id: 3,
    category: 'Driver Stories',
    title: 'Meet Emmanuel: 8 Years, 14 Countries, 4,000+ Trips',
    excerpt: 'Emmanuel Osei has been a GetTranzport driver since 2018. We sat down with him to hear about his most memorable journeys across West Africa.',
    author: 'James Okafor',
    date: 'Apr 8, 2026',
    readTime: '8 min read',
    img: 'https://readdy.ai/api/search-image?query=professional%20driver%20in%20smart%20uniform%20standing%20next%20to%20a%20clean%20black%20luxury%20sedan%2C%20confident%20smile%2C%20African%20setting%2C%20golden%20hour%20lighting&width=600&height=380&seq=blog-3&orientation=landscape',
    featured: false,
  },
  {
    id: 4,
    category: 'Destinations',
    title: 'The Ultimate Guide to London–Manchester by Private Transfer',
    excerpt: 'Everything you need to know about the UK\'s most popular intercity route — best departure times, stops, and what to expect.',
    author: 'Priya Sharma',
    date: 'Apr 3, 2026',
    readTime: '5 min read',
    img: 'https://readdy.ai/api/search-image?query=aerial%20view%20of%20English%20motorway%20with%20cars%20at%20sunset%2C%20UK%20countryside%2C%20golden%20light%2C%20travel%20photography%2C%20cinematic%20wide%20shot&width=600&height=380&seq=blog-4&orientation=landscape',
    featured: false,
  },
  {
    id: 5,
    category: 'Safety',
    title: 'How GetTranzport\'s SafeGuard™ System Keeps You Safe on Every Trip',
    excerpt: 'A deep dive into the 3-layer safety verification system that every GetTranzport driver must pass before their first booking.',
    author: 'GetTranzport Safety Team',
    date: 'Mar 28, 2026',
    readTime: '7 min read',
    img: 'https://readdy.ai/api/search-image?query=security%20shield%20icon%20with%20checkmarks%20on%20a%20clean%20modern%20interface%2C%20safety%20technology%20concept%2C%20emerald%20green%20and%20white%20color%20scheme%2C%20professional%20design&width=600&height=380&seq=blog-5&orientation=landscape',
    featured: false,
  },
  {
    id: 6,
    category: 'Travel Tips',
    title: 'Airport Transfer vs. Taxi: Why Private Always Wins',
    excerpt: 'We break down the real cost comparison between airport taxis, rideshares, and GetTranzport private transfers — the numbers might surprise you.',
    author: 'David Chen',
    date: 'Mar 22, 2026',
    readTime: '5 min read',
    img: 'https://readdy.ai/api/search-image?query=modern%20international%20airport%20terminal%20with%20passengers%20and%20luxury%20car%20waiting%20outside%2C%20clean%20architecture%2C%20bright%20natural%20lighting%2C%20travel%20concept&width=600&height=380&seq=blog-6&orientation=landscape',
    featured: false,
  },
];

const CATEGORY_COLORS: Record<string, string> = {
  'Travel Tips': 'bg-emerald-100 text-emerald-700',
  'Industry News': 'bg-sky-100 text-sky-700',
  'Driver Stories': 'bg-amber-100 text-amber-700',
  'Destinations': 'bg-rose-100 text-rose-700',
  'Safety': 'bg-violet-100 text-violet-700',
};

export default function BlogPage() {
  const [activeCategory, setActiveCategory] = useState('All');

  const filtered = activeCategory === 'All'
    ? POSTS
    : POSTS.filter((p) => p.category === activeCategory);

  const featured = POSTS.filter((p) => p.featured);
  const rest = filtered.filter((p) => !p.featured);

  return (
    <div className="min-h-screen flex flex-col bg-white" style={{ fontFamily: 'Inter, sans-serif' }}>
      <Navbar />

      {/* Hero */}
      <section className="pt-28 pb-12 bg-gray-900 text-center">
        <div className="max-w-2xl mx-auto px-6">
          <h1 className="text-4xl font-extrabold text-white mb-3" style={{ fontFamily: 'Syne, sans-serif' }}>
            GetTranzport Journal
          </h1>
          <p className="text-white/60 text-sm">
            Travel tips, industry news, driver stories and destination guides from the GetTranzport team.
          </p>
        </div>
      </section>

      {/* Featured Posts */}
      {activeCategory === 'All' && (
        <section className="py-12 bg-white">
          <div className="max-w-6xl mx-auto px-6">
            <h2 className="text-lg font-bold text-gray-900 mb-6" style={{ fontFamily: 'Syne, sans-serif' }}>Featured</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {featured.map((post) => (
                <article key={post.id} className="group border border-gray-100 rounded-2xl overflow-hidden hover:border-emerald-200 transition-all duration-200 cursor-pointer">
                  <div className="w-full h-52 overflow-hidden">
                    <img src={post.img} alt={post.title} className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-300" />
                  </div>
                  <div className="p-6">
                    <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${CATEGORY_COLORS[post.category] || 'bg-gray-100 text-gray-600'}`}>
                      {post.category}
                    </span>
                    <h3 className="text-base font-bold text-gray-900 mt-3 mb-2 leading-snug group-hover:text-emerald-600 transition-colors">{post.title}</h3>
                    <p className="text-xs text-gray-500 leading-relaxed mb-4">{post.excerpt}</p>
                    <div className="flex items-center justify-between text-xs text-gray-400">
                      <span>{post.author}</span>
                      <span>{post.date} · {post.readTime}</span>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Category Filter + All Posts */}
      <section className="py-12 bg-gray-50/60">
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex flex-wrap gap-2 mb-8">
            {CATEGORIES.map((c) => (
              <button
                key={c}
                onClick={() => setActiveCategory(c)}
                className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap cursor-pointer transition-all ${
                  activeCategory === c
                    ? 'bg-gray-900 text-white'
                    : 'bg-white border border-gray-200 text-gray-600 hover:border-gray-400'
                }`}
              >
                {c}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {(activeCategory === 'All' ? rest : filtered).map((post) => (
              <article key={post.id} className="group bg-white border border-gray-100 rounded-2xl overflow-hidden hover:border-emerald-200 transition-all duration-200 cursor-pointer">
                <div className="w-full h-44 overflow-hidden">
                  <img src={post.img} alt={post.title} className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-300" />
                </div>
                <div className="p-5">
                  <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${CATEGORY_COLORS[post.category] || 'bg-gray-100 text-gray-600'}`}>
                    {post.category}
                  </span>
                  <h3 className="text-sm font-bold text-gray-900 mt-3 mb-2 leading-snug group-hover:text-emerald-600 transition-colors">{post.title}</h3>
                  <p className="text-xs text-gray-500 leading-relaxed mb-4 line-clamp-2">{post.excerpt}</p>
                  <div className="flex items-center justify-between text-xs text-gray-400">
                    <span>{post.author}</span>
                    <span>{post.readTime}</span>
                  </div>
                </div>
              </article>
            ))}
          </div>

          {filtered.length === 0 && (
            <div className="text-center py-16 text-gray-400">
              <i className="ri-article-line text-4xl mb-3 block"></i>
              <p className="text-sm">No posts in this category yet.</p>
            </div>
          )}
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-14 bg-emerald-500">
        <div className="max-w-xl mx-auto px-6 text-center">
          <h2 className="text-2xl font-bold text-white mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>Stay in the Loop</h2>
          <p className="text-white/80 text-sm mb-6">Get travel tips, destination guides and platform updates delivered to your inbox.</p>
          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="email"
              placeholder="Enter your email address"
              className="flex-1 px-4 py-3 rounded-xl text-sm text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-white/50"
            />
            <button className="bg-gray-900 hover:bg-gray-800 text-white font-bold px-6 py-3 rounded-xl text-sm transition-colors cursor-pointer whitespace-nowrap">
              Subscribe
            </button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
