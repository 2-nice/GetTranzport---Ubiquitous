import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';
import { useState } from 'react';

const CATEGORIES = [
  {
    label: 'Booking',
    icon: 'ri-calendar-check-line',
    faqs: [
      { q: 'How do I book a ride on GetTranzport?', a: 'Enter your pickup location, destination, travel date, and number of passengers on the homepage. You\'ll receive competitive offers from verified drivers. Choose the best offer, pay securely, and you\'re confirmed.' },
      { q: 'Can I book a return trip?', a: 'Yes! When entering your trip details, click "Add return date" to book a round trip. You can book both legs with the same driver or choose different drivers for each direction.' },
      { q: 'How far in advance can I book?', a: 'You can book up to 12 months in advance. For same-day bookings, we recommend booking at least 2 hours before your desired pickup time to allow drivers to respond.' },
      { q: 'Can I book for someone else?', a: 'Absolutely. During checkout, you can enter the passenger\'s name and contact details. The driver will be briefed on who to expect at pickup.' },
    ],
  },
  {
    label: 'Pricing',
    icon: 'ri-price-tag-3-line',
    faqs: [
      { q: 'How does GetTranzport\'s pricing work?', a: 'GetTranzport uses a tender-based pricing model. You post your trip and verified drivers submit competitive bids. You choose the best combination of price, rating, and vehicle class. The price you agree to is the price you pay — no surge pricing, no hidden fees.' },
      { q: 'Are there any additional fees?', a: 'The price shown includes the driver\'s fee and GetTranzport\'s service fee. There are no hidden charges. Tolls, parking, and border fees may apply on some routes and will be disclosed upfront.' },
      { q: 'What currencies are accepted?', a: 'We accept payments in 80+ currencies. Your card will be charged in your local currency at the current exchange rate. We support credit/debit cards, PayPal, Apple Pay, and Google Pay.' },
    ],
  },
  {
    label: 'Cancellation',
    icon: 'ri-refund-2-line',
    faqs: [
      { q: 'What is the cancellation policy?', a: 'You can cancel for free up to 24 hours before your scheduled pickup. Cancellations within 24 hours may incur a fee of up to 50% of the trip cost. If the driver cancels, you receive a full refund.' },
      { q: 'What if my flight is delayed?', a: 'For airport pickups, your driver monitors your flight in real time and adjusts their arrival accordingly. Up to 60 minutes of free waiting time is included. If your delay exceeds 60 minutes, contact support to reschedule at no extra charge.' },
      { q: 'How do I get a refund?', a: 'Refunds are processed within 3–5 business days to your original payment method. For eligible cancellations, the full amount is returned. Partial refunds for late cancellations are processed within 7 days.' },
    ],
  },
  {
    label: 'Safety',
    icon: 'ri-shield-check-line',
    faqs: [
      { q: 'How are drivers verified?', a: 'Every driver on GetTranzport undergoes criminal background screening, driving licence verification, vehicle roadworthiness inspection, and identity verification before being approved. Drivers are re-screened annually.' },
      { q: 'What is SafeGuard™?', a: 'SafeGuard™ is GetTranzport\'s multi-layer safety system. It includes driver face-match verification at pickup, real-time GPS trip monitoring, in-app panic button with emergency response, and automatic trip recording.' },
      { q: 'Can I share my trip with someone?', a: 'Yes. Once your trip starts, you can generate a shareable live tracking link from the app. Anyone with the link can follow your journey in real time — no app download required.' },
    ],
  },
  {
    label: 'Drivers',
    icon: 'ri-steering-2-line',
    faqs: [
      { q: 'How do I become a GetTranzport driver?', a: 'Visit our For Drivers page and fill in the application form. You\'ll need a valid driving licence, vehicle registration, insurance, and to pass our background check. Approval typically takes 24 hours.' },
      { q: 'How do drivers get paid?', a: 'Earnings are transferred to your registered bank account within 24 hours of trip completion. There are no weekly or monthly payout delays.' },
      { q: 'Can I drive in multiple countries?', a: 'Yes, if you hold the appropriate licences and documentation for each country. GetTranzport supports multi-country driver profiles for cross-border specialists.' },
    ],
  },
];

function FAQItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border-b border-gray-100 last:border-0">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between gap-4 py-4 text-left cursor-pointer group"
      >
        <span className="text-sm font-semibold text-gray-900 group-hover:text-emerald-600 transition-colors">{q}</span>
        <i className={`ri-${open ? 'subtract' : 'add'}-line text-gray-400 text-lg flex-shrink-0 transition-transform duration-200`}></i>
      </button>
      {open && (
        <div className="pb-4 pr-8">
          <p className="text-sm text-gray-500 leading-relaxed">{a}</p>
        </div>
      )}
    </div>
  );
}

export default function FAQPage() {
  const [activeCategory, setActiveCategory] = useState('Booking');

  const current = CATEGORIES.find((c) => c.label === activeCategory)!;

  return (
    <div className="min-h-screen flex flex-col bg-white" style={{ fontFamily: 'Inter, sans-serif' }}>
      <Navbar />

      {/* Hero */}
      <section className="pt-32 pb-16 bg-gray-950 text-center px-6">
        <span className="text-emerald-400 text-xs font-bold tracking-widest uppercase">Help Centre</span>
        <h1 className="text-4xl md:text-5xl font-extrabold text-white mt-3 mb-4" style={{ fontFamily: 'Syne, sans-serif' }}>
          Frequently Asked Questions
        </h1>
        <p className="text-gray-400 text-base max-w-xl mx-auto">
          Everything you need to know about booking, pricing, safety, and driving with GetTranzport.
        </p>
      </section>

      {/* FAQ */}
      <main className="flex-1 py-16 px-6">
        <div className="max-w-4xl mx-auto">
          {/* Category tabs */}
          <div className="flex flex-wrap gap-2 mb-10 justify-center">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.label}
                onClick={() => setActiveCategory(cat.label)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold whitespace-nowrap transition-all duration-200 cursor-pointer border ${
                  activeCategory === cat.label
                    ? 'bg-emerald-500 text-white border-emerald-500'
                    : 'bg-white text-gray-600 border-gray-200 hover:border-emerald-300 hover:text-emerald-600'
                }`}
              >
                <i className={`${cat.icon} text-base`}></i>
                {cat.label}
              </button>
            ))}
          </div>

          {/* FAQ list */}
          <div className="bg-white rounded-2xl border border-gray-100 px-6 py-2">
            {current.faqs.map((faq) => (
              <FAQItem key={faq.q} q={faq.q} a={faq.a} />
            ))}
          </div>

          {/* Still need help */}
          <div className="mt-10 bg-gray-50 rounded-2xl border border-gray-100 p-8 text-center">
            <div className="w-12 h-12 flex items-center justify-center rounded-full bg-emerald-100 mx-auto mb-4">
              <i className="ri-customer-service-2-line text-emerald-500 text-xl"></i>
            </div>
            <h3 className="text-lg font-bold text-gray-900 mb-2">Still have questions?</h3>
            <p className="text-gray-500 text-sm mb-5">Our support team is available 24/7 via chat, email, and phone.</p>
            <div className="flex flex-wrap gap-3 justify-center">
              <button className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-semibold px-5 py-2.5 rounded-xl transition-colors cursor-pointer whitespace-nowrap">
                <i className="ri-chat-3-line"></i> Live Chat
              </button>
              <button className="flex items-center gap-2 border border-gray-200 text-gray-700 hover:border-emerald-300 hover:text-emerald-600 text-sm font-medium px-5 py-2.5 rounded-xl transition-colors cursor-pointer whitespace-nowrap">
                <i className="ri-mail-line"></i> Email Support
              </button>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
