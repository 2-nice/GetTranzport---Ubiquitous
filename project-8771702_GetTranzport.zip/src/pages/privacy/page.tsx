import { Link } from 'react-router-dom';
import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';

const SECTIONS = [
  {
    title: '1. Information We Collect',
    content: `We collect information you provide directly to us, such as when you create an account, make a booking, or contact support. This includes: name, email address, phone number, payment information (processed securely by our payment partners), trip details (pickup/drop-off locations, dates, passenger count), and communications with our support team. We also collect information automatically when you use our platform, including device information, IP address, browser type, and usage data.`,
  },
  {
    title: '2. How We Use Your Information',
    content: `We use the information we collect to: process and manage your bookings; connect you with available drivers; process payments and send receipts; provide customer support; send service-related communications; improve and personalize our platform; comply with legal obligations; and detect and prevent fraud. We do not sell your personal information to third parties.`,
  },
  {
    title: '3. Information Sharing',
    content: `We share your information with: drivers (name, phone number, and pickup details necessary to complete your trip); payment processors (to process transactions securely); service providers (companies that help us operate our platform, bound by confidentiality agreements); and law enforcement (when required by law or to protect safety). We require all third parties to respect the security of your data and treat it in accordance with applicable law.`,
  },
  {
    title: '4. Data Security',
    content: `We implement industry-standard security measures to protect your personal information, including SSL/TLS encryption for data in transit, AES-256 encryption for data at rest, regular security audits and penetration testing, and strict access controls. However, no method of transmission over the internet is 100% secure, and we cannot guarantee absolute security.`,
  },
  {
    title: '5. Data Retention',
    content: `We retain your personal information for as long as necessary to provide our services and comply with legal obligations. Account information is retained for the duration of your account plus 7 years for tax and legal compliance. Trip data is retained for 5 years. You may request deletion of your account and associated data at any time, subject to legal retention requirements.`,
  },
  {
    title: '6. Your Rights',
    content: `Depending on your location, you may have the following rights regarding your personal data: the right to access your data; the right to correct inaccurate data; the right to request deletion of your data; the right to restrict or object to processing; the right to data portability; and the right to withdraw consent. To exercise these rights, contact our Data Protection Officer at info@gettranzport.com.`,
  },
  {
    title: '7. Cookies',
    content: `We use cookies and similar tracking technologies to enhance your experience on our platform. Essential cookies are required for the platform to function. Analytics cookies help us understand how users interact with our platform. Marketing cookies allow us to show you relevant advertisements. You can manage your cookie preferences through your browser settings or our cookie consent tool.`,
  },
  {
    title: '8. International Transfers',
    content: `As a global platform, your data may be transferred to and processed in countries other than your own. We ensure appropriate safeguards are in place for such transfers, including Standard Contractual Clauses approved by the European Commission and adequacy decisions where applicable.`,
  },
  {
    title: '9. Children\'s Privacy',
    content: `Our platform is not directed to children under the age of 18. We do not knowingly collect personal information from children. If you believe we have inadvertently collected information from a child, please contact us immediately and we will take steps to delete such information.`,
  },
  {
    title: '10. Contact Us',
    content: `If you have questions about this Privacy Policy or our data practices, please contact our Data Protection Officer at info@gettranzport.com or write to our headquarters: 2-Nice Rideshare & Carpooling Transport Services Inc. (GeTTranzport.com - Ubiquitous Ride), 635 St. James Street, Winnipeg, MB R3G 3R4, Canada. Regional offices: One Canada Square, Canary Wharf, London, E14 5AB, United Kingdom | 350 Fifth Avenue, Suite 4100, New York, NY 10118, USA | Plot 1, Adeola Odeku Street, Victoria Island, Lagos, Nigeria.`,
  },
];

export default function PrivacyPage() {
  return (
    <div className="min-h-screen flex flex-col bg-white" style={{ fontFamily: 'Inter, sans-serif' }}>
      <Navbar />

      <section className="pt-28 pb-10 bg-gray-900 text-center">
        <div className="max-w-2xl mx-auto px-6">
          <h1 className="text-4xl font-extrabold text-white mb-3" style={{ fontFamily: 'Syne, sans-serif' }}>Privacy Policy</h1>
          <p className="text-white/55 text-sm">Last updated: April 23, 2026</p>
        </div>
      </section>

      <section className="py-14 bg-white">
        <div className="max-w-3xl mx-auto px-6">
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-5 mb-10 flex items-start gap-3">
            <i className="ri-shield-check-line text-emerald-500 text-lg flex-shrink-0 mt-0.5"></i>
            <p className="text-sm text-emerald-800 leading-relaxed">
              At GetTranzport, your privacy is a priority. This policy explains how we collect, use, and protect your personal information when you use our platform.
            </p>
          </div>

          <div className="flex flex-col gap-8">
            {SECTIONS.map((s) => (
              <div key={s.title}>
                <h2 className="text-base font-bold text-gray-900 mb-3" style={{ fontFamily: 'Syne, sans-serif' }}>{s.title}</h2>
                <p className="text-sm text-gray-600 leading-relaxed">{s.content}</p>
              </div>
            ))}
          </div>

          <div className="mt-12 pt-8 border-t border-gray-100 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-xs text-gray-400">© 2026 2-Nice Rideshare &amp; Carpooling Transport Services Inc. All rights reserved.</p>
            <div className="flex gap-4">
              <Link to="/terms" className="text-xs text-emerald-500 hover:text-emerald-600 transition-colors">Terms of Service</Link>
              <Link to="/support" className="text-xs text-emerald-500 hover:text-emerald-600 transition-colors">Contact Support</Link>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
