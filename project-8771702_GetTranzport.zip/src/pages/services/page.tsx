import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';
import { Link } from 'react-router-dom';

const SERVICES = [
  {
    id: 'city',
    icon: 'ri-route-line',
    title: 'City-to-City Rides',
    tagline: 'Direct. Private. On your schedule.',
    desc: 'Book a private, direct transfer between any two cities worldwide. No shared rides, no detours — just you, your driver, and the open road. Perfect for business travel, family trips, and weekend getaways.',
    features: ['Door-to-door pickup & drop-off', 'No shared passengers', 'Fixed price agreed before booking', 'Available 24/7 in 150+ countries', 'All vehicle classes available'],
    pricing: 'Per-kilometer pricing: base fare + distance rate. Transparent, no surprises.',
    img: 'https://gettransfer.com/common/transport_types/business_small.png?v=2026',
    color: 'emerald',
    routes: ['London → Manchester', 'Lagos → Abuja', 'New York → Washington D.C.', 'Paris → Brussels'],
  },
  {
    id: 'airport',
    icon: 'ri-flight-takeoff-line',
    title: 'Airport Pick-up & Drop-off',
    tagline: 'Meet & greet. Flight tracked. Always on time.',
    desc: 'Stress-free airport transfers with professional meet & greet service. Your driver monitors your flight in real time and adjusts for delays — with up to 60 minutes of free waiting time included.',
    features: ['Flight tracking & delay adjustment', 'Meet & greet with name board at arrivals', 'Up to 60 min free waiting time', 'Help with luggage included', 'Available at 500+ airports worldwide'],
    pricing: 'Per-kilometer pricing with airport base supplement. Fixed price, no meter anxiety.',
    img: 'https://gettransfer.com/common/transport_types/comfort_small.png?v=2026',
    color: 'sky',
    routes: ['LHR → Central London', 'JFK → Manhattan', 'LOS → Victoria Island', 'CDG → Paris Centre'],
  },
  {
    id: 'state',
    icon: 'ri-map-2-line',
    title: 'Across-State / Province Rides',
    tagline: 'Long-haul comfort. Professional drivers.',
    desc: 'Cross state and provincial boundaries in comfort with experienced long-haul drivers. Whether it\'s a 3-hour or 12-hour journey, GetTranzport drivers know the routes, the rest stops, and the roads.',
    features: ['Experienced long-haul drivers', 'Comfort stops on request', 'Multiple vehicle classes for groups', 'Fixed price — no meter running', 'Available across all 50 US states, all Canadian provinces, and more'],
    pricing: 'Per-kilometer pricing with long-haul discount tiers. The further you go, the better the rate.',
    img: 'https://gettransfer.com/common/transport_types/suv_small.png?v=2026',
    color: 'amber',
    routes: ['Toronto → Ottawa', 'Lagos → Port Harcourt', 'Mumbai → Goa', 'Sydney → Melbourne'],
  },
  {
    id: 'crossborder',
    icon: 'ri-global-line',
    title: 'Cross-Border Transfers',
    tagline: 'Seamless. International. Hassle-free.',
    desc: 'Travel across international borders with drivers who know the crossing procedures, documentation requirements, and fastest routes. From Europe to Africa to the Americas — we\'ve got every border covered.',
    features: ['Drivers experienced in border procedures', 'Pre-trip documentation guidance', 'Available at 200+ international crossings', 'Real-time border wait time updates', 'Multi-currency pricing'],
    pricing: 'Per-kilometer pricing with border crossing supplement. All fees included in your quote.',
    img: 'https://gettransfer.com/common/transport_types/premium_small.png?v=2026',
    color: 'rose',
    routes: ['Tijuana → San Diego', 'Paris → Brussels', 'Nairobi → Kampala', 'Buenos Aires → Montevideo'],
  },
];

const COLOR_MAP: Record<string, { bg: string; text: string; border: string; pill: string; pillText: string; btn: string }> = {
  emerald: { bg: 'bg-emerald-50', text: 'text-emerald-600', border: 'border-emerald-200', pill: 'bg-emerald-100', pillText: 'text-emerald-700', btn: 'bg-emerald-500 hover:bg-emerald-600' },
  sky:     { bg: 'bg-sky-50',     text: 'text-sky-600',     border: 'border-sky-200',     pill: 'bg-sky-100',     pillText: 'text-sky-700',     btn: 'bg-sky-500 hover:bg-sky-600'         },
  amber:   { bg: 'bg-amber-50',   text: 'text-amber-600',   border: 'border-amber-200',   pill: 'bg-amber-100',   pillText: 'text-amber-700',   btn: 'bg-amber-500 hover:bg-amber-600'     },
  rose:    { bg: 'bg-rose-50',    text: 'text-rose-600',    border: 'border-rose-200',     pill: 'bg-rose-100',    pillText: 'text-rose-700',    btn: 'bg-rose-500 hover:bg-rose-600'       },
};

export default function ServicesPage() {
  return (
    <div className="min-h-screen flex flex-col bg-white" style={{ fontFamily: 'Inter, sans-serif' }}>
      <Navbar />

      {/* Hero */}
      <section className="pt-32 pb-16 bg-gray-950 text-center px-6">
        <span className="text-emerald-400 text-xs font-bold tracking-widest uppercase">Our Services</span>
        <h1 className="text-4xl md:text-5xl font-extrabold text-white mt-3 mb-4" style={{ fontFamily: 'Syne, sans-serif' }}>
          Every Long-Distance Journey, Covered
        </h1>
        <p className="text-gray-400 text-base max-w-xl mx-auto">
          Four specialised service types. One platform. 150+ countries. Professional vetted drivers for every route.
        </p>
      </section>

      {/* Services */}
      <main className="flex-1 py-16 px-6">
        <div className="max-w-5xl mx-auto flex flex-col gap-16">
          {SERVICES.map((s, i) => {
            const c = COLOR_MAP[s.color];
            return (
              <div key={s.id} className={`flex flex-col ${i % 2 === 1 ? 'lg:flex-row-reverse' : 'lg:flex-row'} gap-10 items-center`}>
                {/* Visual */}
                <div className={`flex-shrink-0 w-full lg:w-72 h-56 rounded-3xl ${c.bg} ${c.border} border-2 flex items-center justify-center`}>
                  <img src={s.img} alt={s.title} className="h-36 w-auto object-contain" />
                </div>
                {/* Text */}
                <div className="flex-1">
                  <span className={`inline-flex items-center gap-1.5 text-xs font-bold px-3 py-1 rounded-full mb-3 ${c.pill} ${c.pillText}`}>
                    <i className={`${s.icon} text-sm`}></i>
                    {s.title}
                  </span>
                  <h2 className="text-2xl md:text-3xl font-extrabold text-gray-900 mb-1" style={{ fontFamily: 'Syne, sans-serif' }}>{s.title}</h2>
                  <p className={`text-sm font-semibold ${c.text} mb-3`}>{s.tagline}</p>
                  <p className="text-gray-500 text-sm leading-relaxed mb-5">{s.desc}</p>
                  <div className={`flex items-start gap-2 mb-5 p-3 rounded-xl ${c.bg} ${c.border} border`}>
                    <i className="ri-price-tag-3-line text-sm mt-0.5 flex-shrink-0"></i>
                    <p className="text-xs text-gray-700 leading-relaxed">{s.pricing}</p>
                  </div>
                  <ul className="flex flex-col gap-2 mb-5">
                    {s.features.map((f) => (
                      <li key={f} className="flex items-center gap-2 text-sm text-gray-700">
                        <i className="ri-checkbox-circle-fill text-emerald-500 text-base flex-shrink-0"></i>
                        {f}
                      </li>
                    ))}
                  </ul>
                  <div className="flex flex-wrap gap-2 mb-5">
                    {s.routes.map((r) => (
                      <span key={r} className="text-xs bg-gray-100 text-gray-600 px-3 py-1 rounded-full">{r}</span>
                    ))}
                  </div>
                  <Link to="/" className={`inline-flex items-center gap-2 ${c.btn} text-white text-sm font-bold px-5 py-2.5 rounded-xl transition-colors cursor-pointer whitespace-nowrap`}>
                    Book Now <i className="ri-arrow-right-line"></i>
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      </main>

      <Footer />
    </div>
  );
}
