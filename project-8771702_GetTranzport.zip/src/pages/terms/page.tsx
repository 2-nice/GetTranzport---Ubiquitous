import { Link } from 'react-router-dom';
import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';

const SECTIONS = [
  {
    title: '1. Acceptance of Terms',
    content: `By accessing or using the GetTranzport platform (website, mobile application, or API), you agree to be bound by these Terms of Service and all applicable laws and regulations. If you do not agree with any of these terms, you are prohibited from using or accessing this platform. These terms apply to all users of the platform, including passengers, drivers, agents, and business clients.`,
  },
  {
    title: '2. Description of Service',
    content: `GetTranzport operates as a marketplace platform connecting passengers with independent professional drivers for long-distance private transfer services. These services include city-to-city rides, airport pick-up and drop-off, across-state and province transfers, and cross-border passenger transfers. GetTranzport does not directly provide transportation services; it facilitates connections between passengers and independent drivers.`,
  },
  {
    title: '3. User Accounts',
    content: `To access certain features of the platform, you must register for an account. You agree to provide accurate, current, and complete information during registration and to update such information to keep it accurate. You are responsible for safeguarding your password and for all activities that occur under your account. You must notify GetTranzport immediately of any unauthorized use of your account.`,
  },
  {
    title: '4. Booking and Payment',
    content: `All bookings made through the GetTranzport platform are subject to driver acceptance. Prices displayed are estimates based on the tender system; final prices are set by drivers. Payment is processed securely through our payment partners. By making a booking, you authorize GetTranzport to charge the agreed amount to your selected payment method. All prices are inclusive of applicable taxes unless otherwise stated.`,
  },
  {
    title: '5. Cancellation and Refund Policy',
    content: `Passengers may cancel bookings free of charge up to 24 hours before the scheduled departure time. Cancellations made within 24 hours of departure may be subject to a cancellation fee of up to 50% of the booking value. No-shows will be charged the full booking amount. Refunds for eligible cancellations will be processed within 3–5 business days to the original payment method.`,
  },
  {
    title: '6. Driver Obligations',
    content: `All drivers on the GetTranzport platform must maintain valid driving licenses, vehicle registration, and insurance at all times. Drivers must complete GetTranzport\'s verification process including background checks and vehicle inspections. Drivers are independent contractors and are not employees of GetTranzport. Drivers are responsible for their own tax obligations and compliance with local transportation regulations.`,
  },
  {
    title: '7. Prohibited Conduct',
    content: `Users are prohibited from: using the platform for any unlawful purpose; harassing, threatening, or intimidating other users or drivers; providing false information during registration or booking; attempting to circumvent the platform\'s payment system; using automated tools to access the platform without authorization; and engaging in any conduct that disrupts or interferes with the platform\'s operation.`,
  },
  {
    title: '8. Limitation of Liability',
    content: `GetTranzport\'s liability to you for any cause whatsoever, and regardless of the form of the action, will at all times be limited to the amount paid by you to GetTranzport for the specific booking giving rise to the claim. GetTranzport is not liable for any indirect, incidental, special, consequential, or punitive damages, including loss of profits, data, or goodwill.`,
  },
  {
    title: '9. Privacy',
    content: `Your use of the GetTranzport platform is also governed by our Privacy Policy, which is incorporated into these Terms by reference. Please review our Privacy Policy to understand our practices regarding the collection, use, and disclosure of your personal information.`,
  },
  {
    title: '10. Changes to Terms',
    content: `GetTranzport reserves the right to modify these Terms of Service at any time. We will notify users of significant changes via email or prominent notice on the platform. Your continued use of the platform after such modifications constitutes your acceptance of the updated terms. We recommend reviewing these terms periodically.`,
  },
  {
    title: '11. Governing Law',
    content: `These Terms of Service shall be governed by and construed in accordance with the laws of the Province of Manitoba, Canada, without regard to its conflict of law provisions. Any disputes arising under these terms shall be subject to the exclusive jurisdiction of the courts of Manitoba, Canada.`,
  },
  {
    title: '12. Contact',
    content: `If you have any questions about these Terms of Service, please contact our legal team at info@gettranzport.com or write to our headquarters: 2-Nice Rideshare & Carpooling Transport Services Inc. (GeTTranzport.com - Ubiquitous Ride), 635 St. James Street, Winnipeg, MB R3G 3R4, Canada. Regional offices: One Canada Square, Canary Wharf, London, E14 5AB, United Kingdom | 350 Fifth Avenue, Suite 4100, New York, NY 10118, USA | Plot 1, Adeola Odeku Street, Victoria Island, Lagos, Nigeria.`,
  },
];

export default function TermsPage() {
  return (
    <div className="min-h-screen flex flex-col bg-white" style={{ fontFamily: 'Inter, sans-serif' }}>
      <Navbar />

      <section className="pt-28 pb-10 bg-gray-900 text-center">
        <div className="max-w-2xl mx-auto px-6">
          <h1 className="text-4xl font-extrabold text-white mb-3" style={{ fontFamily: 'Syne, sans-serif' }}>Terms of Service</h1>
          <p className="text-white/55 text-sm">Last updated: April 23, 2026</p>
        </div>
      </section>

      <section className="py-14 bg-white">
        <div className="max-w-3xl mx-auto px-6">
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-5 mb-10 flex items-start gap-3">
            <i className="ri-information-line text-amber-500 text-lg flex-shrink-0 mt-0.5"></i>
            <p className="text-sm text-amber-800 leading-relaxed">
              Please read these Terms of Service carefully before using the GetTranzport platform. These terms constitute a legally binding agreement between you and 2-Nice Rideshare &amp; Carpooling Transport Services Inc.
            </p>
          </div>

          <div className="flex flex-col gap-8">
            {SECTIONS.map((s) => (
              <div key={s.title}>
                <h2 className="text-base font-bold text-gray-900 mb-3" style={{ fontFamily: 'Syne, sans-serif' }}>{s.title}</h2>
                <p className="text-sm text-gray-600 leading-relaxed">{s.content}</p>
              </div>
            ))}
          </div>

          <div className="mt-12 pt-8 border-t border-gray-100 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-xs text-gray-400">© 2026 2-Nice Rideshare &amp; Carpooling Transport Services Inc. All rights reserved.</p>
            <div className="flex gap-4">
              <Link to="/privacy" className="text-xs text-emerald-500 hover:text-emerald-600 transition-colors">Privacy Policy</Link>
              <Link to="/support" className="text-xs text-emerald-500 hover:text-emerald-600 transition-colors">Contact Support</Link>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
