import { useState, FormEvent } from 'react';
import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';

const BENEFITS = [
  { icon: 'ri-percent-line', title: 'Up to 15% Commission', desc: 'Earn competitive commissions on every booking you refer. Paid monthly with no cap.' },
  { icon: 'ri-dashboard-line', title: 'Agent Dashboard', desc: 'Full-featured portal to manage bookings, track earnings, and view client trip history.' },
  { icon: 'ri-global-line', title: '180+ Countries', desc: 'Offer your clients transfers in virtually every country — one platform, global coverage.' },
  { icon: 'ri-customer-service-2-line', title: 'Dedicated Agent Support', desc: 'Priority 24/7 support line exclusively for registered agents. No queues, no bots.' },
  { icon: 'ri-price-tag-3-line', title: 'Exclusive Agent Rates', desc: 'Access wholesale pricing not available to the public. Maximize your margin.' },
  { icon: 'ri-file-list-3-line', title: 'White-Label Options', desc: 'Embed GetTranzport booking into your own website with our white-label API integration.' },
];

const TIERS = [
  {
    name: 'Starter Agent',
    commission: '8%',
    bookings: '1–20 bookings/mo',
    features: ['Agent dashboard access', 'Standard support', 'Monthly payouts', 'Basic reporting'],
    cta: 'Apply Now',
    highlight: false,
  },
  {
    name: 'Pro Agent',
    commission: '12%',
    bookings: '21–100 bookings/mo',
    features: ['Everything in Starter', 'Priority support line', 'Weekly payouts', 'Advanced analytics', 'Exclusive rates'],
    cta: 'Apply Now',
    highlight: true,
  },
  {
    name: 'Elite Partner',
    commission: '15%',
    bookings: '100+ bookings/mo',
    features: ['Everything in Pro', 'Dedicated account manager', 'Daily payouts', 'White-label API', 'Co-marketing opportunities'],
    cta: 'Contact Us',
    highlight: false,
  },
];

export default function ForAgentsPage() {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new URLSearchParams(new FormData(form) as unknown as Record<string, string>);
    try {
      await fetch('https://readdy.ai/api/form/d7l7638uvp0hpqmgi0e0', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: data.toString(),
      });
      setSubmitted(true);
    } catch {
      setSubmitted(true);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-white" style={{ fontFamily: 'Inter, sans-serif' }}>
      <Navbar />

      {/* Hero */}
      <section className="relative pt-28 pb-20 overflow-hidden">
        <img
          src="https://readdy.ai/api/search-image?query=professional%20travel%20agent%20working%20at%20modern%20desk%20with%20multiple%20screens%20showing%20booking%20systems%2C%20clean%20office%20environment%2C%20warm%20lighting%2C%20business%20professional%20setting&width=1440&height=500&seq=agents-hero-1&orientation=landscape"
          alt="GetTranzport agent program"
          className="absolute inset-0 w-full h-full object-cover object-top opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-gray-900 via-gray-900/90 to-gray-900/60"></div>
        <div className="relative z-10 max-w-5xl mx-auto px-6">
          <div className="max-w-2xl">
            <span className="inline-block bg-amber-500/20 text-amber-400 text-xs font-semibold px-3 py-1 rounded-full mb-5 border border-amber-500/30">
              Agent &amp; Affiliate Program
            </span>
            <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-5 leading-tight" style={{ fontFamily: 'Syne, sans-serif' }}>
              Earn More.<br />Sell Smarter.<br />
              <span className="text-amber-400">Partner With GetTranzport.</span>
            </h1>
            <p className="text-white/65 text-base mb-8 leading-relaxed">
              Join 3,200+ travel agents and affiliates earning commissions on every long-distance transfer booking. No upfront costs, no monthly fees.
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <a
                href="#apply"
                className="flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-600 text-white font-bold px-7 py-3.5 rounded-xl transition-colors cursor-pointer whitespace-nowrap"
              >
                <i className="ri-user-add-line"></i>
                Apply to Join
              </a>
              <a
                href="#tiers"
                className="flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 text-white font-semibold px-7 py-3.5 rounded-xl transition-colors cursor-pointer whitespace-nowrap border border-white/20"
              >
                View Commission Tiers
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-10 bg-amber-500">
        <div className="max-w-5xl mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            {[
              { value: '3,200+', label: 'Active Agents' },
              { value: '$4.2M', label: 'Paid in Commissions' },
              { value: '180+', label: 'Countries Covered' },
              { value: '15%', label: 'Max Commission Rate' },
            ].map((s) => (
              <div key={s.label}>
                <div className="text-2xl font-extrabold text-white mb-1" style={{ fontFamily: 'Syne, sans-serif' }}>{s.value}</div>
                <div className="text-white/75 text-xs">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-16 bg-white">
        <div className="max-w-5xl mx-auto px-6">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>Why Agents Choose GetTranzport</h2>
            <p className="text-gray-500 text-sm">Everything you need to build a profitable transfer business.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {BENEFITS.map((b) => (
              <div key={b.title} className="border border-gray-100 rounded-2xl p-6 hover:border-amber-200 hover:bg-amber-50/20 transition-all duration-200">
                <div className="w-10 h-10 flex items-center justify-center bg-amber-50 rounded-xl mb-4">
                  <i className={`${b.icon} text-amber-500 text-lg`}></i>
                </div>
                <h3 className="text-sm font-bold text-gray-900 mb-2">{b.title}</h3>
                <p className="text-xs text-gray-500 leading-relaxed">{b.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Commission Tiers */}
      <section id="tiers" className="py-16 bg-gray-50/60">
        <div className="max-w-5xl mx-auto px-6">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>Commission Tiers</h2>
            <p className="text-gray-500 text-sm">Scale your earnings as your booking volume grows.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {TIERS.map((t) => (
              <div
                key={t.name}
                className={`rounded-2xl p-7 flex flex-col ${
                  t.highlight
                    ? 'bg-gray-900 text-white border-2 border-amber-400'
                    : 'bg-white border border-gray-100'
                }`}
              >
                {t.highlight && (
                  <span className="text-[10px] font-bold bg-amber-400 text-gray-900 px-2.5 py-1 rounded-full w-fit mb-4">MOST POPULAR</span>
                )}
                <h3 className={`text-base font-bold mb-1 ${t.highlight ? 'text-white' : 'text-gray-900'}`}>{t.name}</h3>
                <div className={`text-3xl font-extrabold mb-1 ${t.highlight ? 'text-amber-400' : 'text-gray-900'}`} style={{ fontFamily: 'Syne, sans-serif' }}>
                  {t.commission}
                </div>
                <p className={`text-xs mb-5 ${t.highlight ? 'text-white/60' : 'text-gray-400'}`}>{t.bookings}</p>
                <ul className="flex flex-col gap-2 mb-7 flex-1">
                  {t.features.map((f) => (
                    <li key={f} className="flex items-center gap-2 text-xs">
                      <i className={`ri-checkbox-circle-fill ${t.highlight ? 'text-amber-400' : 'text-emerald-500'}`}></i>
                      <span className={t.highlight ? 'text-white/80' : 'text-gray-600'}>{f}</span>
                    </li>
                  ))}
                </ul>
                <a
                  href="#apply"
                  className={`w-full text-center py-3 rounded-xl text-sm font-bold transition-colors cursor-pointer whitespace-nowrap ${
                    t.highlight
                      ? 'bg-amber-400 hover:bg-amber-500 text-gray-900'
                      : 'bg-gray-100 hover:bg-gray-200 text-gray-800'
                  }`}
                >
                  {t.cta}
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Application Form */}
      <section id="apply" className="py-16 bg-white">
        <div className="max-w-2xl mx-auto px-6">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>Apply to Become an Agent</h2>
            <p className="text-gray-500 text-sm">Fill in the form below. Our partnerships team will review and respond within 48 hours.</p>
          </div>

          {submitted ? (
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-10 text-center">
              <div className="w-14 h-14 flex items-center justify-center bg-amber-100 rounded-full mx-auto mb-4">
                <i className="ri-checkbox-circle-fill text-amber-500 text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Application Received!</h3>
              <p className="text-sm text-gray-600">Our partnerships team will review your application and get back to you within 48 hours.</p>
            </div>
          ) : (
            <form
              data-readdy-form
              onSubmit={handleSubmit}
              className="bg-white border border-gray-100 rounded-2xl p-8 flex flex-col gap-4"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">Full Name</label>
                  <input name="full_name" type="text" required placeholder="Jane Smith" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">Email Address</label>
                  <input name="email" type="email" required placeholder="jane@agency.com" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition" />
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">Company / Agency Name</label>
                  <input name="company" type="text" required placeholder="Smith Travel Agency" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">Country</label>
                  <input name="country" type="text" required placeholder="Canada" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Estimated Monthly Bookings</label>
                <select name="monthly_bookings" required className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition cursor-pointer">
                  <option value="">Select range...</option>
                  <option value="1-20">1–20 bookings/month</option>
                  <option value="21-100">21–100 bookings/month</option>
                  <option value="100+">100+ bookings/month</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Tell us about your business</label>
                <textarea name="business_description" required rows={4} maxLength={500} placeholder="Describe your travel business and how you plan to use GetTranzport..." className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 transition resize-none" />
                <p className="text-xs text-gray-400 mt-1">Max 500 characters</p>
              </div>
              <button type="submit" className="w-full bg-amber-500 hover:bg-amber-600 text-white font-bold py-3.5 rounded-xl text-sm transition-colors cursor-pointer whitespace-nowrap">
                Submit Application
              </button>
            </form>
          )}
        </div>
      </section>

      {/* Contact / Support */}
      <section className="py-16 bg-gray-50/60 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>Agent Support</h2>
            <p className="text-gray-500 text-sm">Priority 24/7 support line exclusively for registered agents.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <a href="tel:+14313342841" className="flex items-center gap-3 bg-white border border-gray-100 rounded-2xl p-5 hover:border-amber-300 transition-colors cursor-pointer">
              <div className="w-10 h-10 flex items-center justify-center bg-amber-50 rounded-xl flex-shrink-0">
                <i className="ri-phone-line text-amber-500 text-lg"></i>
              </div>
              <div>
                <p className="text-xs text-gray-400 font-medium">24/7 Phone</p>
                <p className="text-sm font-bold text-gray-900">+1 431-334-2841</p>
              </div>
            </a>
            <a href="mailto:support@gettranzport.com" className="flex items-center gap-3 bg-white border border-gray-100 rounded-2xl p-5 hover:border-amber-300 transition-colors cursor-pointer">
              <div className="w-10 h-10 flex items-center justify-center bg-amber-50 rounded-xl flex-shrink-0">
                <i className="ri-mail-line text-amber-500 text-lg"></i>
              </div>
              <div>
                <p className="text-xs text-gray-400 font-medium">Agent Email</p>
                <p className="text-sm font-bold text-gray-900">support@gettranzport.com</p>
              </div>
            </a>
            <a href="https://wa.me/14313342841" target="_blank" rel="nofollow noopener" className="flex items-center gap-3 bg-white border border-gray-100 rounded-2xl p-5 hover:border-amber-300 transition-colors cursor-pointer">
              <div className="w-10 h-10 flex items-center justify-center bg-amber-50 rounded-xl flex-shrink-0">
                <i className="ri-whatsapp-line text-amber-500 text-lg"></i>
              </div>
              <div>
                <p className="text-xs text-gray-400 font-medium">WhatsApp</p>
                <p className="text-sm font-bold text-gray-900">+1 431-334-2841</p>
              </div>
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
