import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';

type BookingMode = 'ride_km' | 'ride_hr' | 'delivery_kg';

// ─── Ride/km offers ───────────────────────────────────────────────────────────
const OFFERS_RIDE_KM = [
  {
    id: 1, driver: 'Marcus T.', rating: 4.97, trips: 1842,
    avatar: 'https://readdy.ai/api/search-image?query=professional%20male%20driver%20headshot%2C%20smart%20uniform%2C%20confident%20smile%2C%20clean%20background%2C%20portrait%20photography&width=80&height=80&seq=driver-1&orientation=squarish',
    vehicle: 'Mercedes-Benz E-Class', vehicleClass: 'Business', year: 2024, pax: 3, luggage: 3,
    price: 142, basePrice: 45, perKm: 0.29, distance: 335, eta: '3h 45m',
    features: ['Meet & Greet', 'Free Waiting 60 min', 'Wi-Fi', 'Water Included'],
    badge: 'Top Rated', badgeColor: 'bg-amber-100 text-amber-700',
  },
  {
    id: 2, driver: 'Elena V.', rating: 4.91, trips: 3204,
    avatar: 'https://readdy.ai/api/search-image?query=professional%20female%20driver%20headshot%2C%20smart%20uniform%2C%20friendly%20smile%2C%20clean%20background%2C%20portrait%20photography&width=80&height=80&seq=driver-2&orientation=squarish',
    vehicle: 'Toyota Camry', vehicleClass: 'Comfort', year: 2023, pax: 3, luggage: 2,
    price: 89, basePrice: 35, perKm: 0.16, distance: 335, eta: '3h 50m',
    features: ['Meet & Greet', 'Free Waiting 60 min', 'Air Conditioning'],
    badge: 'Best Value', badgeColor: 'bg-emerald-100 text-emerald-700',
  },
  {
    id: 3, driver: 'James O.', rating: 4.88, trips: 967,
    avatar: 'https://readdy.ai/api/search-image?query=professional%20male%20African%20driver%20headshot%2C%20smart%20uniform%2C%20confident%20expression%2C%20clean%20background%2C%20portrait%20photography&width=80&height=80&seq=driver-3&orientation=squarish',
    vehicle: 'BMW 5 Series', vehicleClass: 'Premium', year: 2024, pax: 3, luggage: 3,
    price: 198, basePrice: 55, perKm: 0.43, distance: 335, eta: '3h 40m',
    features: ['Meet & Greet', 'Free Waiting 60 min', 'Wi-Fi', 'Refreshments', 'Child Seat Available'],
    badge: 'Premium', badgeColor: 'bg-violet-100 text-violet-700',
  },
  {
    id: 4, driver: 'Priya S.', rating: 4.95, trips: 2110,
    avatar: 'https://readdy.ai/api/search-image?query=professional%20female%20Indian%20driver%20headshot%2C%20smart%20uniform%2C%20warm%20smile%2C%20clean%20background%2C%20portrait%20photography&width=80&height=80&seq=driver-4&orientation=squarish',
    vehicle: 'Volkswagen Passat', vehicleClass: 'Economy', year: 2022, pax: 3, luggage: 2,
    price: 72, basePrice: 28, perKm: 0.13, distance: 335, eta: '4h 00m',
    features: ['Meet & Greet', 'Free Waiting 60 min'],
    badge: 'Lowest Price', badgeColor: 'bg-sky-100 text-sky-700',
  },
  {
    id: 5, driver: 'Carlos M.', rating: 4.93, trips: 1456,
    avatar: 'https://readdy.ai/api/search-image?query=professional%20male%20Hispanic%20driver%20headshot%2C%20smart%20uniform%2C%20professional%20expression%2C%20clean%20background%2C%20portrait%20photography&width=80&height=80&seq=driver-5&orientation=squarish',
    vehicle: 'Mercedes-Benz V-Class', vehicleClass: 'Van', year: 2023, pax: 7, luggage: 7,
    price: 215, basePrice: 60, perKm: 0.46, distance: 335, eta: '3h 55m',
    features: ['Meet & Greet', 'Free Waiting 60 min', 'Wi-Fi', 'Extra Luggage Space'],
    badge: 'Group Friendly', badgeColor: 'bg-rose-100 text-rose-700',
  },
  {
    id: 6, driver: 'Aisha K.', rating: 4.90, trips: 788,
    avatar: 'https://readdy.ai/api/search-image?query=professional%20female%20Middle%20Eastern%20driver%20headshot%2C%20smart%20uniform%2C%20confident%20smile%2C%20clean%20background%2C%20portrait%20photography&width=80&height=80&seq=driver-6&orientation=squarish',
    vehicle: 'Rolls-Royce Ghost', vehicleClass: 'VIP', year: 2024, pax: 3, luggage: 3,
    price: 420, basePrice: 120, perKm: 0.89, distance: 335, eta: '3h 35m',
    features: ['Chauffeur Service', 'Free Waiting 60 min', 'Wi-Fi', 'Champagne', 'Privacy Screen'],
    badge: 'VIP', badgeColor: 'bg-yellow-100 text-yellow-700',
  },
];

// ─── Ride/hr offers ───────────────────────────────────────────────────────────
const OFFERS_RIDE_HR = [
  {
    id: 101, driver: 'Marcus T.', rating: 4.97, trips: 1842,
    avatar: 'https://readdy.ai/api/search-image?query=professional%20male%20driver%20headshot%2C%20smart%20uniform%2C%20confident%20smile%2C%20clean%20background%2C%20portrait%20photography&width=80&height=80&seq=driver-1&orientation=squarish',
    vehicle: 'Mercedes-Benz E-Class', vehicleClass: 'Business', year: 2024, pax: 3, luggage: 3,
    price: 180, perHour: 45, hours: 4,
    features: ['Meet & Greet', 'Wi-Fi', 'Water Included', 'Flexible Stops'],
    badge: 'Top Rated', badgeColor: 'bg-amber-100 text-amber-700',
  },
  {
    id: 102, driver: 'Elena V.', rating: 4.91, trips: 3204,
    avatar: 'https://readdy.ai/api/search-image?query=professional%20female%20driver%20headshot%2C%20smart%20uniform%2C%20friendly%20smile%2C%20clean%20background%2C%20portrait%20photography&width=80&height=80&seq=driver-2&orientation=squarish',
    vehicle: 'Toyota Camry', vehicleClass: 'Comfort', year: 2023, pax: 3, luggage: 2,
    price: 120, perHour: 30, hours: 4,
    features: ['Meet & Greet', 'Air Conditioning', 'Flexible Stops'],
    badge: 'Best Value', badgeColor: 'bg-emerald-100 text-emerald-700',
  },
  {
    id: 103, driver: 'James O.', rating: 4.88, trips: 967,
    avatar: 'https://readdy.ai/api/search-image?query=professional%20male%20African%20driver%20headshot%2C%20smart%20uniform%2C%20confident%20expression%2C%20clean%20background%2C%20portrait%20photography&width=80&height=80&seq=driver-3&orientation=squarish',
    vehicle: 'BMW 5 Series', vehicleClass: 'Premium', year: 2024, pax: 3, luggage: 3,
    price: 240, perHour: 60, hours: 4,
    features: ['Meet & Greet', 'Wi-Fi', 'Refreshments', 'Child Seat Available', 'Flexible Stops'],
    badge: 'Premium', badgeColor: 'bg-violet-100 text-violet-700',
  },
  {
    id: 104, driver: 'Priya S.', rating: 4.95, trips: 2110,
    avatar: 'https://readdy.ai/api/search-image?query=professional%20female%20Indian%20driver%20headshot%2C%20smart%20uniform%2C%20warm%20smile%2C%20clean%20background%2C%20portrait%20photography&width=80&height=80&seq=driver-4&orientation=squarish',
    vehicle: 'Volkswagen Passat', vehicleClass: 'Economy', year: 2022, pax: 3, luggage: 2,
    price: 100, perHour: 25, hours: 4,
    features: ['Meet & Greet', 'Flexible Stops'],
    badge: 'Lowest Price', badgeColor: 'bg-sky-100 text-sky-700',
  },
  {
    id: 105, driver: 'Carlos M.', rating: 4.93, trips: 1456,
    avatar: 'https://readdy.ai/api/search-image?query=professional%20male%20Hispanic%20driver%20headshot%2C%20smart%20uniform%2C%20professional%20expression%2C%20clean%20background%2C%20portrait%20photography&width=80&height=80&seq=driver-5&orientation=squarish',
    vehicle: 'Mercedes-Benz V-Class', vehicleClass: 'Van', year: 2023, pax: 7, luggage: 7,
    price: 280, perHour: 70, hours: 4,
    features: ['Meet & Greet', 'Wi-Fi', 'Extra Luggage Space', 'Flexible Stops'],
    badge: 'Group Friendly', badgeColor: 'bg-rose-100 text-rose-700',
  },
  {
    id: 106, driver: 'Aisha K.', rating: 4.90, trips: 788,
    avatar: 'https://readdy.ai/api/search-image?query=professional%20female%20Middle%20Eastern%20driver%20headshot%2C%20smart%20uniform%2C%20confident%20smile%2C%20clean%20background%2C%20portrait%20photography&width=80&height=80&seq=driver-6&orientation=squarish',
    vehicle: 'Rolls-Royce Ghost', vehicleClass: 'VIP', year: 2024, pax: 3, luggage: 3,
    price: 400, perHour: 100, hours: 4,
    features: ['Chauffeur Service', 'Wi-Fi', 'Champagne', 'Privacy Screen', 'Flexible Stops'],
    badge: 'VIP', badgeColor: 'bg-yellow-100 text-yellow-700',
  },
];

// ─── Delivery/kg offers ───────────────────────────────────────────────────────
const OFFERS_DELIVERY_KG = [
  {
    id: 201, driver: 'Tony A.', rating: 4.89, trips: 2340,
    avatar: 'https://readdy.ai/api/search-image?query=professional%20male%20delivery%20driver%20headshot%2C%20smart%20uniform%2C%20friendly%20expression%2C%20clean%20background%2C%20portrait%20photography&width=80&height=80&seq=driver-del-1&orientation=squarish',
    vehicle: 'Ford Transit Cargo Van', vehicleClass: 'Cargo Van', year: 2023,
    maxWeight: 800, maxVolume: '8 m³',
    price: 178, basePrice: 50, perKg: 0.38, weight: 50, distance: 335, eta: '4h 10m',
    features: ['Cargo Secured', 'Proof of Delivery', 'Real-Time Tracking', 'Insurance Included'],
    badge: 'Cargo Specialist', badgeColor: 'bg-orange-100 text-orange-700',
  },
  {
    id: 202, driver: 'Dmitri V.', rating: 4.85, trips: 1120,
    avatar: 'https://readdy.ai/api/search-image?query=professional%20male%20Eastern%20European%20delivery%20driver%20headshot%2C%20smart%20uniform%2C%20serious%20expression%2C%20clean%20background%2C%20portrait%20photography&width=80&height=80&seq=driver-del-2&orientation=squarish',
    vehicle: 'Mercedes Sprinter', vehicleClass: 'Large Van', year: 2022,
    maxWeight: 1500, maxVolume: '14 m³',
    price: 245, basePrice: 70, perKg: 0.52, weight: 50, distance: 335, eta: '4h 20m',
    features: ['Cargo Secured', 'Proof of Delivery', 'Real-Time Tracking', 'Fragile Handling', 'Insurance Included'],
    badge: 'Heavy Cargo', badgeColor: 'bg-red-100 text-red-700',
  },
  {
    id: 203, driver: 'Lena B.', rating: 4.94, trips: 876,
    avatar: 'https://readdy.ai/api/search-image?query=professional%20female%20delivery%20driver%20headshot%2C%20smart%20uniform%2C%20warm%20smile%2C%20clean%20background%2C%20portrait%20photography&width=80&height=80&seq=driver-del-3&orientation=squarish',
    vehicle: 'Volkswagen Caddy', vehicleClass: 'Small Van', year: 2024,
    maxWeight: 400, maxVolume: '3.5 m³',
    price: 98, basePrice: 30, perKg: 0.22, weight: 50, distance: 335, eta: '3h 55m',
    features: ['Cargo Secured', 'Proof of Delivery', 'Real-Time Tracking'],
    badge: 'Best Value', badgeColor: 'bg-emerald-100 text-emerald-700',
  },
  {
    id: 204, driver: 'Kwame A.', rating: 4.92, trips: 1654,
    avatar: 'https://readdy.ai/api/search-image?query=professional%20male%20African%20delivery%20driver%20headshot%2C%20smart%20uniform%2C%20confident%20expression%2C%20clean%20background%2C%20portrait%20photography&width=80&height=80&seq=driver-del-4&orientation=squarish',
    vehicle: 'Iveco Daily Box Truck', vehicleClass: 'Box Truck', year: 2023,
    maxWeight: 3500, maxVolume: '20 m³',
    price: 390, basePrice: 100, perKg: 0.78, weight: 50, distance: 335, eta: '4h 30m',
    features: ['Cargo Secured', 'Proof of Delivery', 'Real-Time Tracking', 'Tail Lift', 'Insurance Included', 'Pallet Handling'],
    badge: 'Bulk Freight', badgeColor: 'bg-purple-100 text-purple-700',
  },
  {
    id: 205, driver: 'Ravi P.', rating: 4.87, trips: 2890,
    avatar: 'https://readdy.ai/api/search-image?query=professional%20male%20South%20Asian%20delivery%20driver%20headshot%2C%20smart%20uniform%2C%20friendly%20smile%2C%20clean%20background%2C%20portrait%20photography&width=80&height=80&seq=driver-del-5&orientation=squarish',
    vehicle: 'Renault Kangoo', vehicleClass: 'Small Van', year: 2023,
    maxWeight: 350, maxVolume: '3 m³',
    price: 85, basePrice: 25, perKg: 0.18, weight: 50, distance: 335, eta: '3h 50m',
    features: ['Cargo Secured', 'Proof of Delivery', 'Real-Time Tracking'],
    badge: 'Lowest Price', badgeColor: 'bg-sky-100 text-sky-700',
  },
];

const VEHICLE_CLASSES_KM = ['All Classes', 'Economy', 'Comfort', 'Business', 'Premium', 'VIP', 'Van'];
const VEHICLE_CLASSES_HR = ['All Classes', 'Economy', 'Comfort', 'Business', 'Premium', 'VIP', 'Van'];
const VEHICLE_CLASSES_DL = ['All Classes', 'Small Van', 'Cargo Van', 'Large Van', 'Box Truck'];

const MODE_LABELS: Record<BookingMode, { label: string; sub: string; icon: string; color: string }> = {
  ride_km:      { label: 'Ride',     sub: 'per km', icon: 'ri-route-line',  color: 'bg-emerald-500' },
  ride_hr:      { label: 'Ride',     sub: 'per hr', icon: 'ri-time-line',   color: 'bg-emerald-500' },
  delivery_kg:  { label: 'Delivery', sub: 'per kg', icon: 'ri-truck-line',  color: 'bg-orange-500'  },
};

export default function BookPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<BookingMode>('ride_km');
  const [selectedClass, setSelectedClass] = useState('All Classes');
  const [sortBy, setSortBy] = useState('recommended');
  const [selectedOffer, setSelectedOffer] = useState<number | null>(null);
  const [showBreakdown, setShowBreakdown] = useState<number | null>(null);

  const handleModeChange = (m: BookingMode) => {
    setMode(m);
    setSelectedClass('All Classes');
    setSelectedOffer(null);
    setShowBreakdown(null);
  };

  const allOffers =
    mode === 'ride_km' ? OFFERS_RIDE_KM :
    mode === 'ride_hr' ? OFFERS_RIDE_HR :
    OFFERS_DELIVERY_KG;

  const vehicleClasses =
    mode === 'ride_km' ? VEHICLE_CLASSES_KM :
    mode === 'ride_hr' ? VEHICLE_CLASSES_HR :
    VEHICLE_CLASSES_DL;

  const filtered = allOffers.filter(
    (o) => selectedClass === 'All Classes' || o.vehicleClass === selectedClass
  );

  const sorted = [...filtered].sort((a, b) => {
    if (sortBy === 'price_asc') return a.price - b.price;
    if (sortBy === 'price_desc') return b.price - a.price;
    if (sortBy === 'rating') return b.rating - a.rating;
    return 0;
  });

  const isDelivery = mode === 'delivery_kg';
  const accentBtn = isDelivery ? 'bg-orange-500 hover:bg-orange-600' : 'bg-emerald-500 hover:bg-emerald-600';
  const accentText = isDelivery ? 'text-orange-400' : 'text-emerald-400';
  const accentBorder = isDelivery ? 'border-orange-400 ring-orange-400' : 'border-emerald-400 ring-emerald-400';

  return (
    <div className="min-h-screen flex flex-col bg-white" style={{ fontFamily: 'Inter, sans-serif' }}>
      <Navbar />

      {/* Search Summary Bar */}
      <div className="pt-16 bg-gray-900">
        <div className="max-w-6xl mx-auto px-6 py-5">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">

            {/* Route chips */}
            <div className="flex items-center gap-3 flex-wrap">
              {mode === 'ride_hr' ? (
                <div className="flex items-center gap-2 bg-white/10 rounded-xl px-4 py-2.5">
                  <i className={`ri-map-pin-2-fill ${accentText} text-sm`}></i>
                  <span className="text-white text-sm font-medium">London</span>
                </div>
              ) : (
                <div className="flex items-center gap-2 bg-white/10 rounded-xl px-4 py-2.5">
                  <i className={`ri-map-pin-2-fill ${accentText} text-sm`}></i>
                  <span className="text-white text-sm font-medium">London</span>
                  <i className="ri-arrow-right-line text-white/40 text-xs"></i>
                  <span className="text-white text-sm font-medium">Manchester</span>
                </div>
              )}
              {mode !== 'ride_hr' && (
                <div className="flex items-center gap-2 bg-white/10 rounded-xl px-4 py-2.5">
                  <i className={`ri-road-map-line ${accentText} text-sm`}></i>
                  <span className="text-white/80 text-sm">335 km</span>
                </div>
              )}
              <div className="flex items-center gap-2 bg-white/10 rounded-xl px-4 py-2.5">
                <i className={`ri-calendar-line ${accentText} text-sm`}></i>
                <span className="text-white/80 text-sm">May 15, 2026</span>
              </div>
              {mode === 'ride_hr' && (
                <div className="flex items-center gap-2 bg-white/10 rounded-xl px-4 py-2.5">
                  <i className={`ri-time-line ${accentText} text-sm`}></i>
                  <span className="text-white/80 text-sm">4 hours</span>
                </div>
              )}
              {mode === 'delivery_kg' && (
                <div className="flex items-center gap-2 bg-white/10 rounded-xl px-4 py-2.5">
                  <i className={`ri-scales-line ${accentText} text-sm`}></i>
                  <span className="text-white/80 text-sm">50 kg</span>
                </div>
              )}
              {mode !== 'delivery_kg' && (
                <div className="flex items-center gap-2 bg-white/10 rounded-xl px-4 py-2.5">
                  <i className={`ri-group-line ${accentText} text-sm`}></i>
                  <span className="text-white/80 text-sm">2 passengers</span>
                </div>
              )}
            </div>

            {/* Mode switcher */}
            <div className="flex items-center gap-3">
              <div className="flex bg-white/10 rounded-xl p-1 gap-0.5">
                {(Object.keys(MODE_LABELS) as BookingMode[]).map((m) => {
                  const ml = MODE_LABELS[m];
                  return (
                    <button
                      key={m}
                      onClick={() => handleModeChange(m)}
                      className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold whitespace-nowrap cursor-pointer transition-all ${
                        mode === m ? `${ml.color} text-white` : 'text-white/60 hover:text-white'
                      }`}
                    >
                      <i className={`${ml.icon} text-xs`}></i>
                      {ml.label}
                      <span className={`text-[9px] font-bold px-1 py-0.5 rounded ${
                        mode === m ? 'bg-white/20 text-white' : 'bg-white/10 text-white/50'
                      }`}>{ml.sub}</span>
                    </button>
                  );
                })}
              </div>
              <Link to="/" className={`flex items-center gap-2 ${accentText} text-sm font-medium hover:opacity-80 transition-colors whitespace-nowrap`}>
                <i className="ri-edit-line"></i>Edit
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Results */}
      <section className="flex-1 py-8 bg-gray-50/60">
        <div className="max-w-6xl mx-auto px-6">

          {/* Filters row */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
            <div>
              <h2 className="text-xl font-bold text-gray-900" style={{ fontFamily: 'Syne, sans-serif' }}>
                {sorted.length} {isDelivery ? 'Delivery Quotes' : 'Offers'} Available
              </h2>
              <p className="text-xs text-gray-500 mt-0.5">
                {mode === 'ride_km' && 'London → Manchester · 335 km · ~3h 45m · per-km pricing'}
                {mode === 'ride_hr' && 'London · 4 hours · per-hour pricing'}
                {mode === 'delivery_kg' && 'London → Manchester · 335 km · 50 kg cargo · per-kg pricing'}
              </p>
            </div>
            <div className="flex flex-wrap gap-2 items-center">
              <div className="flex flex-wrap gap-1.5">
                {vehicleClasses.map((c) => (
                  <button key={c} onClick={() => setSelectedClass(c)}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap cursor-pointer transition-all ${
                      selectedClass === c ? 'bg-gray-900 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:border-gray-400'
                    }`}>
                    {c}
                  </button>
                ))}
              </div>
              <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}
                className="border border-gray-200 rounded-xl px-3 py-1.5 text-xs text-gray-700 focus:outline-none focus:border-emerald-400 cursor-pointer bg-white">
                <option value="recommended">Recommended</option>
                <option value="price_asc">Price: Low to High</option>
                <option value="price_desc">Price: High to Low</option>
                <option value="rating">Highest Rated</option>
              </select>
            </div>
          </div>

          {/* Delivery info banner */}
          {isDelivery && (
            <div className="bg-orange-50 border border-orange-100 rounded-2xl px-5 py-4 mb-5 flex items-start gap-3">
              <i className="ri-information-line text-orange-500 text-lg flex-shrink-0 mt-0.5"></i>
              <div>
                <p className="text-sm font-semibold text-orange-800">Delivery/kg Pricing</p>
                <p className="text-xs text-orange-600 mt-0.5">
                  Prices are calculated as: Base fee + (rate per kg × cargo weight). All quotes include cargo insurance, proof of delivery, and real-time GPS tracking.
                </p>
              </div>
            </div>
          )}

          {sorted.length === 0 ? (
            <div className="text-center py-16 text-gray-400">
              <i className={`${isDelivery ? 'ri-truck-line' : 'ri-car-line'} text-4xl mb-3 block`}></i>
              <p className="text-sm">No offers for this vehicle class. Try a different filter.</p>
            </div>
          ) : (
            <div className="flex flex-col gap-4">
              {sorted.map((offer) => {
                const isKm = mode === 'ride_km';
                const isHr = mode === 'ride_hr';
                const isDl = mode === 'delivery_kg';
                const dlOffer = offer as typeof OFFERS_DELIVERY_KG[0];
                const kmOffer = offer as typeof OFFERS_RIDE_KM[0];
                const hrOffer = offer as typeof OFFERS_RIDE_HR[0];

                return (
                  <div key={offer.id}
                    className={`bg-white border rounded-2xl p-6 transition-all duration-200 ${
                      selectedOffer === offer.id
                        ? `${accentBorder} border ring-1`
                        : 'border-gray-100 hover:border-gray-200'
                    }`}>
                    <div className="flex flex-col md:flex-row md:items-center gap-5">

                      {/* Driver */}
                      <div className="flex items-center gap-4 flex-shrink-0">
                        <div className="w-14 h-14 rounded-full overflow-hidden flex-shrink-0">
                          <img src={offer.avatar} alt={offer.driver} className="w-full h-full object-cover object-top" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-bold text-gray-900">{offer.driver}</span>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${offer.badgeColor}`}>{offer.badge}</span>
                          </div>
                          <div className="flex items-center gap-1 mt-0.5">
                            <i className="ri-star-fill text-amber-400 text-xs"></i>
                            <span className="text-xs font-semibold text-gray-700">{offer.rating}</span>
                            <span className="text-xs text-gray-400">({offer.trips.toLocaleString()} trips)</span>
                          </div>
                          <p className="text-xs text-gray-500 mt-0.5">{offer.vehicle} · {offer.year}</p>
                        </div>
                      </div>

                      {/* Specs */}
                      <div className="flex items-center gap-4 md:ml-4">
                        <div className="text-center">
                          <div className="text-xs font-bold text-gray-900">{offer.vehicleClass}</div>
                          <div className="text-[10px] text-gray-400">Class</div>
                        </div>
                        {isDl ? (
                          <>
                            <div className="text-center">
                              <div className="flex items-center gap-1 text-xs font-bold text-gray-900">
                                <i className="ri-scales-line text-gray-400"></i>{dlOffer.maxWeight} kg
                              </div>
                              <div className="text-[10px] text-gray-400">Max Load</div>
                            </div>
                            <div className="text-center">
                              <div className="flex items-center gap-1 text-xs font-bold text-gray-900">
                                <i className="ri-box-3-line text-gray-400"></i>{dlOffer.maxVolume}
                              </div>
                              <div className="text-[10px] text-gray-400">Volume</div>
                            </div>
                            <div className="text-center">
                              <div className="flex items-center gap-1 text-xs font-bold text-gray-900">
                                <i className="ri-time-line text-gray-400"></i>{dlOffer.eta}
                              </div>
                              <div className="text-[10px] text-gray-400">ETA</div>
                            </div>
                          </>
                        ) : (
                          <>
                            <div className="text-center">
                              <div className="flex items-center gap-1 text-xs font-bold text-gray-900">
                                <i className="ri-group-line text-gray-400"></i>{offer.pax}
                              </div>
                              <div className="text-[10px] text-gray-400">Pax</div>
                            </div>
                            <div className="text-center">
                              <div className="flex items-center gap-1 text-xs font-bold text-gray-900">
                                <i className="ri-luggage-cart-line text-gray-400"></i>{offer.luggage}
                              </div>
                              <div className="text-[10px] text-gray-400">Bags</div>
                            </div>
                            {isKm && (
                              <div className="text-center">
                                <div className="flex items-center gap-1 text-xs font-bold text-gray-900">
                                  <i className="ri-time-line text-gray-400"></i>{kmOffer.eta}
                                </div>
                                <div className="text-[10px] text-gray-400">ETA</div>
                              </div>
                            )}
                            {isHr && (
                              <div className="text-center">
                                <div className="flex items-center gap-1 text-xs font-bold text-gray-900">
                                  <i className="ri-time-line text-gray-400"></i>{hrOffer.hours}h
                                </div>
                                <div className="text-[10px] text-gray-400">Duration</div>
                              </div>
                            )}
                          </>
                        )}
                      </div>

                      {/* Features */}
                      <div className="flex flex-wrap gap-1.5 flex-1">
                        {offer.features.map((f) => (
                          <span key={f} className="flex items-center gap-1 text-[10px] bg-gray-50 border border-gray-100 text-gray-600 px-2 py-1 rounded-full">
                            <i className={`ri-checkbox-circle-fill text-[10px] ${isDelivery ? 'text-orange-400' : 'text-emerald-400'}`}></i>
                            {f}
                          </span>
                        ))}
                      </div>

                      {/* Price + CTA */}
                      <div className="flex flex-col items-end gap-2 flex-shrink-0">
                        <div className="text-right">
                          <div className="text-2xl font-extrabold text-gray-900" style={{ fontFamily: 'Syne, sans-serif' }}>
                            ${offer.price}
                          </div>
                          <div className="text-xs text-gray-400">
                            {isKm && `$${kmOffer.basePrice} base + $${kmOffer.perKm}/km × ${kmOffer.distance} km`}
                            {isHr && `$${hrOffer.perHour}/hr × ${hrOffer.hours} hrs`}
                            {isDl && `$${dlOffer.basePrice} base + $${dlOffer.perKg}/kg × ${dlOffer.weight} kg`}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setShowBreakdown(showBreakdown === offer.id ? null : offer.id)}
                            className="text-xs font-medium text-gray-500 hover:text-gray-700 transition-colors cursor-pointer whitespace-nowrap">
                            {showBreakdown === offer.id ? 'Hide' : 'Price Breakdown'}
                          </button>
                          <button
                            onClick={() => setSelectedOffer(offer.id)}
                            className={`${accentBtn} text-white font-bold px-6 py-2.5 rounded-xl text-sm transition-colors cursor-pointer whitespace-nowrap`}>
                            {selectedOffer === offer.id ? 'Selected ✓' : isDelivery ? 'Book Delivery' : 'Select Offer'}
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Price Breakdown */}
                    {showBreakdown === offer.id && (
                      <div className="mt-5 pt-4 border-t border-gray-100">
                        <div className="bg-gray-50 rounded-xl p-4 max-w-sm ml-auto">
                          <h4 className="text-xs font-bold text-gray-700 mb-3">Price Breakdown</h4>
                          <div className="flex flex-col gap-2 text-xs">
                            {isKm && (
                              <>
                                <div className="flex justify-between text-gray-600"><span>Base fare</span><span>${kmOffer.basePrice}</span></div>
                                <div className="flex justify-between text-gray-600"><span>Distance ({kmOffer.distance} km × ${kmOffer.perKm}/km)</span><span>${(kmOffer.distance * kmOffer.perKm).toFixed(2)}</span></div>
                                <div className="flex justify-between text-gray-600"><span>Service fee</span><span>${(kmOffer.price - kmOffer.basePrice - kmOffer.distance * kmOffer.perKm).toFixed(2)}</span></div>
                              </>
                            )}
                            {isHr && (
                              <>
                                <div className="flex justify-between text-gray-600"><span>Hourly rate</span><span>${hrOffer.perHour}/hr</span></div>
                                <div className="flex justify-between text-gray-600"><span>Duration ({hrOffer.hours} hrs)</span><span>${hrOffer.perHour * hrOffer.hours}</span></div>
                                <div className="flex justify-between text-gray-600"><span>Service fee</span><span>${hrOffer.price - hrOffer.perHour * hrOffer.hours}</span></div>
                              </>
                            )}
                            {isDl && (
                              <>
                                <div className="flex justify-between text-gray-600"><span>Base fee</span><span>${dlOffer.basePrice}</span></div>
                                <div className="flex justify-between text-gray-600"><span>Weight ({dlOffer.weight} kg × ${dlOffer.perKg}/kg)</span><span>${(dlOffer.weight * dlOffer.perKg).toFixed(2)}</span></div>
                                <div className="flex justify-between text-gray-600"><span>Cargo insurance</span><span>Included</span></div>
                                <div className="flex justify-between text-gray-600"><span>Service fee</span><span>${(dlOffer.price - dlOffer.basePrice - dlOffer.weight * dlOffer.perKg).toFixed(2)}</span></div>
                              </>
                            )}
                            <div className="h-px bg-gray-200 my-1"></div>
                            <div className="flex justify-between font-bold text-gray-900"><span>Total</span><span>${offer.price}</span></div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </section>

      {/* Floating checkout bar */}
      {selectedOffer && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-gray-900 text-white rounded-2xl px-8 py-4 flex items-center gap-6">
          <div>
            <div className="text-xs text-white/60">{isDelivery ? 'Selected delivery' : 'Selected offer'}</div>
            <div className="text-sm font-bold">
              {allOffers.find((o) => o.id === selectedOffer)?.driver} · {allOffers.find((o) => o.id === selectedOffer)?.vehicle}
            </div>
          </div>
          <div className={`text-xl font-extrabold ${isDelivery ? 'text-orange-400' : 'text-emerald-400'}`} style={{ fontFamily: 'Syne, sans-serif' }}>
            ${allOffers.find((o) => o.id === selectedOffer)?.price}
          </div>
          <button
            onClick={() => navigate('/login')}
            className={`${accentBtn} text-white font-bold px-6 py-2.5 rounded-xl text-sm transition-colors cursor-pointer whitespace-nowrap`}>
            Proceed to Checkout
          </button>
        </div>
      )}

      <Footer />
    </div>
  );
}
