import { useState, FormEvent } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';

const CATEGORIES = [
  { icon: 'ri-calendar-check-line', title: 'Booking Help', desc: 'Questions about making, changing or cancelling a booking.' },
  { icon: 'ri-money-dollar-circle-line', title: 'Payments & Pricing', desc: 'Billing, refunds, pricing and payment methods.' },
  { icon: 'ri-car-line', title: 'Driver Issues', desc: 'Problems with your driver, vehicle or trip experience.' },
  { icon: 'ri-shield-check-line', title: 'Safety & Security', desc: 'Report a safety concern or suspicious activity.' },
  { icon: 'ri-user-settings-line', title: 'Account & Profile', desc: 'Login issues, profile settings and preferences.' },
  { icon: 'ri-global-line', title: 'Cross-Border Trips', desc: 'Visa, border crossing and international transfer queries.' },
];

const FAQS = [
  { q: 'How do I cancel my booking?', a: 'You can cancel your booking from your trip dashboard up to 24 hours before departure for a full refund. Cancellations within 24 hours may incur a fee.' },
  { q: 'When will I receive my refund?', a: 'Refunds are processed within 3–5 business days to your original payment method. Bank processing times may vary.' },
  { q: 'Can I change my pickup time?', a: 'Yes — contact your driver directly via the in-app chat or call our 24/7 support line to request a time change.' },
  { q: 'What if my driver doesn\'t show up?', a: 'Call our 24/7 emergency line immediately. We will reassign a driver or issue a full refund within 1 hour.' },
];

export default function SupportPage() {
  const [submitted, setSubmitted] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new URLSearchParams(new FormData(form) as unknown as Record<string, string>);
    try {
      await fetch('https://readdy.ai/api/form/d7l7638uvp0hpqmgi0dg', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: data.toString(),
      });
      setSubmitted(true);
    } catch {
      setSubmitted(true);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-white" style={{ fontFamily: 'Inter, sans-serif' }}>
      <Navbar />

      {/* Hero */}
      <section className="pt-28 pb-14 bg-gray-900 text-center">
        <div className="max-w-2xl mx-auto px-6">
          <div className="w-14 h-14 flex items-center justify-center bg-emerald-500/20 rounded-2xl mx-auto mb-5">
            <i className="ri-customer-service-2-line text-emerald-400 text-2xl"></i>
          </div>
          <h1 className="text-4xl font-extrabold text-white mb-3" style={{ fontFamily: 'Syne, sans-serif' }}>
            How Can We Help?
          </h1>
          <p className="text-white/60 text-sm mb-6">
            Our support team is available 24/7. Average response time: under 3 minutes.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <a
              href="tel:+14313342841"
              className="flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white font-semibold px-6 py-3 rounded-xl transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-phone-line"></i>
              +1 431-334-2841
            </a>
            <a
              href="https://wa.me/14313342841"
              target="_blank"
              rel="nofollow noopener"
              className="flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 text-white font-semibold px-6 py-3 rounded-xl transition-colors cursor-pointer whitespace-nowrap border border-white/20"
            >
              <i className="ri-whatsapp-line text-green-400"></i>
              WhatsApp Chat
            </a>
          </div>
        </div>
      </section>

      {/* Help Categories */}
      <section className="py-14 bg-white">
        <div className="max-w-5xl mx-auto px-6">
          <h2 className="text-xl font-bold text-gray-900 mb-8 text-center" style={{ fontFamily: 'Syne, sans-serif' }}>
            Browse Help Topics
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {CATEGORIES.map((c) => (
              <Link
                key={c.title}
                to="/faq"
                className="group flex items-start gap-4 border border-gray-100 rounded-2xl p-5 hover:border-emerald-300 hover:bg-emerald-50/30 transition-all duration-200 cursor-pointer"
              >
                <div className="w-10 h-10 flex items-center justify-center bg-emerald-50 rounded-xl flex-shrink-0 group-hover:bg-emerald-100 transition-colors">
                  <i className={`${c.icon} text-emerald-500 text-lg`}></i>
                </div>
                <div>
                  <h3 className="text-sm font-bold text-gray-900 mb-1">{c.title}</h3>
                  <p className="text-xs text-gray-500 leading-relaxed">{c.desc}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Quick FAQs */}
      <section className="py-14 bg-gray-50/60">
        <div className="max-w-3xl mx-auto px-6">
          <h2 className="text-xl font-bold text-gray-900 mb-8 text-center" style={{ fontFamily: 'Syne, sans-serif' }}>
            Quick Answers
          </h2>
          <div className="flex flex-col gap-3">
            {FAQS.map((faq, i) => (
              <div key={i} className="bg-white border border-gray-100 rounded-xl overflow-hidden">
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between px-5 py-4 text-left cursor-pointer hover:bg-gray-50 transition-colors"
                >
                  <span className="text-sm font-semibold text-gray-900">{faq.q}</span>
                  <i className={`ri-arrow-down-s-line text-gray-400 text-lg transition-transform duration-200 ${openFaq === i ? 'rotate-180' : ''}`}></i>
                </button>
                {openFaq === i && (
                  <div className="px-5 pb-4 text-sm text-gray-600 leading-relaxed border-t border-gray-50">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
          <div className="text-center mt-6">
            <Link to="/faq" className="text-sm font-semibold text-emerald-500 hover:text-emerald-600 transition-colors">
              View all FAQs <i className="ri-arrow-right-line"></i>
            </Link>
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section className="py-14 bg-white">
        <div className="max-w-2xl mx-auto px-6">
          <div className="text-center mb-8">
            <h2 className="text-xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>
              Send Us a Message
            </h2>
            <p className="text-gray-500 text-sm">We typically respond within 30 minutes.</p>
          </div>

          {submitted ? (
            <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-10 text-center">
              <div className="w-14 h-14 flex items-center justify-center bg-emerald-100 rounded-full mx-auto mb-4">
                <i className="ri-checkbox-circle-fill text-emerald-500 text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Message Sent!</h3>
              <p className="text-sm text-gray-600">Our support team will get back to you within 30 minutes.</p>
            </div>
          ) : (
            <form
              data-readdy-form
              onSubmit={handleSubmit}
              className="bg-white border border-gray-100 rounded-2xl p-8 flex flex-col gap-4"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">Full Name</label>
                  <input
                    name="full_name"
                    type="text"
                    required
                    placeholder="John Doe"
                    className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder-gray-400 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">Email Address</label>
                  <input
                    name="email"
                    type="email"
                    required
                    placeholder="john@example.com"
                    className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder-gray-400 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Topic</label>
                <select
                  name="topic"
                  required
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition cursor-pointer"
                >
                  <option value="">Select a topic...</option>
                  {CATEGORIES.map((c) => (
                    <option key={c.title} value={c.title}>{c.title}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Booking Reference (optional)</label>
                <input
                  name="booking_ref"
                  type="text"
                  placeholder="e.g. TRZ-2026-00123"
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder-gray-400 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Message</label>
                <textarea
                  name="message"
                  required
                  rows={5}
                  maxLength={500}
                  placeholder="Describe your issue in detail..."
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder-gray-400 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition resize-none"
                />
                <p className="text-xs text-gray-400 mt-1">Max 500 characters</p>
              </div>
              <button
                type="submit"
                className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-3.5 rounded-xl text-sm transition-colors cursor-pointer whitespace-nowrap"
              >
                Send Message
              </button>
            </form>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}
