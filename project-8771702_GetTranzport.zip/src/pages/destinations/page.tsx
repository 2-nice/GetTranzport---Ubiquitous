import { useState } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';

const REGIONS = ['All Regions', 'Europe', 'Africa', 'Americas', 'Asia', 'Middle East', 'Oceania'];

const ROUTES = [
  { from: 'London', to: 'Manchester', country: 'UK', region: 'Europe', distance: '335 km', time: '3h 30m', price: 'from $89', flag: '🇬🇧', type: 'City-to-City', popular: true },
  { from: 'Paris', to: 'Brussels', country: 'France / Belgium', region: 'Europe', distance: '312 km', time: '3h 15m', price: 'from $95', flag: '🇫🇷', type: 'Cross-Border', popular: true },
  { from: 'Lagos', to: 'Abuja', country: 'Nigeria', region: 'Africa', distance: '760 km', time: '7h 00m', price: 'from $65', flag: '🇳🇬', type: 'City-to-City', popular: true },
  { from: 'New York', to: 'Washington DC', country: 'USA', region: 'Americas', distance: '365 km', time: '4h 00m', price: 'from $120', flag: '🇺🇸', type: 'City-to-City', popular: true },
  { from: 'Dubai', to: 'Abu Dhabi', country: 'UAE', region: 'Middle East', distance: '140 km', time: '1h 30m', price: 'from $55', flag: '🇦🇪', type: 'City-to-City', popular: true },
  { from: 'Bangkok', to: 'Pattaya', country: 'Thailand', region: 'Asia', distance: '147 km', time: '2h 00m', price: 'from $40', flag: '🇹🇭', type: 'City-to-City', popular: true },
  { from: 'Nairobi', to: 'Mombasa', country: 'Kenya', region: 'Africa', distance: '485 km', time: '5h 30m', price: 'from $58', flag: '🇰🇪', type: 'City-to-City', popular: false },
  { from: 'Toronto', to: 'Montreal', country: 'Canada', region: 'Americas', distance: '540 km', time: '5h 30m', price: 'from $110', flag: '🇨🇦', type: 'City-to-City', popular: false },
  { from: 'Berlin', to: 'Prague', country: 'Germany / Czech', region: 'Europe', distance: '350 km', time: '3h 45m', price: 'from $88', flag: '🇩🇪', type: 'Cross-Border', popular: false },
  { from: 'Accra', to: 'Kumasi', country: 'Ghana', region: 'Africa', distance: '250 km', time: '3h 00m', price: 'from $35', flag: '🇬🇭', type: 'City-to-City', popular: false },
  { from: 'Sydney', to: 'Melbourne', country: 'Australia', region: 'Oceania', distance: '878 km', time: '9h 00m', price: 'from $195', flag: '🇦🇺', type: 'City-to-City', popular: false },
  { from: 'Mumbai', to: 'Pune', country: 'India', region: 'Asia', distance: '148 km', time: '2h 30m', price: 'from $28', flag: '🇮🇳', type: 'City-to-City', popular: false },
  { from: 'Cairo', to: 'Alexandria', country: 'Egypt', region: 'Africa', distance: '220 km', time: '2h 30m', price: 'from $32', flag: '🇪🇬', type: 'City-to-City', popular: false },
  { from: 'Amsterdam', to: 'Antwerp', country: 'Netherlands / Belgium', region: 'Europe', distance: '160 km', time: '1h 45m', price: 'from $72', flag: '🇳🇱', type: 'Cross-Border', popular: false },
  { from: 'Johannesburg', to: 'Durban', country: 'South Africa', region: 'Africa', distance: '570 km', time: '6h 00m', price: 'from $75', flag: '🇿🇦', type: 'City-to-City', popular: false },
  { from: 'Los Angeles', to: 'Las Vegas', country: 'USA', region: 'Americas', distance: '435 km', time: '4h 30m', price: 'from $130', flag: '🇺🇸', type: 'City-to-City', popular: true },
  { from: 'Singapore', to: 'Kuala Lumpur', country: 'Singapore / Malaysia', region: 'Asia', distance: '350 km', time: '4h 00m', price: 'from $85', flag: '🇸🇬', type: 'Cross-Border', popular: true },
  { from: 'Istanbul', to: 'Ankara', country: 'Turkey', region: 'Middle East', distance: '450 km', time: '4h 30m', price: 'from $70', flag: '🇹🇷', type: 'City-to-City', popular: false },
];

const SERVICE_TYPES = ['All Types', 'City-to-City', 'Cross-Border', 'Airport Transfer'];

export default function DestinationsPage() {
  const [region, setRegion] = useState('All Regions');
  const [serviceType, setServiceType] = useState('All Types');
  const [search, setSearch] = useState('');

  const filtered = ROUTES.filter((r) => {
    const matchRegion = region === 'All Regions' || r.region === region;
    const matchType = serviceType === 'All Types' || r.type === serviceType;
    const matchSearch =
      !search ||
      r.from.toLowerCase().includes(search.toLowerCase()) ||
      r.to.toLowerCase().includes(search.toLowerCase()) ||
      r.country.toLowerCase().includes(search.toLowerCase());
    return matchRegion && matchType && matchSearch;
  });

  const popular = ROUTES.filter((r) => r.popular);

  return (
    <div className="min-h-screen flex flex-col bg-white" style={{ fontFamily: 'Inter, sans-serif' }}>
      <Navbar />

      {/* Hero */}
      <section className="relative pt-28 pb-16 bg-gray-900 overflow-hidden">
        <img
          src="https://readdy.ai/api/search-image?query=aerial%20view%20of%20world%20map%20with%20glowing%20route%20lines%20connecting%20major%20cities%2C%20dark%20background%2C%20travel%20and%20transportation%20concept%2C%20cinematic%20lighting%2C%20ultra%20detailed&width=1440&height=400&seq=dest-hero-1&orientation=landscape"
          alt="Global destinations"
          className="absolute inset-0 w-full h-full object-cover object-center opacity-30"
        />
        <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
          <span className="inline-block bg-emerald-500/20 text-emerald-400 text-xs font-semibold px-3 py-1 rounded-full mb-4 border border-emerald-500/30">
            180+ Countries · 50,000+ Routes
          </span>
          <h1 className="text-4xl md:text-5xl font-extrabold text-white mb-4" style={{ fontFamily: 'Syne, sans-serif' }}>
            Our Destinations
          </h1>
          <p className="text-white/65 text-base max-w-xl mx-auto mb-8">
            Explore popular long-distance routes across every continent. Private transfers, competitive prices, verified drivers.
          </p>
          {/* Search */}
          <div className="relative max-w-md mx-auto">
            <i className="ri-search-line absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 text-base"></i>
            <input
              type="text"
              placeholder="Search city, country or route..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-3.5 rounded-xl bg-white text-sm text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-emerald-400"
            />
          </div>
        </div>
      </section>

      {/* Popular Routes */}
      <section className="py-12 bg-white">
        <div className="max-w-6xl mx-auto px-6">
          <h2 className="text-xl font-bold text-gray-900 mb-6" style={{ fontFamily: 'Syne, sans-serif' }}>
            Most Popular Routes
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {popular.map((r) => (
              <Link
                key={`${r.from}-${r.to}`}
                to="/book"
                className="group border border-gray-100 rounded-2xl p-5 hover:border-emerald-300 hover:bg-emerald-50/30 transition-all duration-200 cursor-pointer"
              >
                <div className="flex items-center justify-between mb-3">
                  <span className="text-2xl">{r.flag}</span>
                  <span className="text-[10px] font-semibold bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">{r.type}</span>
                </div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-sm font-bold text-gray-900">{r.from}</span>
                  <i className="ri-arrow-right-line text-gray-400 text-xs"></i>
                  <span className="text-sm font-bold text-gray-900">{r.to}</span>
                </div>
                <p className="text-xs text-gray-400 mb-3">{r.country}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3 text-xs text-gray-500">
                    <span><i className="ri-road-map-line mr-1"></i>{r.distance}</span>
                    <span><i className="ri-time-line mr-1"></i>{r.time}</span>
                  </div>
                  <span className="text-sm font-bold text-emerald-600">{r.price}</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* All Routes with Filters */}
      <section className="py-12 bg-gray-50/60">
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
            <h2 className="text-xl font-bold text-gray-900" style={{ fontFamily: 'Syne, sans-serif' }}>
              All Routes <span className="text-gray-400 font-normal text-base">({filtered.length})</span>
            </h2>
            <div className="flex flex-wrap gap-2">
              {/* Region filter */}
              <div className="flex flex-wrap gap-1.5">
                {REGIONS.map((r) => (
                  <button
                    key={r}
                    onClick={() => setRegion(r)}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap cursor-pointer transition-all ${
                      region === r
                        ? 'bg-emerald-500 text-white'
                        : 'bg-white border border-gray-200 text-gray-600 hover:border-emerald-300'
                    }`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Service type tabs */}
          <div className="flex gap-2 mb-6">
            {SERVICE_TYPES.map((t) => (
              <button
                key={t}
                onClick={() => setServiceType(t)}
                className={`px-4 py-2 rounded-lg text-xs font-semibold whitespace-nowrap cursor-pointer transition-all ${
                  serviceType === t
                    ? 'bg-gray-900 text-white'
                    : 'bg-white border border-gray-200 text-gray-600 hover:border-gray-400'
                }`}
              >
                {t}
              </button>
            ))}
          </div>

          {filtered.length === 0 ? (
            <div className="text-center py-16 text-gray-400">
              <i className="ri-map-pin-line text-4xl mb-3 block"></i>
              <p className="text-sm">No routes found. Try a different search or filter.</p>
            </div>
          ) : (
            <div className="flex flex-col gap-3">
              {filtered.map((r) => (
                <Link
                  key={`${r.from}-${r.to}-all`}
                  to="/book"
                  className="group bg-white border border-gray-100 rounded-xl px-5 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-emerald-300 transition-all duration-200 cursor-pointer"
                >
                  <div className="flex items-center gap-4">
                    <span className="text-xl">{r.flag}</span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-gray-900">{r.from}</span>
                        <span className="text-gray-300">→</span>
                        <span className="text-sm font-bold text-gray-900">{r.to}</span>
                        <span className="text-[10px] font-semibold bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full ml-1">{r.type}</span>
                      </div>
                      <p className="text-xs text-gray-400 mt-0.5">{r.country}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-6">
                    <div className="flex items-center gap-4 text-xs text-gray-500">
                      <span><i className="ri-road-map-line mr-1 text-gray-400"></i>{r.distance}</span>
                      <span><i className="ri-time-line mr-1 text-gray-400"></i>{r.time}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-base font-bold text-emerald-600">{r.price}</span>
                      <span className="text-xs font-semibold text-emerald-500 group-hover:gap-2 flex items-center gap-1 whitespace-nowrap">
                        Book <i className="ri-arrow-right-line"></i>
                      </span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-emerald-500">
        <div className="max-w-3xl mx-auto px-6 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-3" style={{ fontFamily: 'Syne, sans-serif' }}>
            Don&apos;t see your route?
          </h2>
          <p className="text-white/80 text-sm mb-6">
            We cover 180+ countries. Enter any origin and destination — our drivers will send you offers.
          </p>
          <Link
            to="/"
            className="inline-flex items-center gap-2 bg-white text-emerald-600 font-bold px-8 py-3.5 rounded-xl hover:bg-emerald-50 transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-search-line"></i>
            Search Your Route
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
}
