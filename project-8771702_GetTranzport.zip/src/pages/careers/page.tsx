import { useState, FormEvent } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';

const PERKS = [
  { icon: 'ri-global-line', title: 'Remote-First', desc: 'Work from anywhere. Our team spans 15+ countries.' },
  { icon: 'ri-heart-pulse-line', title: 'Health & Wellness', desc: 'Comprehensive health insurance, mental health support, and gym stipend.' },
  { icon: 'ri-calendar-event-line', title: 'Unlimited PTO', desc: 'Take the time you need. We trust you to manage your schedule.' },
  { icon: 'ri-stock-line', title: 'Equity Options', desc: 'Every full-time employee receives stock options in 2-Nice Rideshare & Carpooling Transport Services Inc.' },
  { icon: 'ri-graduation-cap-line', title: 'Learning Budget', desc: '$2,000/year for courses, conferences, books, and certifications.' },
  { icon: 'ri-parent-line', title: 'Parental Leave', desc: '16 weeks paid parental leave for all new parents.' },
];

const POSITIONS = [
  {
    title: 'Senior Backend Engineer',
    dept: 'Engineering',
    location: 'Remote · Canada / UK / USA',
    type: 'Full-time',
    desc: 'Design and build scalable APIs and microservices that power millions of rides across 150+ countries.',
  },
  {
    title: 'Product Designer',
    dept: 'Design',
    location: 'Remote · Anywhere',
    type: 'Full-time',
    desc: 'Lead the design of our passenger and driver mobile experiences. Shape the future of long-distance travel.',
  },
  {
    title: 'Driver Operations Manager',
    dept: 'Operations',
    location: 'Winnipeg, MB · Hybrid',
    type: 'Full-time',
    desc: 'Manage driver onboarding, quality assurance, and support operations across North America.',
  },
  {
    title: 'Growth Marketing Lead',
    dept: 'Marketing',
    location: 'Remote · UK / Nigeria / USA',
    type: 'Full-time',
    desc: 'Drive user acquisition and retention across our key markets. Own the full growth funnel.',
  },
  {
    title: 'Customer Support Specialist',
    dept: 'Support',
    location: 'Remote · Anywhere',
    type: 'Full-time',
    desc: 'Provide world-class support to passengers and drivers via chat, email, and phone in multiple languages.',
  },
  {
    title: 'Data Analyst',
    dept: 'Data',
    location: 'Remote · Anywhere',
    type: 'Full-time',
    desc: 'Turn complex ride and user data into actionable insights that drive product and business decisions.',
  },
];

export default function CareersPage() {
  const [submitted, setSubmitted] = useState(false);
  const [selectedRole, setSelectedRole] = useState('');

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new URLSearchParams(new FormData(form) as unknown as Record<string, string>);
    try {
      await fetch('https://readdy.ai/api/form/d7lhjjh6pfkeslelbgq0', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: data.toString(),
      });
      setSubmitted(true);
    } catch {
      setSubmitted(true);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-white" style={{ fontFamily: 'Inter, sans-serif' }}>
      <Navbar />

      {/* Hero */}
      <section className="pt-28 pb-14 bg-gray-900 text-center">
        <div className="max-w-2xl mx-auto px-6">
          <div className="w-14 h-14 flex items-center justify-center bg-emerald-500/20 rounded-2xl mx-auto mb-5">
            <i className="ri-briefcase-line text-emerald-400 text-2xl"></i>
          </div>
          <h1 className="text-4xl font-extrabold text-white mb-3" style={{ fontFamily: 'Syne, sans-serif' }}>
            Join the Team
          </h1>
          <p className="text-white/60 text-sm mb-6">
            Help us build the future of long-distance transportation. We're a remote-first team on a mission to connect the world, one ride at a time.
          </p>
          <div className="flex flex-wrap gap-3 justify-center">
            {[
              { val: '50+', label: 'Team Members' },
              { val: '15+', label: 'Countries' },
              { val: '6', label: 'Open Roles' },
            ].map((s) => (
              <div key={s.label} className="bg-white/10 border border-white/10 rounded-xl px-5 py-2.5">
                <div className="text-lg font-extrabold text-emerald-400" style={{ fontFamily: 'Syne, sans-serif' }}>{s.val}</div>
                <div className="text-xs text-white/50">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Perks */}
      <section className="py-16 bg-white">
        <div className="max-w-5xl mx-auto px-6">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>Why Work With Us</h2>
            <p className="text-gray-500 text-sm">Perks and benefits designed for a modern, distributed team.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {PERKS.map((p) => (
              <div key={p.title} className="border border-gray-100 rounded-2xl p-6 hover:border-emerald-200 hover:bg-emerald-50/20 transition-all duration-200">
                <div className="w-10 h-10 flex items-center justify-center bg-emerald-50 rounded-xl mb-4">
                  <i className={`${p.icon} text-emerald-500 text-lg`}></i>
                </div>
                <h3 className="text-sm font-bold text-gray-900 mb-2">{p.title}</h3>
                <p className="text-xs text-gray-500 leading-relaxed">{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Open Positions */}
      <section className="py-16 bg-gray-50/60">
        <div className="max-w-4xl mx-auto px-6">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>Open Positions</h2>
            <p className="text-gray-500 text-sm">Find your next challenge. All roles are open until filled.</p>
          </div>
          <div className="flex flex-col gap-3">
            {POSITIONS.map((pos) => (
              <button
                key={pos.title}
                onClick={() => setSelectedRole(pos.title)}
                className="w-full text-left bg-white border border-gray-100 rounded-2xl p-6 hover:border-emerald-300 transition-all duration-200 cursor-pointer group"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="text-sm font-bold text-gray-900 group-hover:text-emerald-600 transition-colors">{pos.title}</h3>
                    <p className="text-xs text-gray-500 mt-1">{pos.desc}</p>
                  </div>
                  <div className="flex items-center gap-3 flex-shrink-0">
                    <span className="text-xs text-gray-400 bg-gray-50 px-2.5 py-1 rounded-lg">{pos.dept}</span>
                    <span className="text-xs text-gray-400 bg-gray-50 px-2.5 py-1 rounded-lg">{pos.location}</span>
                    <span className="text-xs text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-lg font-medium">{pos.type}</span>
                    <i className="ri-arrow-right-line text-gray-300 group-hover:text-emerald-500 transition-colors"></i>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Application Form */}
      <section id="apply" className="py-16 bg-white">
        <div className="max-w-2xl mx-auto px-6">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>Apply Now</h2>
            <p className="text-gray-500 text-sm">Tell us about yourself and why you'd be a great fit. We'll respond within 5 business days.</p>
          </div>

          {submitted ? (
            <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-10 text-center">
              <div className="w-14 h-14 flex items-center justify-center bg-emerald-100 rounded-full mx-auto mb-4">
                <i className="ri-checkbox-circle-fill text-emerald-500 text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Application Submitted!</h3>
              <p className="text-sm text-gray-600">Thank you for your interest. Our hiring team will review and get back to you within 5 business days.</p>
            </div>
          ) : (
            <form
              data-readdy-form
              onSubmit={handleSubmit}
              className="bg-white border border-gray-100 rounded-2xl p-8 flex flex-col gap-4"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">Full Name</label>
                  <input name="full_name" type="text" required placeholder="John Doe" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">Email Address</label>
                  <input name="email" type="email" required placeholder="john@example.com" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition" />
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">Phone Number</label>
                  <input name="phone" type="tel" required placeholder="+1 431-334-2841" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">Location / Timezone</label>
                  <input name="location" type="text" required placeholder="Winnipeg, MB (CST)" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Position You're Applying For</label>
                <select
                  name="position"
                  required
                  value={selectedRole}
                  onChange={(e) => setSelectedRole(e.target.value)}
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition cursor-pointer"
                >
                  <option value="">Select a position...</option>
                  {POSITIONS.map((p) => (
                    <option key={p.title} value={p.title}>{p.title}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">LinkedIn / Portfolio URL</label>
                <input name="portfolio" type="url" placeholder="https://linkedin.com/in/johndoe" className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Why do you want to join GetTranzport?</label>
                <textarea name="motivation" required rows={4} maxLength={500} placeholder="Tell us about your experience and what excites you about this role..." className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition resize-none" />
                <p className="text-xs text-gray-400 mt-1">Max 500 characters</p>
              </div>
              <button type="submit" className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-3.5 rounded-xl text-sm transition-colors cursor-pointer whitespace-nowrap">
                Submit Application
              </button>
            </form>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}