import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';
import HeroSection from './components/HeroSection';
import StatsBar from './components/StatsBar';
import ReviewsSection from './components/ReviewsSection';
import FleetSection from './components/FleetSection';
import ServicesSection from './components/ServicesSection';
import HowItWorksSection from './components/HowItWorksSection';
import InnovationSection from './components/InnovationSection';
import SafetySection from './components/SafetySection';
import DestinationsSection from './components/DestinationsSection';
import WhyTranzportSection from './components/WhyTranzportSection';
import BusinessCTASection from './components/BusinessCTASection';
import AppBannerSection from './components/AppBannerSection';

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-white" style={{ fontFamily: 'Inter, sans-serif' }}>
      <Navbar />
      <main className="flex-1">
        <HeroSection />
        <StatsBar />
        <ReviewsSection />
        <FleetSection />
        <ServicesSection />
        <HowItWorksSection />
        <InnovationSection />
        <SafetySection />
        <DestinationsSection />
        <WhyTranzportSection />
        <BusinessCTASection />
        <AppBannerSection />
      </main>
      <Footer />
    </div>
  );
}
