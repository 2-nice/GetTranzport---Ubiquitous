const STATS = [
  { value: '5M+', label: 'Happy Passengers' },
  { value: '150+', label: 'Countries Covered' },
  { value: '4.9★', label: 'Average Rating' },
  { value: '50K+', label: 'Verified Drivers' },
];

export default function StatsBar() {
  return (
    <section className="bg-white border-b border-gray-100">
      <div className="max-w-5xl mx-auto px-6 py-10">
        <div className="grid grid-cols-2 md:grid-cols-4 divide-x divide-gray-100">
          {STATS.map((s, i) => (
            <div key={s.label} className={`flex flex-col items-center gap-1 py-2 ${i > 0 ? '' : ''}`}>
              <span
                className="text-[38px] font-extrabold text-emerald-500 leading-none"
                style={{ fontFamily: 'Syne, sans-serif' }}
              >
                {s.value}
              </span>
              <span className="text-sm text-gray-500 font-medium">{s.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
