import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

type TabId = 'ride_km' | 'ride_hr' | 'delivery_kg';

const TABS: { id: TabId; label: string; sub: string; icon: string }[] = [
  { id: 'ride_km',      label: 'Ride',     sub: 'per km',  icon: 'ri-route-line'         },
  { id: 'ride_hr',      label: 'Ride',     sub: 'per hr',  icon: 'ri-time-line'          },
  { id: 'delivery_kg',  label: 'Delivery', sub: 'per kg',  icon: 'ri-truck-line'         },
];

export default function HeroSection() {
  const [activeTab, setActiveTab] = useState<TabId>('ride_km');
  const navigate = useNavigate();

  // Ride/km state
  const [from, setFrom]           = useState('');
  const [to, setTo]               = useState('');
  const [date, setDate]           = useState('');
  const [returnDate, setReturnDate] = useState('');
  const [isReturn, setIsReturn]   = useState(false);
  const [passengers, setPassengers] = useState(1);

  // Ride/hr state
  const [hrLocation, setHrLocation] = useState('');
  const [hours, setHours]           = useState(4);
  const [hrDate, setHrDate]         = useState('');

  // Delivery/kg state
  const [dlFrom, setDlFrom]   = useState('');
  const [dlTo, setDlTo]       = useState('');
  const [dlDate, setDlDate]   = useState('');
  const [weight, setWeight]   = useState(10);
  const [dlDesc, setDlDesc]   = useState('');

  const handleSwap = () => { const t = from; setFrom(to); setTo(t); };

  return (
    <section className="relative w-full overflow-hidden" style={{ minHeight: '660px' }}>
      {/* Background */}
      <div className="absolute inset-0">
        <img
          src="https://gettransfer.com/img/domains/gettransfer_bg-header.jpg"
          alt="Long-distance ride hire worldwide"
          className="w-full h-full object-cover object-center scale-105"
          style={{ filter: 'brightness(0.72)' }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black/50"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center justify-center px-4 pt-32 pb-16" style={{ minHeight: '660px' }}>

        {/* Headline */}
        <p className="text-emerald-400 text-xs font-bold tracking-widest uppercase mb-3 text-center">
          150+ Countries &nbsp;·&nbsp; 50,000+ Verified Drivers
        </p>
        <h1
          className="text-4xl md:text-5xl lg:text-[56px] font-extrabold text-white text-center leading-[1.1] mb-3 max-w-3xl"
          style={{ fontFamily: 'Syne, sans-serif', textShadow: '0 2px 20px rgba(0,0,0,0.3)' }}
        >
          The professional Drivers.<br />The Best Fares.<br />
          <span className="text-emerald-400">World-wide.</span>
        </h1>
        <p className="text-white/75 text-base md:text-lg text-center mb-8 max-w-xl">
          Private long-distance transfers &amp; deliveries — city-to-city, airport, cross-border &amp; cargo. Compare offers from verified drivers worldwide.
        </p>

        {/* Booking widget */}
        <div className="w-full max-w-[660px]">

          {/* Tabs */}
          <div className="flex gap-2 mb-0">
            {TABS.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-1.5 px-5 py-2.5 rounded-t-xl text-sm font-semibold whitespace-nowrap transition-all duration-150 cursor-pointer ${
                  activeTab === tab.id
                    ? 'bg-white text-gray-900'
                    : 'bg-white/15 backdrop-blur-sm text-white border border-white/20 hover:bg-white/25'
                }`}
              >
                <i className={`${tab.icon} text-sm`}></i>
                {tab.label}
                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ml-0.5 ${
                  activeTab === tab.id
                    ? tab.id === 'delivery_kg' ? 'bg-orange-100 text-orange-600' : 'bg-emerald-100 text-emerald-600'
                    : 'bg-white/20 text-white/80'
                }`}>
                  {tab.sub}
                </span>
              </button>
            ))}
          </div>

          {/* Form panel */}
          <div className="bg-white rounded-b-2xl rounded-tr-2xl p-5">

            {/* ── RIDE / KM ── */}
            {activeTab === 'ride_km' && (
              <>
                <div className="relative border border-gray-200 rounded-xl overflow-hidden mb-3">
                  <div className="flex items-center border-b border-gray-100">
                    <div className="pl-4 pr-2"><i className="ri-map-pin-2-fill text-emerald-500 text-base"></i></div>
                    <input type="text" placeholder="From: address, airport, hotel" value={from} onChange={(e) => setFrom(e.target.value)}
                      className="flex-1 py-3.5 pr-4 text-sm text-gray-800 placeholder-gray-400 focus:outline-none bg-transparent" />
                  </div>
                  <div className="flex items-center">
                    <div className="pl-4 pr-2"><i className="ri-map-pin-line text-gray-400 text-base"></i></div>
                    <input type="text" placeholder="To: address, airport, hotel" value={to} onChange={(e) => setTo(e.target.value)}
                      className="flex-1 py-3.5 pr-12 text-sm text-gray-800 placeholder-gray-400 focus:outline-none bg-transparent" />
                    <button type="button" onClick={handleSwap}
                      className="absolute right-3 top-1/2 -translate-y-1/2 w-7 h-7 flex items-center justify-center rounded-full border border-gray-200 bg-white text-gray-400 hover:text-emerald-500 hover:border-emerald-300 transition-colors cursor-pointer">
                      <i className="ri-arrow-up-down-line text-xs"></i>
                    </button>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2 mb-4">
                  <div className="relative">
                    <i className="ri-calendar-line absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm pointer-events-none"></i>
                    <input type="date" value={date} onChange={(e) => setDate(e.target.value)}
                      className="w-full pl-8 pr-2 py-3 border border-gray-200 rounded-xl text-xs text-gray-700 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition cursor-pointer" />
                  </div>
                  <div>
                    {isReturn ? (
                      <div className="relative">
                        <i className="ri-calendar-check-line absolute left-3 top-1/2 -translate-y-1/2 text-emerald-500 text-sm pointer-events-none"></i>
                        <input type="date" value={returnDate} onChange={(e) => setReturnDate(e.target.value)}
                          className="w-full pl-8 pr-2 py-3 border border-emerald-300 rounded-xl text-xs text-gray-700 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition cursor-pointer" />
                      </div>
                    ) : (
                      <button type="button" onClick={() => setIsReturn(true)}
                        className="w-full h-full flex items-center justify-center gap-1.5 border border-dashed border-gray-300 rounded-xl text-xs text-gray-400 hover:border-emerald-400 hover:text-emerald-500 transition-colors cursor-pointer py-3 px-2 whitespace-nowrap">
                        <i className="ri-add-line text-sm"></i>Return
                      </button>
                    )}
                  </div>
                  <div className="flex items-center border border-gray-200 rounded-xl px-3 gap-1.5">
                    <i className="ri-group-line text-gray-400 text-sm flex-shrink-0"></i>
                    <span className="text-xs text-gray-500 flex-1 whitespace-nowrap">Pax</span>
                    <div className="flex items-center gap-1">
                      <button type="button" onClick={() => setPassengers(Math.max(1, passengers - 1))} className="w-5 h-5 flex items-center justify-center rounded-full border border-gray-200 text-gray-500 hover:border-emerald-400 hover:text-emerald-500 transition cursor-pointer">
                        <i className="ri-subtract-line text-[10px]"></i>
                      </button>
                      <span className="text-xs font-bold text-gray-800 w-4 text-center">{passengers}</span>
                      <button type="button" onClick={() => setPassengers(Math.min(50, passengers + 1))} className="w-5 h-5 flex items-center justify-center rounded-full border border-gray-200 text-gray-500 hover:border-emerald-400 hover:text-emerald-500 transition cursor-pointer">
                        <i className="ri-add-line text-[10px]"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </>
            )}

            {/* ── RIDE / HR ── */}
            {activeTab === 'ride_hr' && (
              <>
                <div className="flex items-center border border-gray-200 rounded-xl px-4 mb-3">
                  <i className="ri-map-pin-2-fill text-emerald-500 text-base mr-2"></i>
                  <input type="text" placeholder="Location: city, address or area" value={hrLocation} onChange={(e) => setHrLocation(e.target.value)}
                    className="flex-1 py-3.5 text-sm text-gray-800 placeholder-gray-400 focus:outline-none bg-transparent" />
                </div>
                <div className="grid grid-cols-2 gap-2 mb-3">
                  <div className="relative">
                    <i className="ri-calendar-line absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm pointer-events-none"></i>
                    <input type="date" value={hrDate} onChange={(e) => setHrDate(e.target.value)}
                      className="w-full pl-8 pr-2 py-3 border border-gray-200 rounded-xl text-xs text-gray-700 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition cursor-pointer" />
                  </div>
                  <div className="flex items-center border border-gray-200 rounded-xl px-4 gap-3">
                    <i className="ri-time-line text-emerald-500 text-base flex-shrink-0"></i>
                    <span className="text-xs text-gray-500 whitespace-nowrap">Duration</span>
                    <div className="flex items-center gap-2 ml-auto">
                      <button type="button" onClick={() => setHours(Math.max(1, hours - 1))} className="w-6 h-6 flex items-center justify-center rounded-full border border-gray-200 text-gray-500 hover:border-emerald-400 hover:text-emerald-500 transition cursor-pointer">
                        <i className="ri-subtract-line text-xs"></i>
                      </button>
                      <span className="text-sm font-bold text-gray-800 w-14 text-center">{hours} hr{hours > 1 ? 's' : ''}</span>
                      <button type="button" onClick={() => setHours(Math.min(24, hours + 1))} className="w-6 h-6 flex items-center justify-center rounded-full border border-gray-200 text-gray-500 hover:border-emerald-400 hover:text-emerald-500 transition cursor-pointer">
                        <i className="ri-add-line text-xs"></i>
                      </button>
                    </div>
                  </div>
                </div>
                <div className="flex items-center border border-gray-200 rounded-xl px-3 gap-1.5 py-2.5 mb-4">
                  <i className="ri-group-line text-gray-400 text-sm flex-shrink-0"></i>
                  <span className="text-xs text-gray-500 flex-1">Passengers</span>
                  <div className="flex items-center gap-1">
                    <button type="button" onClick={() => setPassengers(Math.max(1, passengers - 1))} className="w-5 h-5 flex items-center justify-center rounded-full border border-gray-200 text-gray-500 hover:border-emerald-400 hover:text-emerald-500 transition cursor-pointer">
                      <i className="ri-subtract-line text-[10px]"></i>
                    </button>
                    <span className="text-xs font-bold text-gray-800 w-4 text-center">{passengers}</span>
                    <button type="button" onClick={() => setPassengers(Math.min(50, passengers + 1))} className="w-5 h-5 flex items-center justify-center rounded-full border border-gray-200 text-gray-500 hover:border-emerald-400 hover:text-emerald-500 transition cursor-pointer">
                      <i className="ri-add-line text-[10px]"></i>
                    </button>
                  </div>
                </div>
              </>
            )}

            {/* ── DELIVERY / KG ── */}
            {activeTab === 'delivery_kg' && (
              <>
                <div className="relative border border-gray-200 rounded-xl overflow-hidden mb-3">
                  <div className="flex items-center border-b border-gray-100">
                    <div className="pl-4 pr-2"><i className="ri-map-pin-2-fill text-orange-500 text-base"></i></div>
                    <input type="text" placeholder="Pickup: address, warehouse, depot" value={dlFrom} onChange={(e) => setDlFrom(e.target.value)}
                      className="flex-1 py-3.5 pr-4 text-sm text-gray-800 placeholder-gray-400 focus:outline-none bg-transparent" />
                  </div>
                  <div className="flex items-center">
                    <div className="pl-4 pr-2"><i className="ri-map-pin-line text-gray-400 text-base"></i></div>
                    <input type="text" placeholder="Delivery: address, business, home" value={dlTo} onChange={(e) => setDlTo(e.target.value)}
                      className="flex-1 py-3.5 pr-4 text-sm text-gray-800 placeholder-gray-400 focus:outline-none bg-transparent" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 mb-3">
                  <div className="relative">
                    <i className="ri-calendar-line absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm pointer-events-none"></i>
                    <input type="date" value={dlDate} onChange={(e) => setDlDate(e.target.value)}
                      className="w-full pl-8 pr-2 py-3 border border-gray-200 rounded-xl text-xs text-gray-700 focus:outline-none focus:border-orange-400 focus:ring-1 focus:ring-orange-400 transition cursor-pointer" />
                  </div>
                  <div className="flex items-center border border-gray-200 rounded-xl px-4 gap-3">
                    <i className="ri-scales-line text-orange-500 text-base flex-shrink-0"></i>
                    <span className="text-xs text-gray-500 whitespace-nowrap">Weight</span>
                    <div className="flex items-center gap-2 ml-auto">
                      <button type="button" onClick={() => setWeight(Math.max(1, weight - 5))} className="w-6 h-6 flex items-center justify-center rounded-full border border-gray-200 text-gray-500 hover:border-orange-400 hover:text-orange-500 transition cursor-pointer">
                        <i className="ri-subtract-line text-xs"></i>
                      </button>
                      <span className="text-sm font-bold text-gray-800 w-14 text-center">{weight} kg</span>
                      <button type="button" onClick={() => setWeight(Math.min(5000, weight + 5))} className="w-6 h-6 flex items-center justify-center rounded-full border border-gray-200 text-gray-500 hover:border-orange-400 hover:text-orange-500 transition cursor-pointer">
                        <i className="ri-add-line text-xs"></i>
                      </button>
                    </div>
                  </div>
                </div>
                <div className="flex items-center border border-gray-200 rounded-xl px-4 mb-4">
                  <i className="ri-box-3-line text-gray-400 text-base mr-2"></i>
                  <input type="text" placeholder="Cargo description (e.g. electronics, furniture, documents)" value={dlDesc} onChange={(e) => setDlDesc(e.target.value)}
                    className="flex-1 py-3 text-sm text-gray-800 placeholder-gray-400 focus:outline-none bg-transparent" />
                </div>
              </>
            )}

            {/* CTA */}
            <button
              type="button"
              onClick={() => navigate('/book')}
              className={`w-full font-bold py-4 rounded-xl text-[15px] transition-colors duration-150 cursor-pointer whitespace-nowrap text-white ${
                activeTab === 'delivery_kg'
                  ? 'bg-orange-500 hover:bg-orange-600 active:bg-orange-700'
                  : 'bg-emerald-500 hover:bg-emerald-600 active:bg-emerald-700'
              }`}
            >
              {activeTab === 'delivery_kg' ? 'Get Delivery Quotes' : 'Get Offers'}
            </button>
          </div>
        </div>

        {/* Trust chips */}
        <div className="flex flex-wrap justify-center gap-2 mt-6 max-w-2xl">
          {[
            'Ride/km · Ride/hr · Delivery/kg',
            'Tender-Based Pricing',
            'View Driver Before Paying',
            'Full Refund Cancellation',
            'Up to 60 Min Free Waiting',
            '50,000+ Verified Drivers',
          ].map((chip) => (
            <span key={chip}
              className="flex items-center gap-1.5 bg-white/10 backdrop-blur-sm border border-white/15 text-white/85 text-xs font-medium px-3 py-1.5 rounded-full whitespace-nowrap">
              <i className="ri-checkbox-circle-fill text-emerald-400 text-xs"></i>
              {chip}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
