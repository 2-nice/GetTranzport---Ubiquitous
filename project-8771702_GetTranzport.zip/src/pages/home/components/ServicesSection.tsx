import { Link } from 'react-router-dom';

const SERVICES = [
  {
    icon: 'ri-route-line',
    title: 'City-to-City Rides',
    desc: 'Direct private transfers between cities. No stops, no shared rides — your driver, your schedule.',
    iconBg: 'bg-emerald-50',
    iconColor: 'text-emerald-500',
  },
  {
    icon: 'ri-flight-takeoff-line',
    title: 'Airport Pick-up & Drop-off',
    desc: 'Meet & greet at arrivals with a name board. Flight tracking + up to 60 min free waiting.',
    iconBg: 'bg-sky-50',
    iconColor: 'text-sky-500',
  },
  {
    icon: 'ri-map-2-line',
    title: 'Across-State / Province',
    desc: 'Long-haul rides across states and provinces with professional drivers who know the route.',
    iconBg: 'bg-amber-50',
    iconColor: 'text-amber-500',
  },
  {
    icon: 'ri-global-line',
    title: 'Cross-Border Transfers',
    desc: 'Seamless international transfers. Experienced drivers who handle all border formalities.',
    iconBg: 'bg-rose-50',
    iconColor: 'text-rose-500',
  },
];

export default function ServicesSection() {
  return (
    <section className="py-16 bg-gray-50/60">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-10">
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>
            Every Long-Distance Journey, Covered
          </h2>
          <p className="text-gray-500 text-sm max-w-lg mx-auto">
            From airport runs to cross-border journeys — GetTranzport covers every long-distance passenger need.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {SERVICES.map((s) => (
            <Link
              key={s.title}
              to="/book"
              className="bg-white rounded-2xl p-6 border border-gray-100 hover:border-emerald-200 transition-all duration-200 cursor-pointer group block"
            >
              <div className={`w-11 h-11 flex items-center justify-center rounded-xl ${s.iconBg} mb-4 group-hover:scale-110 transition-transform duration-200`}>
                <i className={`${s.icon} ${s.iconColor} text-xl`}></i>
              </div>
              <h3 className="text-sm font-bold text-gray-900 mb-2">{s.title}</h3>
              <p className="text-xs text-gray-500 leading-relaxed">{s.desc}</p>
              <div className="mt-4 flex items-center gap-1 text-xs font-semibold text-emerald-500 group-hover:gap-2 transition-all">
                Book now <i className="ri-arrow-right-line"></i>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
