const PILLARS = [
  {
    icon: 'ri-user-search-line',
    title: 'Driver Background Checks',
    desc: 'Every driver undergoes criminal background screening, licence verification, and vehicle roadworthiness inspection before joining the platform.',
    stat: '100%',
    statLabel: 'of drivers screened',
  },
  {
    icon: 'ri-shield-keyhole-line',
    title: 'Identity Verification at Pickup',
    desc: 'Passengers confirm driver identity via face-match photo before entering the vehicle. No match, no ride — your safety is non-negotiable.',
    stat: '3-step',
    statLabel: 'verification process',
  },
  {
    icon: 'ri-record-circle-line',
    title: 'Trip Recording & Monitoring',
    desc: 'All trips are logged with GPS data, timestamps, and route history. Our 24/7 operations team monitors for anomalies in real time.',
    stat: '24/7',
    statLabel: 'live monitoring',
  },
  {
    icon: 'ri-customer-service-2-line',
    title: 'Emergency Response',
    desc: 'One tap on the in-app panic button connects you to our emergency response team and shares your live location with local authorities.',
    stat: '<90s',
    statLabel: 'average response time',
  },
];

export default function SafetySection() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-14 items-center">
          {/* Left text */}
          <div className="flex-1 max-w-lg">
            <span className="inline-flex items-center gap-1.5 text-rose-500 text-xs font-bold tracking-widest uppercase mb-3">
              <i className="ri-shield-star-line text-sm"></i>
              Safety & Trust
            </span>
            <h2 className="text-3xl md:text-4xl font-extrabold text-gray-900 mb-4" style={{ fontFamily: 'Syne, sans-serif' }}>
              Your Safety Is Our<br />
              <span className="text-emerald-500">Top Priority</span>
            </h2>
            <p className="text-gray-500 text-sm leading-relaxed mb-8">
              Long-distance travel demands a higher standard of safety. GetTranzport's multi-layer SafeGuard™ system protects every passenger from booking to arrival — across every border, every route, every time.
            </p>
            <div className="flex flex-col gap-3">
              {['ISO 27001 certified data security', 'GDPR & global privacy compliant', 'Partnered with local emergency services in 80+ countries', 'All payments secured with 256-bit SSL encryption'].map((item) => (
                <div key={item} className="flex items-center gap-2.5 text-sm text-gray-700">
                  <i className="ri-checkbox-circle-fill text-emerald-500 text-base flex-shrink-0"></i>
                  {item}
                </div>
              ))}
            </div>
          </div>

          {/* Right grid */}
          <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {PILLARS.map((p) => (
              <div key={p.title} className="bg-gray-50 rounded-2xl p-5 border border-gray-100 hover:border-emerald-200 transition-colors">
                <div className="w-10 h-10 flex items-center justify-center rounded-xl bg-white border border-gray-100 mb-3">
                  <i className={`${p.icon} text-emerald-500 text-lg`}></i>
                </div>
                <div className="flex items-baseline gap-1.5 mb-1">
                  <span className="text-xl font-extrabold text-gray-900" style={{ fontFamily: 'Syne, sans-serif' }}>{p.stat}</span>
                  <span className="text-xs text-gray-400">{p.statLabel}</span>
                </div>
                <h3 className="text-sm font-bold text-gray-900 mb-1">{p.title}</h3>
                <p className="text-xs text-gray-500 leading-relaxed">{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
