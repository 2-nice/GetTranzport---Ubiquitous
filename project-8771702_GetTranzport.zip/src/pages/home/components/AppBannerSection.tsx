export default function AppBannerSection() {
  return (
    <section className="bg-gray-900 overflow-hidden">
      <div className="max-w-6xl mx-auto px-6">
        <div className="flex flex-col lg:flex-row items-end gap-0">

          {/* Phone mockup — flush bottom */}
          <div className="order-2 lg:order-1 flex-shrink-0 flex items-end self-end">
            <img
              src="https://gettransfer.com/img/phone.png"
              alt="GetTranzport app"
              className="h-64 md:h-72 w-auto object-contain object-bottom select-none"
              draggable={false}
            />
          </div>

          {/* Text block */}
          <div className="flex-1 order-1 lg:order-2 py-14 lg:pl-12 text-center lg:text-left">
            <h2 className="text-3xl md:text-4xl font-extrabold text-white mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>
              Download <span className="text-emerald-400">GetTranzport App</span>
            </h2>
            <p className="text-gray-400 text-sm mb-6 max-w-sm mx-auto lg:mx-0">
              Book transfers on the go with our award-winning mobile app.
            </p>

            <ul className="flex flex-col gap-2 mb-8 items-center lg:items-start">
              {['Easy booking', 'Real-time tracking', 'Offline mode'].map((f) => (
                <li key={f} className="flex items-center gap-2 text-sm text-gray-300">
                  <i className="ri-checkbox-circle-fill text-emerald-400 text-base flex-shrink-0"></i>
                  {f}
                </li>
              ))}
            </ul>

            <div className="flex flex-col sm:flex-row gap-3 justify-center lg:justify-start">
              <a
                href="https://gettransfer.onelink.me/swC4/f0209212"
                target="_blank"
                rel="nofollow noopener"
                className="flex items-center gap-3 bg-white text-gray-900 px-5 py-3 rounded-xl text-sm font-semibold hover:bg-gray-100 transition-colors cursor-pointer whitespace-nowrap"
              >
                <i className="ri-apple-line text-xl"></i>
                <div className="text-left">
                  <div className="text-[10px] text-gray-500 leading-none">Download on the</div>
                  <div className="text-sm font-bold leading-tight">App Store</div>
                </div>
              </a>
              <a
                href="https://gettransfer.onelink.me/swC4/f0209212"
                target="_blank"
                rel="nofollow noopener"
                className="flex items-center gap-3 bg-white text-gray-900 px-5 py-3 rounded-xl text-sm font-semibold hover:bg-gray-100 transition-colors cursor-pointer whitespace-nowrap"
              >
                <i className="ri-google-play-line text-xl"></i>
                <div className="text-left">
                  <div className="text-[10px] text-gray-500 leading-none">Get it on</div>
                  <div className="text-sm font-bold leading-tight">Google Play</div>
                </div>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
