import { Link } from 'react-router-dom';

const ROUTES = [
  { from: 'New York',      to: 'Washington D.C.', distance: '365 km', time: '4h',   price: 'From $89',      flag: '🇺🇸' },
  { from: 'London',        to: 'Manchester',      distance: '320 km', time: '3.5h', price: 'From £65',      flag: '🇬🇧' },
  { from: 'Lagos',         to: 'Abuja',           distance: '760 km', time: '7h',   price: 'From ₦45,000',  flag: '🇳🇬' },
  { from: 'Dubai',         to: 'Abu Dhabi',       distance: '140 km', time: '1.5h', price: 'From AED 180',  flag: '🇦🇪' },
  { from: 'Paris',         to: 'Brussels',        distance: '310 km', time: '3h',   price: 'From €75',      flag: '🇫🇷' },
  { from: 'Mumbai',        to: 'Pune',            distance: '150 km', time: '2.5h', price: 'From ₹1,800',   flag: '🇮🇳' },
  { from: 'Nairobi',       to: 'Mombasa',         distance: '480 km', time: '5h',   price: 'From KES 4,500',flag: '🇰🇪' },
  { from: 'Toronto',       to: 'Montreal',        distance: '540 km', time: '5.5h', price: 'From CA$120',   flag: '🇨🇦' },
  { from: 'Buenos Aires',  to: 'Montevideo',      distance: '230 km', time: '3h',   price: 'From $55',      flag: '🇦🇷' },
];

export default function DestinationsSection() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-10">
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>
            Popular Routes
          </h2>
          <p className="text-gray-500 text-sm">Frequently booked long-distance rides across 150+ countries.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {ROUTES.map((r) => (
            <Link
              key={`${r.from}-${r.to}`}
              to="/book"
              className="group flex items-center gap-4 border border-gray-100 rounded-xl p-4 hover:border-emerald-200 hover:bg-emerald-50/10 transition-all duration-200"
            >
              {/* Route dots */}
              <div className="flex flex-col items-center gap-1 flex-shrink-0">
                <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                <div className="w-px h-5 bg-gray-200"></div>
                <div className="w-2 h-2 rounded-full border-2 border-emerald-500"></div>
              </div>

              {/* Cities */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 mb-1">
                  <span className="text-sm font-semibold text-gray-900 truncate">{r.from}</span>
                  <span className="text-base leading-none">{r.flag}</span>
                </div>
                <span className="text-sm font-semibold text-gray-900 truncate block">{r.to}</span>
              </div>

              {/* Meta */}
              <div className="flex flex-col items-end gap-1 flex-shrink-0">
                <span className="text-sm font-bold text-emerald-600 whitespace-nowrap">{r.price}</span>
                <div className="flex items-center gap-2 text-[11px] text-gray-400">
                  <span>{r.distance}</span>
                  <span>·</span>
                  <span>{r.time}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div className="text-center mt-8">
          <Link to="/destinations" className="inline-flex items-center gap-2 border border-gray-200 text-gray-600 hover:border-emerald-300 hover:text-emerald-600 font-medium text-sm px-6 py-2.5 rounded-xl transition-colors cursor-pointer whitespace-nowrap">
            View All Destinations
            <i className="ri-arrow-right-line"></i>
          </Link>
        </div>
      </div>
    </section>
  );
}
