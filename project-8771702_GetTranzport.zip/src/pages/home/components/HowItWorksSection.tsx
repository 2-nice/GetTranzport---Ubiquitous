const STEPS = [
  { icon: 'ri-map-pin-add-line', title: 'Enter Your Route', desc: 'Type pickup, drop-off, date and number of passengers.' },
  { icon: 'ri-car-line',         title: 'Compare Offers',   desc: 'Browse drivers and vehicle classes. Compare prices and ratings.' },
  { icon: 'ri-bank-card-line',   title: 'Book & Pay',       desc: 'Confirm with secure payment. Get instant confirmation.' },
  { icon: 'ri-steering-2-line',  title: 'Enjoy the Ride',   desc: 'Driver meets you at pickup. Sit back and travel in comfort.' },
];

export default function HowItWorksSection() {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>
            How GetTranzport Works
          </h2>
          <p className="text-gray-500 text-sm">Booking your long-distance ride takes less than 2 minutes.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 relative">
          <div className="hidden lg:block absolute top-9 left-[12.5%] right-[12.5%] h-px bg-gray-100 z-0"></div>
          {STEPS.map((step, i) => (
            <div key={step.title} className="relative z-10 flex flex-col items-center text-center">
              <div className="relative mb-5">
                <div className="w-[72px] h-[72px] flex items-center justify-center rounded-2xl bg-gray-50 border border-gray-100">
                  <i className={`${step.icon} text-emerald-500 text-2xl`}></i>
                </div>
                <span className="absolute -top-2 -right-2 w-5 h-5 flex items-center justify-center bg-emerald-500 text-white text-[10px] font-bold rounded-full">
                  {i + 1}
                </span>
              </div>
              <h3 className="text-sm font-bold text-gray-900 mb-1.5">{step.title}</h3>
              <p className="text-xs text-gray-500 leading-relaxed">{step.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
