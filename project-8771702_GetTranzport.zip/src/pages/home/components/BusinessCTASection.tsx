import { Link } from 'react-router-dom';

export default function BusinessCTASection() {
  return (
    <section className="py-16 bg-gray-50/60">
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">

          {/* For Business */}
          <div className="bg-gray-900 rounded-2xl p-7 flex flex-col gap-4 col-span-1 md:col-span-1">
            <div className="w-10 h-10 flex items-center justify-center rounded-xl bg-white/10">
              <i className="ri-briefcase-4-line text-white text-lg"></i>
            </div>
            <div>
              <span className="text-xs font-bold text-emerald-400 uppercase tracking-widest">For Business</span>
              <h3 className="text-lg font-extrabold text-white mt-1 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>Corporate Travel Management</h3>
              <p className="text-gray-400 text-xs leading-relaxed">Centralised billing, travel policy controls, and dedicated account management for teams of all sizes.</p>
            </div>
            <Link to="/for-business" className="mt-auto inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition-colors cursor-pointer whitespace-nowrap w-fit">
              Explore Business Plans <i className="ri-arrow-right-line"></i>
            </Link>
          </div>

          {/* For Drivers */}
          <div className="bg-emerald-500 rounded-2xl p-7 flex flex-col gap-4">
            <div className="w-10 h-10 flex items-center justify-center rounded-xl bg-white/20">
              <i className="ri-steering-2-line text-white text-lg"></i>
            </div>
            <div>
              <span className="text-xs font-bold text-emerald-100 uppercase tracking-widest">For Drivers</span>
              <h3 className="text-lg font-extrabold text-white mt-1 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>Earn More on Every Long-Distance Trip</h3>
              <p className="text-emerald-100 text-xs leading-relaxed">Join 50,000+ verified drivers. Set your own rates, choose your trips, and get paid fast.</p>
            </div>
            <Link to="/for-drivers" className="mt-auto inline-flex items-center gap-2 bg-white text-emerald-700 hover:bg-emerald-50 text-xs font-bold px-4 py-2.5 rounded-xl transition-colors cursor-pointer whitespace-nowrap w-fit">
              Become a Driver <i className="ri-arrow-right-line"></i>
            </Link>
          </div>

          {/* For Agents */}
          <div className="bg-white rounded-2xl p-7 flex flex-col gap-4 border border-gray-100">
            <div className="w-10 h-10 flex items-center justify-center rounded-xl bg-gray-50 border border-gray-100">
              <i className="ri-user-star-line text-gray-700 text-lg"></i>
            </div>
            <div>
              <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">For Agents</span>
              <h3 className="text-lg font-extrabold text-gray-900 mt-1 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>Resell GetTranzport & Earn Commission</h3>
              <p className="text-gray-500 text-xs leading-relaxed">Travel agents and OTAs earn up to 12% commission on every booking made through your referral link.</p>
            </div>
            <Link to="/for-agents" className="mt-auto inline-flex items-center gap-2 border border-gray-200 text-gray-700 hover:border-emerald-300 hover:text-emerald-600 text-xs font-bold px-4 py-2.5 rounded-xl transition-colors cursor-pointer whitespace-nowrap w-fit">
              Join as Agent <i className="ri-arrow-right-line"></i>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
