const FEATURES = [
  { icon: 'ri-shield-check-line',      title: 'Vetted & Verified Drivers',    desc: 'Every driver passes background checks, vehicle inspections, and licence verification.', iconBg: 'bg-emerald-50', iconColor: 'text-emerald-500' },
  { icon: 'ri-price-tag-3-line',       title: 'Fixed Prices, No Surprises',   desc: 'The price you see is the price you pay. No surge pricing, no hidden fees — ever.',       iconBg: 'bg-sky-50',     iconColor: 'text-sky-500'     },
  { icon: 'ri-time-line',              title: '60 Min Free Waiting',          desc: 'Drivers wait up to 60 minutes at no extra charge for airport pickups.',                   iconBg: 'bg-amber-50',   iconColor: 'text-amber-500'   },
  { icon: 'ri-refund-2-line',          title: 'Free Cancellation',            desc: 'Cancel your booking for free up to 24 hours before your scheduled pickup.',               iconBg: 'bg-rose-50',    iconColor: 'text-rose-500'    },
  { icon: 'ri-customer-service-2-line',title: '24/7 Support',                 desc: 'Our support team is available around the clock via chat, email, and phone.',              iconBg: 'bg-violet-50',  iconColor: 'text-violet-500'  },
  { icon: 'ri-global-line',            title: '150+ Countries',               desc: 'GetTranzport operates in over 150 countries. Wherever you go, we have a driver ready.',      iconBg: 'bg-teal-50',    iconColor: 'text-teal-500'    },
];

export default function WhyGetTranzportSection() {
  return (
    <section className="py-16 bg-gray-50/60">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-10">
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>
            Why Choose GetTranzport
          </h2>
          <p className="text-gray-500 text-sm max-w-lg mx-auto">
            Built around the things that matter most to long-distance travellers.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {FEATURES.map((f) => (
            <div key={f.title} className="bg-white rounded-2xl border border-gray-100 p-5 flex gap-4 hover:border-emerald-200 transition-all duration-200">
              <div className={`flex-shrink-0 w-10 h-10 flex items-center justify-center rounded-xl ${f.iconBg}`}>
                <i className={`${f.icon} ${f.iconColor} text-lg`}></i>
              </div>
              <div>
                <h3 className="text-sm font-bold text-gray-900 mb-1">{f.title}</h3>
                <p className="text-xs text-gray-500 leading-relaxed">{f.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
