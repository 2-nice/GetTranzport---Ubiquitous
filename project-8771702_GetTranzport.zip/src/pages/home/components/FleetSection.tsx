import { useNavigate } from 'react-router-dom';

const FLEET = [
  { label: 'Economy',  img: 'https://gettransfer.com/common/transport_types/economy_small.png?v=2026',  pax: 'Up to 3' },
  { label: 'Comfort',  img: 'https://gettransfer.com/common/transport_types/comfort_small.png?v=2026',  pax: 'Up to 3' },
  { label: 'Business', img: 'https://gettransfer.com/common/transport_types/business_small.png?v=2026', pax: 'Up to 3' },
  { label: 'Premium',  img: 'https://gettransfer.com/common/transport_types/premium_small.png?v=2026',  pax: 'Up to 3' },
  { label: 'VIP',      img: 'https://gettransfer.com/common/transport_types/limousine_small.png?v=2026',pax: 'Up to 3' },
  { label: 'SUV',      img: 'https://gettransfer.com/common/transport_types/suv_small.png?v=2026',      pax: 'Up to 5' },
  { label: 'Van',      img: 'https://gettransfer.com/common/transport_types/van_small.png?v=2026',      pax: 'Up to 8' },
  { label: 'Minibus',  img: 'https://gettransfer.com/common/transport_types/minibus_small.png?v=2026',  pax: 'Up to 16' },
  { label: 'Bus',      img: 'https://gettransfer.com/common/transport_types/bus_small.png?v=2026',      pax: 'Up to 50' },
  { label: 'Delivery', img: 'https://gettransfer.com/common/transport_types/van_small.png?v=2026',      pax: 'Cargo' },
];

export default function FleetSection() {
  const navigate = useNavigate();
  return (
    <section className="py-16 bg-white" id="our_fleet">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-10">
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>
            FLEET: Choose Vehicle Type By Your Desired Service
          </h2>
          <p className="text-gray-500 text-sm">From everyday comfort to VIP — choose the perfect match for your trip.</p>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-10 gap-3">
          {FLEET.map((v) => (
            <button
              key={v.label}
              type="button"
              onClick={() => navigate('/book')}
              className="group flex flex-col items-center border border-gray-100 rounded-xl py-4 px-2 hover:border-emerald-300 hover:bg-emerald-50/20 transition-all duration-200 cursor-pointer w-full"
            >
              <div className="w-full h-[68px] flex items-center justify-center mb-2">
                <img
                  src={v.img}
                  alt={v.label}
                  className="h-14 w-auto object-contain group-hover:scale-105 transition-transform duration-200"
                />
              </div>
              <span className="text-xs font-semibold text-gray-800 text-center">{v.label}</span>
              {v.pax === 'Cargo' && (
                <span className="text-[9px] text-amber-600 font-semibold bg-amber-50 px-1.5 py-0.5 rounded-full mt-0.5">Cargo</span>
              )}
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
