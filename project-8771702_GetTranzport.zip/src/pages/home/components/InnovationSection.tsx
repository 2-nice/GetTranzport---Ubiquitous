import { useState } from 'react';
import { Link } from 'react-router-dom';

const FEATURES = [
  {
    id: 'ai',
    icon: 'ri-brain-line',
    tag: 'AI-Powered',
    title: 'Smart Route Intelligence',
    desc: 'Our AI engine analyses real-time traffic, border wait times, road conditions, and weather across 150+ countries to recommend the fastest, safest route for every long-distance journey.',
    bullets: ['Real-time traffic & border delay prediction', 'Dynamic ETA recalculation en route', 'Alternate route suggestions mid-trip'],
    color: 'emerald',
  },
  {
    id: 'track',
    icon: 'ri-map-pin-time-line',
    tag: 'Live Tracking',
    title: 'Real-Time GPS Tracking',
    desc: 'Share your live trip link with family or colleagues. Track your driver from dispatch to arrival on an interactive map — no app download required for trip sharing.',
    bullets: ['Live driver location on interactive map', 'Shareable trip link for loved ones', 'Arrival notifications via SMS & email'],
    color: 'sky',
  },
  {
    id: 'safety',
    icon: 'ri-shield-star-line',
    tag: 'Safety First',
    title: 'GetTranzport SafeGuard™',
    desc: 'Every ride is monitored by our SafeGuard system. Panic button, trip recording, driver identity verification at pickup, and 24/7 emergency response coordination.',
    bullets: ['In-app panic button with instant response', 'Driver face-match verification at pickup', 'Automatic trip recording & incident logging'],
    color: 'rose',
  },
  {
    id: 'price',
    icon: 'ri-auction-line',
    tag: 'Tender Pricing',
    title: 'Competitive Tender System',
    desc: 'Post your trip and let verified drivers compete for your booking. You choose the best price, rating, and vehicle — not the other way around. Prices drop, quality rises.',
    bullets: ['Drivers bid on your trip in real time', 'Compare price, rating & vehicle side-by-side', 'Lock in your preferred driver before paying'],
    color: 'amber',
  },
];

const COLOR_MAP: Record<string, { bg: string; text: string; border: string; pill: string; pillText: string; dot: string }> = {
  emerald: { bg: 'bg-emerald-50', text: 'text-emerald-600', border: 'border-emerald-200', pill: 'bg-emerald-100', pillText: 'text-emerald-700', dot: 'bg-emerald-500' },
  sky:     { bg: 'bg-sky-50',     text: 'text-sky-600',     border: 'border-sky-200',     pill: 'bg-sky-100',     pillText: 'text-sky-700',     dot: 'bg-sky-500'     },
  rose:    { bg: 'bg-rose-50',    text: 'text-rose-600',    border: 'border-rose-200',    pill: 'bg-rose-100',    pillText: 'text-rose-700',    dot: 'bg-rose-500'    },
  amber:   { bg: 'bg-amber-50',   text: 'text-amber-600',   border: 'border-amber-200',   pill: 'bg-amber-100',   pillText: 'text-amber-700',   dot: 'bg-amber-500'   },
};

export default function InnovationSection() {
  const [active, setActive] = useState('ai');
  const feature = FEATURES.find((f) => f.id === active)!;
  const c = COLOR_MAP[feature.color];

  return (
    <section className="py-20 bg-gray-950 overflow-hidden">
      <div className="max-w-6xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-14">
          <span className="inline-flex items-center gap-1.5 text-emerald-400 text-xs font-bold tracking-widest uppercase mb-3">
            <i className="ri-sparkling-line text-sm"></i>
            Platform Innovation
          </span>
          <h2 className="text-3xl md:text-4xl font-extrabold text-white mb-3" style={{ fontFamily: 'Syne, sans-serif' }}>
            Technology That Puts You First
          </h2>
          <p className="text-gray-400 text-sm max-w-xl mx-auto">
            GetTranzport isn't just a booking platform — it's a full-stack travel intelligence system built for the modern long-distance passenger.
          </p>
        </div>

        {/* Tab selector */}
        <div className="flex flex-wrap justify-center gap-2 mb-10">
          {FEATURES.map((f) => {
            const fc = COLOR_MAP[f.color];
            return (
              <button
                key={f.id}
                onClick={() => setActive(f.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold whitespace-nowrap transition-all duration-200 cursor-pointer border ${
                  active === f.id
                    ? `${fc.bg} ${fc.text} ${fc.border}`
                    : 'bg-white/5 text-gray-400 border-white/10 hover:bg-white/10 hover:text-white'
                }`}
              >
                <i className={`${f.icon} text-base`}></i>
                {f.tag}
              </button>
            );
          })}
        </div>

        {/* Feature panel */}
        <div className={`rounded-3xl border ${c.border} ${c.bg} p-8 md:p-10 transition-all duration-300`}>
          <div className="flex flex-col lg:flex-row gap-10 items-start">
            {/* Left */}
            <div className="flex-1">
              <div className={`inline-flex items-center gap-2 ${c.pill} ${c.pillText} text-xs font-bold px-3 py-1 rounded-full mb-4`}>
                <i className={`${feature.icon} text-sm`}></i>
                {feature.tag}
              </div>
              <h3 className="text-2xl md:text-3xl font-extrabold text-gray-900 mb-4" style={{ fontFamily: 'Syne, sans-serif' }}>
                {feature.title}
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed mb-6 max-w-lg">
                {feature.desc}
              </p>
              <ul className="flex flex-col gap-3">
                {feature.bullets.map((b) => (
                  <li key={b} className="flex items-start gap-3 text-sm text-gray-700">
                    <span className={`mt-1.5 w-2 h-2 rounded-full flex-shrink-0 ${c.dot}`}></span>
                    {b}
                  </li>
                ))}
              </ul>
            </div>

            {/* Right — visual */}
            <div className="flex-shrink-0 w-full lg:w-80">
              <div className="bg-white rounded-2xl border border-gray-100 p-6 flex flex-col gap-4">
                {/* Mock UI card */}
                {feature.id === 'ai' && (
                  <>
                    <div className="flex items-center gap-3 pb-3 border-b border-gray-100">
                      <div className="w-9 h-9 flex items-center justify-center rounded-xl bg-emerald-50"><i className="ri-brain-line text-emerald-500 text-lg"></i></div>
                      <div><p className="text-xs font-bold text-gray-900">AI Route Analysis</p><p className="text-[11px] text-gray-400">Lagos → Abuja · Updated 2 min ago</p></div>
                    </div>
                    {[
                      { label: 'Optimal Route', val: 'A1 Expressway', sub: 'Saves 42 min vs alternate', color: 'text-emerald-600' },
                      { label: 'Border Wait', val: 'N/A (Domestic)', sub: 'No border crossing', color: 'text-gray-500' },
                      { label: 'Traffic Score', val: 'Low — Clear', sub: 'Best departure: Now', color: 'text-emerald-600' },
                      { label: 'ETA', val: '6h 48m', sub: 'Arrives ~3:30 PM', color: 'text-gray-800' },
                    ].map((row) => (
                      <div key={row.label} className="flex items-center justify-between">
                        <span className="text-xs text-gray-500">{row.label}</span>
                        <div className="text-right"><p className={`text-xs font-bold ${row.color}`}>{row.val}</p><p className="text-[10px] text-gray-400">{row.sub}</p></div>
                      </div>
                    ))}
                  </>
                )}
                {feature.id === 'track' && (
                  <>
                    <div className="flex items-center gap-3 pb-3 border-b border-gray-100">
                      <div className="w-9 h-9 flex items-center justify-center rounded-xl bg-sky-50"><i className="ri-map-pin-time-line text-sky-500 text-lg"></i></div>
                      <div><p className="text-xs font-bold text-gray-900">Live Trip Tracker</p><p className="text-[11px] text-gray-400">Share link active · 3 viewers</p></div>
                    </div>
                    <div className="bg-sky-50 rounded-xl h-28 flex items-center justify-center relative overflow-hidden">
                      <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'repeating-linear-gradient(0deg,#0ea5e9 0,#0ea5e9 1px,transparent 0,transparent 50%),repeating-linear-gradient(90deg,#0ea5e9 0,#0ea5e9 1px,transparent 0,transparent 50%)', backgroundSize: '20px 20px' }}></div>
                      <div className="relative flex flex-col items-center gap-1">
                        <i className="ri-car-fill text-sky-500 text-2xl"></i>
                        <span className="text-[10px] font-bold text-sky-700 bg-white px-2 py-0.5 rounded-full">Driver en route</span>
                      </div>
                    </div>
                    {[
                      { label: 'Driver', val: 'Emmanuel K.', sub: '4.9★ · 1,240 trips' },
                      { label: 'ETA to pickup', val: '8 min', sub: 'Updating live' },
                    ].map((row) => (
                      <div key={row.label} className="flex items-center justify-between">
                        <span className="text-xs text-gray-500">{row.label}</span>
                        <div className="text-right"><p className="text-xs font-bold text-gray-800">{row.val}</p><p className="text-[10px] text-gray-400">{row.sub}</p></div>
                      </div>
                    ))}
                  </>
                )}
                {feature.id === 'safety' && (
                  <>
                    <div className="flex items-center gap-3 pb-3 border-b border-gray-100">
                      <div className="w-9 h-9 flex items-center justify-center rounded-xl bg-rose-50"><i className="ri-shield-star-line text-rose-500 text-lg"></i></div>
                      <div><p className="text-xs font-bold text-gray-900">SafeGuard™ Active</p><p className="text-[11px] text-gray-400">Trip protected · All checks passed</p></div>
                    </div>
                    {[
                      { icon: 'ri-checkbox-circle-fill', label: 'Driver identity verified', color: 'text-emerald-500' },
                      { icon: 'ri-checkbox-circle-fill', label: 'Vehicle plate confirmed', color: 'text-emerald-500' },
                      { icon: 'ri-checkbox-circle-fill', label: 'Trip recording active', color: 'text-emerald-500' },
                      { icon: 'ri-alarm-warning-line',   label: 'Panic button ready', color: 'text-rose-500' },
                    ].map((item) => (
                      <div key={item.label} className="flex items-center gap-2.5">
                        <i className={`${item.icon} ${item.color} text-base flex-shrink-0`}></i>
                        <span className="text-xs text-gray-700">{item.label}</span>
                      </div>
                    ))}
                    <Link to="/contact" className="w-full mt-1 bg-rose-500 hover:bg-rose-600 text-white text-xs font-bold py-2.5 rounded-xl transition-colors cursor-pointer whitespace-nowrap flex items-center justify-center gap-1.5">
                      <i className="ri-alarm-warning-line"></i>Emergency Panic Button
                    </Link>
                  </>
                )}
                {feature.id === 'price' && (
                  <>
                    <div className="flex items-center gap-3 pb-3 border-b border-gray-100">
                      <div className="w-9 h-9 flex items-center justify-center rounded-xl bg-amber-50"><i className="ri-auction-line text-amber-500 text-lg"></i></div>
                      <div><p className="text-xs font-bold text-gray-900">Live Driver Bids</p><p className="text-[11px] text-gray-400">London → Manchester · 4 offers</p></div>
                    </div>
                    {[
                      { driver: 'James O.', rating: '4.9★', vehicle: 'Mercedes E-Class', price: '£62', badge: 'Lowest' },
                      { driver: 'Sarah M.', rating: '5.0★', vehicle: 'BMW 5 Series',     price: '£68', badge: 'Top Rated' },
                      { driver: 'Ali R.',   rating: '4.8★', vehicle: 'Audi A6',          price: '£71', badge: '' },
                    ].map((bid) => (
                      <div key={bid.driver} className="flex items-center justify-between py-1.5 border-b border-gray-50 last:border-0">
                        <div>
                          <p className="text-xs font-semibold text-gray-900">{bid.driver} <span className="text-amber-500 font-normal">{bid.rating}</span></p>
                          <p className="text-[10px] text-gray-400">{bid.vehicle}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          {bid.badge && <span className="text-[10px] font-bold bg-amber-100 text-amber-700 px-1.5 py-0.5 rounded-full">{bid.badge}</span>}
                          <span className="text-sm font-extrabold text-gray-900">{bid.price}</span>
                        </div>
                      </div>
                    ))}
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
