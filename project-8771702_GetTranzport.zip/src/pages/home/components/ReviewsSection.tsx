import { useState, useRef } from 'react';

const REVIEWS = [
  {
    name: 'Amara Osei',
    route: 'Accra → Kumasi',
    rating: 5,
    text: 'Absolutely seamless experience. The driver was punctual, the car was spotless, and the price was far better than any taxi. Will definitely use GetTranzport again for my next city-to-city trip.',
    platform: 'GetTranzport',
    platformIcon: 'ri-map-pin-2-fill',
  },
  {
    name: 'Priya Nair',
    route: 'Mumbai Airport Transfer',
    rating: 5,
    text: 'My flight was delayed by 2 hours and the driver waited without any extra charge. That kind of reliability is rare. Highly recommend for airport transfers.',
    platform: 'GetTranzport',
    platformIcon: 'ri-map-pin-2-fill',
  },
  {
    name: 'Carlos Mendez',
    route: 'Tijuana → San Diego',
    rating: 5,
    text: 'Cross-border transfer was handled perfectly. The driver knew all the border procedures and we crossed without any issues. Professional and friendly throughout.',
    platform: 'GetTranzport',
    platformIcon: 'ri-map-pin-2-fill',
  },
  {
    name: 'Sophie Laurent',
    route: 'Paris → Brussels',
    rating: 5,
    text: 'Booked a cross-border ride from Paris to Brussels. The vehicle was a premium class Mercedes and the driver was incredibly professional. Worth every cent.',
    platform: 'GetTranzport',
    platformIcon: 'ri-map-pin-2-fill',
  },
  {
    name: 'James Okafor',
    route: 'Lagos → Abuja',
    rating: 4,
    text: 'Great service overall. The booking process was simple and the driver communicated well. The ride was comfortable for a long-distance trip. Support was very responsive.',
    platform: 'GetTranzport',
    platformIcon: 'ri-map-pin-2-fill',
  },
  {
    name: 'Mei Lin',
    route: 'Shenzhen → Guangzhou',
    rating: 5,
    text: 'Used GetTranzport for a business trip. The driver was on time, the car was clean and quiet — perfect for working during the ride. Will use for all my business travel.',
    platform: 'GetTranzport',
    platformIcon: 'ri-map-pin-2-fill',
  },
  {
    name: 'David Kimani',
    route: 'Nairobi → Mombasa',
    rating: 5,
    text: 'Booked a long-distance ride from Nairobi to Mombasa. The driver was professional, the car was comfortable, and we arrived on time. Very competitive pricing.',
    platform: 'GetTranzport',
    platformIcon: 'ri-map-pin-2-fill',
  },
  {
    name: 'Raj Patel',
    route: 'Delhi → Jaipur',
    rating: 5,
    text: 'Excellent service from start to finish. The driver arrived 10 minutes early, the car was spotless, and the journey was smooth. Fixed price meant no haggling.',
    platform: 'GetTranzport',
    platformIcon: 'ri-map-pin-2-fill',
  },
];

function Stars({ rating }: { rating: number }) {
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map((s) => (
        <i key={s} className={`ri-star-fill text-sm ${s <= rating ? 'text-amber-400' : 'text-gray-200'}`}></i>
      ))}
    </div>
  );
}

const PER_PAGE = 3;

export default function ReviewsSection() {
  const [page, setPage] = useState(0);
  const total = Math.ceil(REVIEWS.length / PER_PAGE);
  const visible = REVIEWS.slice(page * PER_PAGE, page * PER_PAGE + PER_PAGE);

  return (
    <section className="py-16 bg-white">
      <div className="max-w-6xl mx-auto px-6">

        {/* Header */}
        <div className="text-center mb-10">
          <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>
            Traveller Reviews
          </h2>
          <p className="text-gray-500 text-sm">Millions of travellers trust us with their trips. Here's what they say.</p>
        </div>

        {/* Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          {visible.map((r) => (
            <div key={r.name} className="border border-gray-100 rounded-2xl p-6 flex flex-col gap-3 bg-white hover:border-gray-200 transition-colors">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-semibold text-gray-900 text-sm">{r.name}</p>
                  <p className="text-xs text-gray-400 mt-0.5 flex items-center gap-1">
                    <i className="ri-route-line text-emerald-400"></i>
                    {r.route}
                  </p>
                </div>
                <span className="text-[11px] font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full whitespace-nowrap">
                  GetTranzport
                </span>
              </div>
              <Stars rating={r.rating} />
              <p className="text-sm text-gray-600 leading-relaxed flex-1">"{r.text}"</p>
            </div>
          ))}
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-center gap-4">
          <button
            onClick={() => setPage(Math.max(0, page - 1))}
            disabled={page === 0}
            className="w-9 h-9 flex items-center justify-center rounded-full border border-gray-200 text-gray-500 hover:border-emerald-400 hover:text-emerald-500 disabled:opacity-30 disabled:cursor-not-allowed transition cursor-pointer"
          >
            <i className="ri-arrow-left-s-line text-lg"></i>
          </button>
          <span className="text-sm text-gray-500 tabular-nums">{page + 1} / {total}</span>
          <button
            onClick={() => setPage(Math.min(total - 1, page + 1))}
            disabled={page === total - 1}
            className="w-9 h-9 flex items-center justify-center rounded-full border border-gray-200 text-gray-500 hover:border-emerald-400 hover:text-emerald-500 disabled:opacity-30 disabled:cursor-not-allowed transition cursor-pointer"
          >
            <i className="ri-arrow-right-s-line text-lg"></i>
          </button>
        </div>
      </div>
    </section>
  );
}
