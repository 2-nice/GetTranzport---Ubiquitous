import { Link } from 'react-router-dom';
import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';

const FEATURES = [
  { icon: 'ri-building-2-line',       title: 'Centralised Billing',         desc: 'One invoice for all employee trips. Integrate with your finance system via API or CSV export.' },
  { icon: 'ri-settings-3-line',       title: 'Travel Policy Controls',      desc: 'Set vehicle class limits, spending caps, and approved routes for your team.' },
  { icon: 'ri-user-settings-line',    title: 'Dedicated Account Manager',   desc: 'A named account manager available 24/7 for enterprise clients.' },
  { icon: 'ri-bar-chart-2-line',      title: 'Reporting & Analytics',       desc: 'Full trip history, spend analysis, and CO₂ reporting for your sustainability goals.' },
  { icon: 'ri-shield-check-line',     title: 'Duty of Care',                desc: 'Real-time employee location tracking and emergency response for every business trip.' },
  { icon: 'ri-global-line',           title: 'Global Coverage',             desc: 'Book rides for employees in 150+ countries from a single platform.' },
];

const PLANS = [
  {
    name: 'Starter',
    price: 'Free',
    sub: 'Up to 5 employees',
    features: ['Centralised billing', 'Basic reporting', 'Email support', 'Standard vehicle classes'],
    cta: 'Get Started',
    highlight: false,
  },
  {
    name: 'Business',
    price: '$49',
    sub: '/month · Up to 50 employees',
    features: ['Everything in Starter', 'Travel policy controls', 'Priority support', 'All vehicle classes', 'API access'],
    cta: 'Start Free Trial',
    highlight: true,
  },
  {
    name: 'Enterprise',
    price: 'Custom',
    sub: 'Unlimited employees',
    features: ['Everything in Business', 'Dedicated account manager', 'Custom integrations', 'Duty of care dashboard', 'CO₂ reporting', 'SLA guarantee'],
    cta: 'Contact Sales',
    highlight: false,
  },
];

export default function ForBusinessPage() {
  return (
    <div className="min-h-screen flex flex-col bg-white" style={{ fontFamily: 'Inter, sans-serif' }}>
      <Navbar />

      {/* Hero */}
      <section className="pt-32 pb-20 bg-gray-950 text-center px-6">
        <span className="text-emerald-400 text-xs font-bold tracking-widest uppercase">For Business</span>
        <h1 className="text-4xl md:text-5xl font-extrabold text-white mt-3 mb-4" style={{ fontFamily: 'Syne, sans-serif' }}>
          Corporate Travel,<br /><span className="text-emerald-400">Simplified</span>
        </h1>
        <p className="text-gray-400 text-base max-w-xl mx-auto mb-8">
          Manage all your company's long-distance travel in one place. Centralised billing, travel policy controls, and real-time duty of care for teams of any size.
        </p>
        <div className="flex flex-wrap gap-3 justify-center">
          <Link to="/signup" className="bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-sm px-6 py-3 rounded-xl transition-colors cursor-pointer whitespace-nowrap">
            Start Free Trial
          </Link>
          <Link to="/contact" className="border border-white/20 text-white hover:bg-white/10 font-medium text-sm px-6 py-3 rounded-xl transition-colors cursor-pointer whitespace-nowrap">
            Contact Sales
          </Link>
        </div>
      </section>

      {/* Logos */}
      <section className="py-10 border-b border-gray-100 px-6">
        <div className="max-w-5xl mx-auto text-center">
          <p className="text-xs text-gray-400 font-medium mb-6 uppercase tracking-widest">Trusted by teams at</p>
          <div className="flex flex-wrap justify-center gap-8 items-center">
            {['Deloitte', 'Accenture', 'Shell', 'Unilever', 'Standard Bank', 'MTN Group'].map((co) => (
              <span key={co} className="text-gray-300 font-bold text-lg tracking-tight" style={{ fontFamily: 'Syne, sans-serif' }}>{co}</span>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-extrabold text-gray-900 mb-3" style={{ fontFamily: 'Syne, sans-serif' }}>Everything Your Team Needs</h2>
            <p className="text-gray-500 text-sm max-w-lg mx-auto">Built for travel managers, finance teams, and HR — not just bookers.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {FEATURES.map((f) => (
              <div key={f.title} className="bg-gray-50 rounded-2xl border border-gray-100 p-5 flex gap-4 hover:border-emerald-200 transition-colors">
                <div className="w-10 h-10 flex items-center justify-center rounded-xl bg-white border border-gray-100 flex-shrink-0">
                  <i className={`${f.icon} text-emerald-500 text-lg`}></i>
                </div>
                <div>
                  <h3 className="text-sm font-bold text-gray-900 mb-1">{f.title}</h3>
                  <p className="text-xs text-gray-500 leading-relaxed">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-16 bg-gray-50/60 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-extrabold text-gray-900 mb-3" style={{ fontFamily: 'Syne, sans-serif' }}>Simple, Transparent Pricing</h2>
            <p className="text-gray-500 text-sm">No setup fees. No hidden charges. Cancel anytime.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {PLANS.map((p) => (
              <div key={p.name} className={`rounded-2xl p-7 flex flex-col gap-4 border-2 ${p.highlight ? 'bg-emerald-500 border-emerald-500' : 'bg-white border-gray-100'}`}>
                <div>
                  <p className={`text-xs font-bold uppercase tracking-widest mb-1 ${p.highlight ? 'text-emerald-100' : 'text-gray-400'}`}>{p.name}</p>
                  <div className={`text-3xl font-extrabold ${p.highlight ? 'text-white' : 'text-gray-900'}`} style={{ fontFamily: 'Syne, sans-serif' }}>{p.price}</div>
                  <p className={`text-xs mt-0.5 ${p.highlight ? 'text-emerald-100' : 'text-gray-400'}`}>{p.sub}</p>
                </div>
                <ul className="flex flex-col gap-2 flex-1">
                  {p.features.map((f) => (
                    <li key={f} className={`flex items-center gap-2 text-xs ${p.highlight ? 'text-emerald-50' : 'text-gray-600'}`}>
                      <i className={`ri-checkbox-circle-fill text-sm flex-shrink-0 ${p.highlight ? 'text-white' : 'text-emerald-500'}`}></i>
                      {f}
                    </li>
                  ))}
                </ul>
                <Link
                  to={p.cta === 'Contact Sales' ? '/contact' : '/signup'}
                  className={`w-full font-bold text-sm py-3 rounded-xl transition-colors cursor-pointer whitespace-nowrap text-center block ${p.highlight ? 'bg-white text-emerald-700 hover:bg-emerald-50' : 'bg-emerald-500 hover:bg-emerald-600 text-white'}`}
                >
                  {p.cta}
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact / Support */}
      <section className="py-16 bg-white px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>Business Support</h2>
            <p className="text-gray-500 text-sm">Dedicated account managers and 24/7 support for enterprise clients.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <a href="tel:+14313342841" className="flex items-center gap-3 bg-gray-50 border border-gray-100 rounded-2xl p-5 hover:border-emerald-300 transition-colors cursor-pointer">
              <div className="w-10 h-10 flex items-center justify-center bg-emerald-50 rounded-xl flex-shrink-0">
                <i className="ri-phone-line text-emerald-500 text-lg"></i>
              </div>
              <div>
                <p className="text-xs text-gray-400 font-medium">24/7 Phone</p>
                <p className="text-sm font-bold text-gray-900">+1 431-334-2841</p>
              </div>
            </a>
            <a href="mailto:admin@gettranzport.com" className="flex items-center gap-3 bg-gray-50 border border-gray-100 rounded-2xl p-5 hover:border-emerald-300 transition-colors cursor-pointer">
              <div className="w-10 h-10 flex items-center justify-center bg-emerald-50 rounded-xl flex-shrink-0">
                <i className="ri-mail-line text-emerald-500 text-lg"></i>
              </div>
              <div>
                <p className="text-xs text-gray-400 font-medium">Business Email</p>
                <p className="text-sm font-bold text-gray-900">admin@gettranzport.com</p>
              </div>
            </a>
            <a href="https://wa.me/14313342841" target="_blank" rel="nofollow noopener" className="flex items-center gap-3 bg-gray-50 border border-gray-100 rounded-2xl p-5 hover:border-emerald-300 transition-colors cursor-pointer">
              <div className="w-10 h-10 flex items-center justify-center bg-emerald-50 rounded-xl flex-shrink-0">
                <i className="ri-whatsapp-line text-emerald-500 text-lg"></i>
              </div>
              <div>
                <p className="text-xs text-gray-400 font-medium">WhatsApp</p>
                <p className="text-sm font-bold text-gray-900">+1 431-334-2841</p>
              </div>
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
