import { useState, FormEvent } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';

const OFFICES = [
  {
    label: 'Headquarters',
    name: 'GeTTranzport.com - Ubiquitous Ride',
    address: '635 St. James Street, Winnipeg, MB R3G 3R4, Canada',
    phone: '+1 431-334-2841',
    email: 'info@gettranzport.com',
    mapQuery: '635+St+James+Street,+Winnipeg,+MB+R3G+3R4,+Canada',
  },
  {
    label: 'United Kingdom Office',
    name: 'GeTTranzport.com - Ubiquitous Ride',
    address: 'One Canada Square, Canary Wharf, London, E14 5AB, United Kingdom',
    phone: '+1 431-334-2841',
    email: 'info@gettranzport.com',
    mapQuery: 'One+Canada+Square,+Canary+Wharf,+London,+E14+5AB,+UK',
  },
  {
    label: 'United States Office',
    name: 'GeTTranzport.com - Ubiquitous Ride',
    address: '350 Fifth Avenue, Suite 4100, New York, NY 10118, USA',
    phone: '+1 431-334-2841',
    email: 'info@gettranzport.com',
    mapQuery: '350+Fifth+Avenue,+New+York,+NY+10118,+USA',
  },
  {
    label: 'Africa Office — Nigeria',
    name: 'GeTTranzport.com - Ubiquitous Ride',
    address: 'Plot 1, Adeola Odeku Street, Victoria Island, Lagos, Nigeria',
    phone: '+1 431-334-2841',
    email: 'info@gettranzport.com',
    mapQuery: 'Plot+1+Adeola+Odeku+Street,+Victoria+Island,+Lagos,+Nigeria',
  },
];

const CONTACT_METHODS = [
  { icon: 'ri-phone-line', label: '24/7 Phone', value: '+1 431-334-2841', href: 'tel:+14313342841' },
  { icon: 'ri-mail-line', label: 'General Email', value: 'info@gettranzport.com', href: 'mailto:info@gettranzport.com' },
  { icon: 'ri-mail-line', label: 'Support Email', value: 'support@gettranzport.com', href: 'mailto:support@gettranzport.com' },
  { icon: 'ri-whatsapp-line', label: 'WhatsApp', value: '+1 431-334-2841', href: 'https://wa.me/14313342841' },
];

export default function ContactPage() {
  const [submitted, setSubmitted] = useState(false);
  const [activeOffice, setActiveOffice] = useState(0);

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new URLSearchParams(new FormData(form) as unknown as Record<string, string>);
    try {
      await fetch('https://readdy.ai/api/form/d7lhibate7rh0002nd9g', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: data.toString(),
      });
      setSubmitted(true);
    } catch {
      setSubmitted(true);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-white" style={{ fontFamily: 'Inter, sans-serif' }}>
      <Navbar />

      {/* Hero */}
      <section className="pt-28 pb-14 bg-gray-900 text-center">
        <div className="max-w-2xl mx-auto px-6">
          <div className="w-14 h-14 flex items-center justify-center bg-emerald-500/20 rounded-2xl mx-auto mb-5">
            <i className="ri-contacts-line text-emerald-400 text-2xl"></i>
          </div>
          <h1 className="text-4xl font-extrabold text-white mb-3" style={{ fontFamily: 'Syne, sans-serif' }}>
            Contact Us
          </h1>
          <p className="text-white/60 text-sm mb-6">
            Get in touch with our team. We typically respond within 30 minutes.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <a
              href="tel:+14313342841"
              className="flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white font-semibold px-6 py-3 rounded-xl transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-phone-line"></i>
              +1 431-334-2841
            </a>
            <a
              href="https://wa.me/14313342841"
              target="_blank"
              rel="nofollow noopener"
              className="flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 text-white font-semibold px-6 py-3 rounded-xl transition-colors cursor-pointer whitespace-nowrap border border-white/20"
            >
              <i className="ri-whatsapp-line text-green-400"></i>
              WhatsApp Chat
            </a>
          </div>
        </div>
      </section>

      {/* Contact Methods */}
      <section className="py-14 bg-white">
        <div className="max-w-5xl mx-auto px-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {CONTACT_METHODS.map((c) => (
              <a
                key={c.label}
                href={c.href}
                target={c.href.startsWith('http') ? '_blank' : undefined}
                rel={c.href.startsWith('http') ? 'nofollow noopener' : undefined}
                className="flex items-center gap-3 bg-gray-50 border border-gray-100 rounded-2xl p-5 hover:border-emerald-300 transition-colors cursor-pointer"
              >
                <div className="w-10 h-10 flex items-center justify-center bg-emerald-50 rounded-xl flex-shrink-0">
                  <i className={`${c.icon} text-emerald-500 text-lg`}></i>
                </div>
                <div>
                  <p className="text-xs text-gray-400 font-medium">{c.label}</p>
                  <p className="text-sm font-bold text-gray-900">{c.value}</p>
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* Offices */}
      <section className="py-14 bg-gray-50/60">
        <div className="max-w-5xl mx-auto px-6">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>Our Offices</h2>
            <p className="text-gray-500 text-sm">2-Nice Rideshare &amp; Carpooling Transport Services Inc.</p>
          </div>

          {/* Office tabs */}
          <div className="flex flex-wrap gap-2 justify-center mb-8">
            {OFFICES.map((o, i) => (
              <button
                key={o.label}
                onClick={() => setActiveOffice(i)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors cursor-pointer whitespace-nowrap ${
                  activeOffice === i
                    ? 'bg-emerald-500 text-white'
                    : 'bg-white border border-gray-200 text-gray-600 hover:border-emerald-300'
                }`}
              >
                {o.label}
              </button>
            ))}
          </div>

          {/* Active office card */}
          <div className="bg-white border border-gray-100 rounded-2xl overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2">
              <div className="p-8 flex flex-col gap-5">
                <div>
                  <span className="text-xs font-bold text-emerald-500 uppercase tracking-widest">{OFFICES[activeOffice].label}</span>
                  <h3 className="text-lg font-bold text-gray-900 mt-1">{OFFICES[activeOffice].name}</h3>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 flex items-center justify-center bg-gray-50 rounded-lg flex-shrink-0">
                    <i className="ri-map-pin-line text-gray-400 text-sm"></i>
                  </div>
                  <p className="text-sm text-gray-600 leading-relaxed">{OFFICES[activeOffice].address}</p>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 flex items-center justify-center bg-gray-50 rounded-lg flex-shrink-0">
                    <i className="ri-phone-line text-gray-400 text-sm"></i>
                  </div>
                  <a href={`tel:${OFFICES[activeOffice].phone.replace(/\s/g, '')}`} className="text-sm text-gray-600 hover:text-emerald-500 transition-colors">
                    {OFFICES[activeOffice].phone}
                  </a>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 flex items-center justify-center bg-gray-50 rounded-lg flex-shrink-0">
                    <i className="ri-mail-line text-gray-400 text-sm"></i>
                  </div>
                  <a href={`mailto:${OFFICES[activeOffice].email}`} className="text-sm text-gray-600 hover:text-emerald-500 transition-colors">
                    {OFFICES[activeOffice].email}
                  </a>
                </div>
              </div>
              <div className="h-64 lg:h-auto bg-gray-100">
                <iframe
                  title={`${OFFICES[activeOffice].label} Map`}
                  src={`https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d100000!2d0!3d0!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDDCsDAwJzAwLjAiTiA3NMKwMDAnMDAuMCJX!5e0!3m2!1sen!2sus!4v1!5m2!1sen!2sus&q=${OFFICES[activeOffice].mapQuery}`}
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="w-full h-full"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section className="py-14 bg-white">
        <div className="max-w-2xl mx-auto px-6">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>Send Us a Message</h2>
            <p className="text-gray-500 text-sm">We typically respond within 30 minutes.</p>
          </div>

          {submitted ? (
            <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-10 text-center">
              <div className="w-14 h-14 flex items-center justify-center bg-emerald-100 rounded-full mx-auto mb-4">
                <i className="ri-checkbox-circle-fill text-emerald-500 text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">Message Sent!</h3>
              <p className="text-sm text-gray-600">Our team will get back to you within 30 minutes.</p>
            </div>
          ) : (
            <form
              data-readdy-form
              onSubmit={handleSubmit}
              className="bg-white border border-gray-100 rounded-2xl p-8 flex flex-col gap-4"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">Full Name</label>
                  <input
                    name="full_name"
                    type="text"
                    required
                    placeholder="John Doe"
                    className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder-gray-400 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1.5">Email Address</label>
                  <input
                    name="email"
                    type="email"
                    required
                    placeholder="john@example.com"
                    className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder-gray-400 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Topic</label>
                <select
                  name="topic"
                  required
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition cursor-pointer"
                >
                  <option value="">Select a topic...</option>
                  <option value="General Inquiry">General Inquiry</option>
                  <option value="Booking Help">Booking Help</option>
                  <option value="Driver Support">Driver Support</option>
                  <option value="Business / Enterprise">Business / Enterprise</option>
                  <option value="Agent / Affiliate">Agent / Affiliate</option>
                  <option value="Partnership">Partnership</option>
                  <option value="Press / Media">Press / Media</option>
                  <option value="Legal / Compliance">Legal / Compliance</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1.5">Message</label>
                <textarea
                  name="message"
                  required
                  rows={5}
                  maxLength={500}
                  placeholder="How can we help you?"
                  className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder-gray-400 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition resize-none"
                />
                <p className="text-xs text-gray-400 mt-1">Max 500 characters</p>
              </div>
              <button
                type="submit"
                className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-3.5 rounded-xl text-sm transition-colors cursor-pointer whitespace-nowrap"
              >
                Send Message
              </button>
            </form>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}