import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';
import { useState } from 'react';

const BENEFITS = [
  { icon: 'ri-money-dollar-circle-line', title: 'Set Your Own Rates',       desc: 'You decide your price. Passengers compare and choose — no platform-imposed fares.' },
  { icon: 'ri-calendar-check-line',      title: 'Work When You Want',       desc: 'Accept trips that fit your schedule. No minimum hours, no mandatory shifts.' },
  { icon: 'ri-route-line',               title: 'Long-Distance = More Pay', desc: 'City-to-city and cross-border trips pay significantly more than short local rides.' },
  { icon: 'ri-bank-line',                title: 'Fast Payouts',             desc: 'Earnings transferred to your account within 24 hours of trip completion.' },
  { icon: 'ri-shield-check-line',        title: 'Driver Protection',        desc: 'Trip insurance, 24/7 driver support, and dispute resolution on every booking.' },
  { icon: 'ri-global-line',              title: 'Global Passenger Base',    desc: 'Access passengers from 150+ countries booking long-distance rides in your area.' },
];

const STEPS = [
  { num: '01', title: 'Create Your Profile',    desc: 'Sign up, upload your licence, vehicle documents, and a profile photo. Takes under 10 minutes.' },
  { num: '02', title: 'Pass Verification',       desc: 'Our team reviews your documents and runs a background check. Approval typically within 24 hours.' },
  { num: '03', title: 'Start Receiving Trips',   desc: 'Browse available trip requests in your area and submit competitive bids. Passengers choose you.' },
  { num: '04', title: 'Drive & Get Paid',        desc: 'Complete the trip, get rated, and receive your earnings within 24 hours.' },
];

export default function ForDriversPage() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', city: '', vehicle: '' });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    const data = new URLSearchParams({
      full_name: form.name,
      email: form.email,
      phone: form.phone,
      city: form.city,
      vehicle_class: form.vehicle,
    });
    try {
      await fetch('https://readdy.ai/api/form/d7li89ate7rh0002ndn0', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: data.toString(),
      });
    } catch {
      // silent
    } finally {
      setLoading(false);
      setSubmitted(true);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-white" style={{ fontFamily: 'Inter, sans-serif' }}>
      <Navbar />

      {/* Hero */}
      <section className="pt-32 pb-20 bg-gray-950 px-6">
        <div className="max-w-5xl mx-auto flex flex-col lg:flex-row gap-12 items-center">
          <div className="flex-1 text-center lg:text-left">
            <span className="text-emerald-400 text-xs font-bold tracking-widest uppercase">For Drivers</span>
            <h1 className="text-4xl md:text-5xl font-extrabold text-white mt-3 mb-4" style={{ fontFamily: 'Syne, sans-serif' }}>
              Earn More on Every<br /><span className="text-emerald-400">Long-Distance Trip</span>
            </h1>
            <p className="text-gray-400 text-base mb-8 max-w-lg">
              Join 50,000+ verified drivers on GetTranzport. Set your own rates, choose your trips, and earn significantly more on city-to-city, airport, and cross-border rides.
            </p>
            <div className="flex flex-wrap gap-4 justify-center lg:justify-start">
              {[
                { val: '50K+', label: 'Active Drivers' },
                { val: '150+', label: 'Countries' },
                { val: '4.8★', label: 'Avg Driver Rating' },
              ].map((s) => (
                <div key={s.label} className="text-center">
                  <div className="text-2xl font-extrabold text-emerald-400" style={{ fontFamily: 'Syne, sans-serif' }}>{s.val}</div>
                  <div className="text-xs text-gray-500">{s.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Sign-up form */}
          <div className="flex-shrink-0 w-full lg:w-96 bg-white rounded-2xl p-7">
            {submitted ? (
              <div className="text-center py-8">
                <div className="w-14 h-14 flex items-center justify-center rounded-full bg-emerald-100 mx-auto mb-4">
                  <i className="ri-checkbox-circle-fill text-emerald-500 text-3xl"></i>
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">Application Received!</h3>
                <p className="text-gray-500 text-sm">We'll review your details and get back to you within 24 hours.</p>
              </div>
            ) : (
              <>
                <h3 className="text-lg font-bold text-gray-900 mb-1">Start Driving with GetTranzport</h3>
                <p className="text-gray-500 text-xs mb-5">Fill in your details and we'll be in touch within 24 hours.</p>
                <form data-readdy-form onSubmit={handleSubmit} className="flex flex-col gap-3">
                  {[
                    { key: 'name',    placeholder: 'Full Name',         type: 'text'  },
                    { key: 'email',   placeholder: 'Email Address',     type: 'email' },
                    { key: 'phone',   placeholder: 'Phone Number',      type: 'tel'   },
                    { key: 'city',    placeholder: 'City / Region',     type: 'text'  },
                  ].map((f) => (
                    <input
                      key={f.key}
                      type={f.type}
                      placeholder={f.placeholder}
                      value={form[f.key as keyof typeof form]}
                      onChange={(e) => setForm({ ...form, [f.key]: e.target.value })}
                      className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder-gray-400 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition"
                      required
                    />
                  ))}
                  <select
                    value={form.vehicle}
                    onChange={(e) => setForm({ ...form, vehicle: e.target.value })}
                    className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-700 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition cursor-pointer"
                    required
                  >
                    <option value="">Vehicle Class</option>
                    {['Economy', 'Comfort', 'Business', 'Premium', 'VIP / Limousine', 'SUV', 'Van', 'Minibus', 'Bus'].map((v) => (
                      <option key={v} value={v}>{v}</option>
                    ))}
                  </select>
                  <button type="submit" disabled={loading} className="w-full bg-emerald-500 hover:bg-emerald-600 disabled:opacity-60 text-white font-bold py-3.5 rounded-xl text-sm transition-colors cursor-pointer whitespace-nowrap mt-1">
                    {loading ? 'Submitting...' : 'Apply to Drive'}
                  </button>
                </form>
              </>
            )}
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-20 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-extrabold text-gray-900 mb-3" style={{ fontFamily: 'Syne, sans-serif' }}>Why Drive with GetTranzport?</h2>
            <p className="text-gray-500 text-sm max-w-lg mx-auto">More earnings, more freedom, more support — built for professional long-distance drivers.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {BENEFITS.map((b) => (
              <div key={b.title} className="bg-gray-50 rounded-2xl border border-gray-100 p-5 flex gap-4 hover:border-emerald-200 transition-colors">
                <div className="w-10 h-10 flex items-center justify-center rounded-xl bg-white border border-gray-100 flex-shrink-0">
                  <i className={`${b.icon} text-emerald-500 text-lg`}></i>
                </div>
                <div>
                  <h3 className="text-sm font-bold text-gray-900 mb-1">{b.title}</h3>
                  <p className="text-xs text-gray-500 leading-relaxed">{b.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How to join */}
      <section className="py-16 bg-gray-50/60 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-extrabold text-gray-900 mb-3" style={{ fontFamily: 'Syne, sans-serif' }}>How to Get Started</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {STEPS.map((s) => (
              <div key={s.num} className="flex flex-col items-center text-center">
                <div className="w-12 h-12 flex items-center justify-center rounded-2xl bg-emerald-500 text-white font-extrabold text-sm mb-4" style={{ fontFamily: 'Syne, sans-serif' }}>{s.num}</div>
                <h3 className="text-sm font-bold text-gray-900 mb-1.5">{s.title}</h3>
                <p className="text-xs text-gray-500 leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact / Support */}
      <section className="py-16 bg-white px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>Driver Support</h2>
            <p className="text-gray-500 text-sm">Our driver support team is available 24/7. Reach us anytime.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <a href="tel:+14313342841" className="flex items-center gap-3 bg-gray-50 border border-gray-100 rounded-2xl p-5 hover:border-emerald-300 transition-colors cursor-pointer">
              <div className="w-10 h-10 flex items-center justify-center bg-emerald-50 rounded-xl flex-shrink-0">
                <i className="ri-phone-line text-emerald-500 text-lg"></i>
              </div>
              <div>
                <p className="text-xs text-gray-400 font-medium">24/7 Phone</p>
                <p className="text-sm font-bold text-gray-900">+1 431-334-2841</p>
              </div>
            </a>
            <a href="mailto:drivers@gettranzport.com" className="flex items-center gap-3 bg-gray-50 border border-gray-100 rounded-2xl p-5 hover:border-emerald-300 transition-colors cursor-pointer">
              <div className="w-10 h-10 flex items-center justify-center bg-emerald-50 rounded-xl flex-shrink-0">
                <i className="ri-mail-line text-emerald-500 text-lg"></i>
              </div>
              <div>
                <p className="text-xs text-gray-400 font-medium">Driver Email</p>
                <p className="text-sm font-bold text-gray-900">drivers@gettranzport.com</p>
              </div>
            </a>
            <a href="https://wa.me/14313342841" target="_blank" rel="nofollow noopener" className="flex items-center gap-3 bg-gray-50 border border-gray-100 rounded-2xl p-5 hover:border-emerald-300 transition-colors cursor-pointer">
              <div className="w-10 h-10 flex items-center justify-center bg-emerald-50 rounded-xl flex-shrink-0">
                <i className="ri-whatsapp-line text-emerald-500 text-lg"></i>
              </div>
              <div>
                <p className="text-xs text-gray-400 font-medium">WhatsApp</p>
                <p className="text-sm font-bold text-gray-900">+1 431-334-2841</p>
              </div>
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
