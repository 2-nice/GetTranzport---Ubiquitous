import { Link } from 'react-router-dom';
import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';

const PRESS_RELEASES = [
  {
    date: 'April 20, 2026',
    title: 'GetTranzport Launches Delivery-Per-Kg Service Across North America',
    summary: 'New weight-based delivery pricing model enables businesses and individuals to ship cargo from 1kg to 5,000kg with transparent per-kilogram rates.',
    tag: 'Product Launch',
  },
  {
    date: 'March 15, 2026',
    title: 'GetTranzport Expands to 180+ Countries with New Africa Hub in Lagos',
    summary: 'Strategic expansion into West Africa brings city-to-city and cross-border ride services to Nigeria, Ghana, and neighbouring markets.',
    tag: 'Expansion',
  },
  {
    date: 'February 8, 2026',
    title: '2-Nice Rideshare & Carpooling Transport Services Inc. Reports 300% YoY Growth',
    summary: 'Annual report shows 3x revenue growth driven by cross-border transfers and enterprise business travel contracts.',
    tag: 'Company News',
  },
  {
    date: 'January 12, 2026',
    title: 'GetTranzport Introduces Hourly Ride Booking for Corporate Clients',
    summary: 'New per-hour pricing model allows businesses to book drivers by the hour for meetings, events, and multi-stop itineraries.',
    tag: 'Product Launch',
  },
];

const MENTIONS = [
  { outlet: 'TechCrunch', quote: 'GetTranzport is redefining long-distance ground transportation with its driver-tender model.' },
  { outlet: 'Forbes', quote: 'A compelling alternative to traditional car services for intercity business travel.' },
  { outlet: 'Business Insider', quote: 'The cross-border transfer feature fills a massive gap in the ride-hailing market.' },
  { outlet: 'CNN Business', quote: 'One of the fastest-growing transport startups to watch in 2026.' },
];

const FACTS = [
  { label: 'Founded', value: '2022' },
  { label: 'Headquarters', value: 'Winnipeg, MB, Canada' },
  { label: 'Legal Entity', value: '2-Nice Rideshare & Carpooling Transport Services Inc.' },
  { label: 'Operating Countries', value: '180+' },
  { label: 'Active Drivers', value: '50,000+' },
  { label: 'Passengers Served', value: '5 Million+' },
  { label: 'Services', value: 'Ride/km, Ride/hr, Delivery/kg' },
  { label: 'Website', value: 'gettranzport.com' },
];

export default function PressPage() {
  return (
    <div className="min-h-screen flex flex-col bg-white" style={{ fontFamily: 'Inter, sans-serif' }}>
      <Navbar />

      {/* Hero */}
      <section className="pt-28 pb-14 bg-gray-900 text-center">
        <div className="max-w-2xl mx-auto px-6">
          <div className="w-14 h-14 flex items-center justify-center bg-emerald-500/20 rounded-2xl mx-auto mb-5">
            <i className="ri-newspaper-line text-emerald-400 text-2xl"></i>
          </div>
          <h1 className="text-4xl font-extrabold text-white mb-3" style={{ fontFamily: 'Syne, sans-serif' }}>
            Press & Media
          </h1>
          <p className="text-white/60 text-sm mb-6">
            News, press releases, and media resources for GetTranzport and 2-Nice Rideshare & Carpooling Transport Services Inc.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <a
              href="mailto:info@gettranzport.com"
              className="flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white font-semibold px-6 py-3 rounded-xl transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-mail-line"></i>
              Media Inquiries
            </a>
            <a
              href="tel:+14313342841"
              className="flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 text-white font-semibold px-6 py-3 rounded-xl transition-colors cursor-pointer whitespace-nowrap border border-white/20"
            >
              <i className="ri-phone-line"></i>
              +1 431-334-2841
            </a>
          </div>
        </div>
      </section>

      {/* Press Releases */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-6">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>Press Releases</h2>
            <p className="text-gray-500 text-sm">Latest news and announcements from GetTranzport.</p>
          </div>
          <div className="flex flex-col gap-4">
            {PRESS_RELEASES.map((pr) => (
              <div key={pr.title} className="bg-gray-50 border border-gray-100 rounded-2xl p-6 hover:border-emerald-200 transition-all duration-200">
                <div className="flex items-center gap-3 mb-3">
                  <span className="text-xs font-medium text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-lg">{pr.tag}</span>
                  <span className="text-xs text-gray-400">{pr.date}</span>
                </div>
                <h3 className="text-sm font-bold text-gray-900 mb-2">{pr.title}</h3>
                <p className="text-xs text-gray-500 leading-relaxed">{pr.summary}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Media Mentions */}
      <section className="py-16 bg-gray-50/60">
        <div className="max-w-5xl mx-auto px-6">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>In The News</h2>
            <p className="text-gray-500 text-sm">What the media is saying about GetTranzport.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {MENTIONS.map((m) => (
              <div key={m.outlet} className="bg-white border border-gray-100 rounded-2xl p-6 hover:border-emerald-200 transition-all duration-200">
                <div className="flex items-center gap-2 mb-3">
                  <i className="ri-double-quotes-l text-emerald-400 text-lg"></i>
                  <span className="text-xs font-bold text-gray-900 uppercase tracking-wider">{m.outlet}</span>
                </div>
                <p className="text-sm text-gray-600 leading-relaxed italic">"{m.quote}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Press Kit / Company Facts */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-6">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>Company Facts</h2>
            <p className="text-gray-500 text-sm">Quick-reference information for journalists and media partners.</p>
          </div>
          <div className="bg-gray-50 border border-gray-100 rounded-2xl p-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-5">
              {FACTS.map((f) => (
                <div key={f.label} className="flex justify-between items-baseline border-b border-gray-200 pb-3">
                  <span className="text-xs text-gray-400 font-medium">{f.label}</span>
                  <span className="text-sm font-semibold text-gray-900 text-right">{f.value}</span>
                </div>
              ))}
            </div>
            <div className="mt-8 pt-6 border-t border-gray-200">
              <h3 className="text-sm font-bold text-gray-900 mb-3">Media Contact</h3>
              <div className="flex flex-col sm:flex-row gap-4 text-sm">
                <a href="mailto:info@gettranzport.com" className="flex items-center gap-2 text-gray-600 hover:text-emerald-500 transition-colors">
                  <i className="ri-mail-line text-emerald-500"></i>
                  info@gettranzport.com
                </a>
                <a href="tel:+14313342841" className="flex items-center gap-2 text-gray-600 hover:text-emerald-500 transition-colors">
                  <i className="ri-phone-line text-emerald-500"></i>
                  +1 431-334-2841
                </a>
                <span className="flex items-center gap-2 text-gray-600">
                  <i className="ri-map-pin-line text-emerald-500"></i>
                  635 St. James Street, Winnipeg, MB R3G 3R4, Canada
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Brand Assets */}
      <section className="py-16 bg-gray-50/60">
        <div className="max-w-4xl mx-auto px-6">
          <div className="text-center mb-10">
            <h2 className="text-2xl font-bold text-gray-900 mb-2" style={{ fontFamily: 'Syne, sans-serif' }}>Brand Assets</h2>
            <p className="text-gray-500 text-sm">Official logos and brand guidelines for media use.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="bg-white border border-gray-100 rounded-2xl p-6 text-center">
              <div className="w-16 h-16 flex items-center justify-center bg-gray-50 rounded-xl mx-auto mb-4">
                <img
                  src="https://storage.readdy-site.link/project_files/2f77d222-cd48-4fcf-b09d-5b6904c3fbdd/57438424-a74c-47ae-9eda-4c633ac1fd05_GetTranzport-Official-logo.jpeg?v=54456dcff3e06ef19161c84429e27556"
                  alt="GetTranzport Logo"
                  className="h-10 w-auto object-contain"
                />
              </div>
              <h3 className="text-sm font-bold text-gray-900 mb-1">GetTranzport Logo</h3>
              <p className="text-xs text-gray-500 mb-3">Primary brand mark for digital and print use.</p>
              <span className="text-xs text-gray-400 bg-gray-50 px-3 py-1.5 rounded-lg">Available upon request</span>
            </div>
            <div className="bg-white border border-gray-100 rounded-2xl p-6 text-center">
              <div className="w-16 h-16 flex items-center justify-center bg-gray-50 rounded-xl mx-auto mb-4">
                <img
                  src="https://storage.readdy-site.link/project_files/2f77d222-cd48-4fcf-b09d-5b6904c3fbdd/3a98e49d-9b57-45a3-96ca-4e955260d506_2nice-Logo.jpg?v=08585cd6ed3ffd5ef7004483e839bded"
                  alt="2-Nice Logo"
                  className="h-10 w-auto object-contain"
                />
              </div>
              <h3 className="text-sm font-bold text-gray-900 mb-1">2-Nice Corporate Logo</h3>
              <p className="text-xs text-gray-500 mb-3">Parent company mark for legal and corporate communications.</p>
              <span className="text-xs text-gray-400 bg-gray-50 px-3 py-1.5 rounded-lg">Available upon request</span>
            </div>
          </div>
          <p className="text-center text-xs text-gray-400 mt-6">
            For high-resolution assets and brand guidelines, please contact{' '}
            <a href="mailto:info@gettranzport.com" className="text-emerald-500 hover:text-emerald-600 transition-colors">info@gettranzport.com</a>
          </p>
        </div>
      </section>

      <Footer />
    </div>
  );
}