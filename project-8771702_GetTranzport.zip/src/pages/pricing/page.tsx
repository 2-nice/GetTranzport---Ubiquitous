import { useState, useEffect } from 'react';
import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';
import supabase from '@/lib/supabaseClient';
import { FareRange } from '@/lib/fareUtils';
import FareEstimator from './components/FareEstimator';
import FareTable from './components/FareTable';

const STATS = [
  { icon: 'ri-global-line',      value: '240',   label: 'Countries Covered' },
  { icon: 'ri-car-line',         value: '10',    label: 'Vehicle Classes' },
  { icon: 'ri-money-dollar-circle-line', value: '2,400', label: 'Fare Data Points' },
  { icon: 'ri-refresh-line',     value: 'Live',  label: 'Real-Time Pricing' },
];

export default function PricingPage() {
  const [fareData, setFareData] = useState<FareRange[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    async function fetchFares() {
      setLoading(true);
      const { data, error: err } = await supabase
        .from('fare_ranges')
        .select('*')
        .order('country', { ascending: true });
      if (err) {
        setError('Failed to load fare data. Please try again.');
      } else {
        setFareData(data as FareRange[]);
      }
      setLoading(false);
    }
    fetchFares();
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-gray-50" style={{ fontFamily: 'Inter, sans-serif' }}>
      <Navbar />

      {/* Hero */}
      <section className="pt-32 pb-16 bg-gray-950 text-center px-6">
        <span className="text-emerald-400 text-xs font-bold tracking-widest uppercase">Transparent Pricing</span>
        <h1 className="text-4xl md:text-5xl font-extrabold text-white mt-3 mb-4" style={{ fontFamily: 'Syne, sans-serif' }}>
          Global Fare Ranges
        </h1>
        <p className="text-gray-400 text-base max-w-xl mx-auto mb-10">
          Real per-kilometer fare ranges for 240 countries across 10 vehicle classes. No hidden fees — just transparent, market-driven pricing.
        </p>

        {/* Stats */}
        <div className="flex flex-wrap justify-center gap-6 md:gap-12">
          {STATS.map((s) => (
            <div key={s.label} className="text-center">
              <div className="w-10 h-10 flex items-center justify-center bg-emerald-500/20 rounded-xl mx-auto mb-2">
                <i className={`${s.icon} text-emerald-400 text-lg`}></i>
              </div>
              <p className="text-2xl font-extrabold text-white">{s.value}</p>
              <p className="text-xs text-gray-400">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* How pricing works */}
      <section className="py-12 px-6 bg-white border-b border-gray-100">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-xl font-bold text-gray-900 mb-6 text-center" style={{ fontFamily: 'Syne, sans-serif' }}>
            How Our Pricing System Works
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                icon: 'ri-map-pin-2-line',
                title: 'Country-Specific Baselines',
                desc: 'Every country has its own minimum fare (L) per km, calibrated to local market conditions, cost of living, and fuel prices.',
              },
              {
                icon: 'ri-palette-line',
                title: 'Color-Band Fare System',
                desc: 'Drivers enter their fare and instantly see a color band — from Green (Excellent) to Red (Too High or Too Low) — based on a 0.90 USD range above the baseline.',
              },
              {
                icon: 'ri-auction-line',
                title: 'Tender-Based Competition',
                desc: 'Passengers post trips and drivers compete with offers. The color system encourages competitive, realistic pricing that benefits both sides.',
              },
            ].map((item) => (
              <div key={item.title} className="flex gap-4">
                <div className="w-10 h-10 flex items-center justify-center bg-emerald-50 rounded-xl flex-shrink-0 mt-0.5">
                  <i className={`${item.icon} text-emerald-600 text-lg`}></i>
                </div>
                <div>
                  <h3 className="font-bold text-gray-900 text-sm mb-1">{item.title}</h3>
                  <p className="text-gray-500 text-xs leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Main content */}
      <main className="flex-1 py-10 px-6">
        <div className="max-w-6xl mx-auto space-y-8">

          {loading ? (
            <div className="flex flex-col items-center justify-center py-24 gap-4">
              <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
              <p className="text-gray-500 text-sm">Loading fare data from 240 countries...</p>
            </div>
          ) : error ? (
            <div className="text-center py-16">
              <i className="ri-error-warning-line text-4xl text-red-400 mb-3 block"></i>
              <p className="text-red-500 text-sm">{error}</p>
            </div>
          ) : (
            <>
              {/* Fare Estimator */}
              <FareEstimator fareData={fareData} />

              {/* Color Band Guide */}
              <div className="bg-white rounded-2xl border border-gray-100 p-6">
                <h2 className="text-lg font-bold text-gray-900 mb-4" style={{ fontFamily: 'Syne, sans-serif' }}>
                  Driver Fare Color Guide
                </h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {[
                    { color: 'bg-red-500',     border: 'border-red-100',     bg: 'bg-red-50',     text: 'text-red-700',     label: 'Too Low',   range: 'Below minimum',  msg: 'Too low fare - enter a realistic fare' },
                    { color: 'bg-emerald-500', border: 'border-emerald-100', bg: 'bg-emerald-50', text: 'text-emerald-700', label: 'Excellent', range: '0% – 20%',       msg: 'Excellent fare - high chances' },
                    { color: 'bg-sky-500',     border: 'border-sky-100',     bg: 'bg-sky-50',     text: 'text-sky-700',     label: 'Good',      range: '20% – 40%',      msg: 'Good fare - medium chances' },
                    { color: 'bg-yellow-400',  border: 'border-yellow-100',  bg: 'bg-yellow-50',  text: 'text-yellow-700',  label: 'Fair',      range: '40% – 60%',      msg: 'Fair fare - moderate chances' },
                    { color: 'bg-orange-400',  border: 'border-orange-100',  bg: 'bg-orange-50',  text: 'text-orange-700',  label: 'High',      range: '60% – 80%',      msg: 'High fare - low chances' },
                    { color: 'bg-red-500',     border: 'border-red-100',     bg: 'bg-red-50',     text: 'text-red-700',     label: 'Very High', range: '80% – 100%',     msg: 'Very high fare - very low chances' },
                  ].map((b) => (
                    <div key={b.label} className={`rounded-xl border p-4 ${b.bg} ${b.border}`}>
                      <div className="flex items-center gap-2 mb-2">
                        <span className={`w-3 h-3 rounded-full flex-shrink-0 ${b.color}`}></span>
                        <span className={`text-sm font-bold ${b.text}`}>{b.label}</span>
                        <span className="text-xs text-gray-400 ml-auto">{b.range}</span>
                      </div>
                      <p className={`text-xs ${b.text} opacity-80`}>{b.msg}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-4 p-3 bg-gray-50 rounded-xl border border-gray-100">
                  <p className="text-xs text-gray-500 leading-relaxed">
                    <strong className="text-gray-700">Formula:</strong> Position = (Your Fare − Country Min) ÷ 0.90 &nbsp;|&nbsp;
                    Each country and vehicle class uses its own baseline (L). The full range spans L to L + $0.90/km.
                  </p>
                </div>
              </div>

              {/* Fare Table */}
              <FareTable fareData={fareData} />
            </>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
