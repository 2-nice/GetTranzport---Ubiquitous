import { useState, useEffect } from 'react';
import supabase from '@/lib/supabaseClient';
import {
  FareRange, VehicleClass, VEHICLE_CLASSES,
  getMinMax, getFareBand, BAND_STYLES,
} from '@/lib/fareUtils';

interface Props {
  fareData: FareRange[];
}

export default function FareEstimator({ fareData }: Props) {
  const [selectedCountry, setSelectedCountry] = useState('');
  const [selectedVehicle, setSelectedVehicle] = useState<VehicleClass>('economy');
  const [driverFare, setDriverFare] = useState('');
  const [countrySearch, setCountrySearch] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);

  const countries = fareData.map((r) => ({ country: r.country, continent: r.continent }))
    .sort((a, b) => a.country.localeCompare(b.country));

  const filtered = countries.filter((c) =>
    c.country.toLowerCase().includes(countrySearch.toLowerCase())
  );

  const selectedRow = fareData.find((r) => r.country === selectedCountry);
  const fareRange = selectedRow ? getMinMax(selectedRow, selectedVehicle) : null;

  const fareNum = parseFloat(driverFare);
  const band = fareRange && !isNaN(fareNum) && driverFare !== ''
    ? getFareBand(fareNum, fareRange.min)
    : null;
  const bandStyle = band ? BAND_STYLES[band.color] : null;

  const barWidth = band
    ? band.color === 'red-low'
      ? 0
      : Math.min(100, Math.round(band.position * 100))
    : 0;

  return (
    <div className="bg-white rounded-2xl border border-gray-100 p-6 md:p-8">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 flex items-center justify-center bg-emerald-50 rounded-xl">
          <i className="ri-calculator-line text-emerald-600 text-lg"></i>
        </div>
        <div>
          <h2 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'Syne, sans-serif' }}>
            Live Fare Estimator
          </h2>
          <p className="text-xs text-gray-500">Check fare ranges & driver pricing bands in real time</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {/* Country picker */}
        <div className="relative">
          <label className="block text-xs font-semibold text-gray-600 mb-1.5">Country</label>
          <div className="relative">
            <input
              type="text"
              placeholder="Search country..."
              value={countrySearch || selectedCountry}
              onChange={(e) => { setCountrySearch(e.target.value); setSelectedCountry(''); setShowDropdown(true); }}
              onFocus={() => setShowDropdown(true)}
              onBlur={() => setTimeout(() => setShowDropdown(false), 150)}
              className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition cursor-pointer"
            />
            <i className="ri-search-line absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm pointer-events-none"></i>
          </div>
          {showDropdown && filtered.length > 0 && (
            <div className="absolute z-20 top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-xl shadow-lg max-h-52 overflow-y-auto">
              {filtered.map((c) => (
                <button
                  key={c.country}
                  onMouseDown={() => {
                    setSelectedCountry(c.country);
                    setCountrySearch('');
                    setShowDropdown(false);
                  }}
                  className="w-full text-left px-4 py-2.5 text-sm text-gray-700 hover:bg-emerald-50 hover:text-emerald-700 transition-colors cursor-pointer flex items-center justify-between"
                >
                  <span>{c.country}</span>
                  <span className="text-[10px] text-gray-400">{c.continent}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Vehicle class */}
        <div>
          <label className="block text-xs font-semibold text-gray-600 mb-1.5">Vehicle Class</label>
          <select
            value={selectedVehicle}
            onChange={(e) => setSelectedVehicle(e.target.value as VehicleClass)}
            className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition cursor-pointer bg-white"
          >
            {VEHICLE_CLASSES.map((v) => (
              <option key={v.key} value={v.key}>{v.label} ({v.pax})</option>
            ))}
          </select>
        </div>

        {/* Driver fare input */}
        <div>
          <label className="block text-xs font-semibold text-gray-600 mb-1.5">Your Fare (USD/km)</label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 text-sm font-semibold">$</span>
            <input
              type="number"
              step="0.01"
              min="0"
              placeholder="e.g. 1.20"
              value={driverFare}
              onChange={(e) => setDriverFare(e.target.value)}
              className="w-full border border-gray-200 rounded-xl pl-8 pr-4 py-3 text-sm text-gray-800 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition"
            />
          </div>
        </div>
      </div>

      {/* Results */}
      {selectedRow && fareRange ? (
        <div className="space-y-4">
          {/* Fare range display */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-gray-50 rounded-xl p-4 text-center">
              <p className="text-[10px] text-gray-500 font-semibold uppercase tracking-wide mb-1">Min (Baseline)</p>
              <p className="text-xl font-bold text-gray-900">${fareRange.min.toFixed(2)}</p>
              <p className="text-[10px] text-gray-400">per km</p>
            </div>
            <div className="bg-emerald-50 rounded-xl p-4 text-center border border-emerald-100">
              <p className="text-[10px] text-emerald-600 font-semibold uppercase tracking-wide mb-1">Sweet Spot</p>
              <p className="text-xl font-bold text-emerald-700">
                ${(fareRange.min + 0.09).toFixed(2)}–${(fareRange.min + 0.27).toFixed(2)}
              </p>
              <p className="text-[10px] text-emerald-500">Excellent–Good zone</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-4 text-center">
              <p className="text-[10px] text-gray-500 font-semibold uppercase tracking-wide mb-1">Max</p>
              <p className="text-xl font-bold text-gray-900">${fareRange.max.toFixed(2)}</p>
              <p className="text-[10px] text-gray-400">per km</p>
            </div>
          </div>

          {/* Color band result */}
          {band && bandStyle && (
            <div className={`rounded-xl border p-4 ${bandStyle.bg} ${bandStyle.border}`}>
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className={`text-sm font-bold ${bandStyle.text}`}>{band.label}</p>
                  <p className={`text-xs ${bandStyle.text} opacity-80`}>{band.message}</p>
                </div>
                <div className={`text-2xl font-extrabold ${bandStyle.text}`}>
                  ${fareNum.toFixed(2)}
                </div>
              </div>
              {/* Progress bar */}
              <div className="h-2.5 bg-white/60 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${bandStyle.bar}`}
                  style={{ width: `${barWidth}%` }}
                ></div>
              </div>
              <div className="flex justify-between mt-1">
                <span className="text-[10px] text-gray-500">${fareRange.min.toFixed(2)} (min)</span>
                <span className="text-[10px] text-gray-500">${(fareRange.min + 0.90).toFixed(2)} (max)</span>
              </div>
            </div>
          )}

          {/* Color band legend */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {[
              { color: 'bg-red-500',     label: 'Too Low',   range: 'Below min' },
              { color: 'bg-emerald-500', label: 'Excellent', range: '0–20%' },
              { color: 'bg-sky-500',     label: 'Good',      range: '20–40%' },
              { color: 'bg-yellow-400',  label: 'Fair',      range: '40–60%' },
              { color: 'bg-orange-400',  label: 'High',      range: '60–80%' },
              { color: 'bg-red-500',     label: 'Very High', range: '80–100%' },
            ].map((b) => (
              <div key={b.label} className="flex items-center gap-2 text-xs text-gray-600">
                <span className={`w-3 h-3 rounded-full flex-shrink-0 ${b.color}`}></span>
                <span className="font-medium">{b.label}</span>
                <span className="text-gray-400">({b.range})</span>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="text-center py-8 text-gray-400">
          <i className="ri-map-pin-2-line text-3xl mb-2 block"></i>
          <p className="text-sm">Select a country and vehicle class to see fare ranges</p>
        </div>
      )}
    </div>
  );
}
