import { useState, useMemo } from 'react';
import { FareRange, VehicleClass, VEHICLE_CLASSES } from '@/lib/fareUtils';

interface Props {
  fareData: FareRange[];
}

const CONTINENTS = ['All', 'Africa', 'Asia', 'Europe', 'North America', 'Oceania', 'South America'];

export default function FareTable({ fareData }: Props) {
  const [search, setSearch] = useState('');
  const [continent, setContinent] = useState('All');
  const [activeVehicle, setActiveVehicle] = useState<VehicleClass>('economy');
  const [page, setPage] = useState(1);
  const PER_PAGE = 20;

  const filtered = useMemo(() => {
    return fareData.filter((r) => {
      const matchSearch = r.country.toLowerCase().includes(search.toLowerCase());
      const matchContinent = continent === 'All' || r.continent === continent;
      return matchSearch && matchContinent;
    }).sort((a, b) => a.country.localeCompare(b.country));
  }, [fareData, search, continent]);

  const totalPages = Math.ceil(filtered.length / PER_PAGE);
  const paginated = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);

  const handleSearch = (v: string) => { setSearch(v); setPage(1); };
  const handleContinent = (v: string) => { setContinent(v); setPage(1); };

  return (
    <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
      {/* Header */}
      <div className="p-6 border-b border-gray-100">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 flex items-center justify-center bg-emerald-50 rounded-xl">
            <i className="ri-table-line text-emerald-600 text-lg"></i>
          </div>
          <div>
            <h2 className="text-lg font-bold text-gray-900" style={{ fontFamily: 'Syne, sans-serif' }}>
              Global Fare Table
            </h2>
            <p className="text-xs text-gray-500">{fareData.length} countries · 10 vehicle classes · USD per km</p>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1">
            <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm pointer-events-none"></i>
            <input
              type="text"
              placeholder="Search country..."
              value={search}
              onChange={(e) => handleSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm text-gray-800 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 transition"
            />
          </div>
          <select
            value={continent}
            onChange={(e) => handleContinent(e.target.value)}
            className="border border-gray-200 rounded-xl px-4 py-2.5 text-sm text-gray-700 focus:outline-none focus:border-emerald-400 bg-white cursor-pointer"
          >
            {CONTINENTS.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>

        {/* Vehicle tabs */}
        <div className="flex flex-wrap gap-2 mt-3">
          {VEHICLE_CLASSES.map((v) => (
            <button
              key={v.key}
              onClick={() => setActiveVehicle(v.key)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
                activeVehicle === v.key
                  ? 'bg-emerald-500 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              <i className={`${v.icon} text-sm`}></i>
              {v.label}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-100">
              <th className="text-left px-6 py-3 text-xs font-bold text-gray-500 uppercase tracking-wide">Country</th>
              <th className="text-left px-4 py-3 text-xs font-bold text-gray-500 uppercase tracking-wide">Continent</th>
              <th className="text-right px-4 py-3 text-xs font-bold text-emerald-600 uppercase tracking-wide">Min ($/km)</th>
              <th className="text-right px-4 py-3 text-xs font-bold text-gray-500 uppercase tracking-wide">Max ($/km)</th>
              <th className="text-right px-6 py-3 text-xs font-bold text-gray-500 uppercase tracking-wide">Range</th>
            </tr>
          </thead>
          <tbody>
            {paginated.length === 0 ? (
              <tr>
                <td colSpan={5} className="text-center py-12 text-gray-400 text-sm">
                  No countries found matching your search.
                </td>
              </tr>
            ) : (
              paginated.map((row, i) => {
                const min = row[`${activeVehicle}_min`] as number;
                const max = row[`${activeVehicle}_max`] as number;
                const spread = max - min;
                return (
                  <tr key={row.id} className={`border-b border-gray-50 hover:bg-emerald-50/30 transition-colors ${i % 2 === 0 ? 'bg-white' : 'bg-gray-50/30'}`}>
                    <td className="px-6 py-3.5 font-semibold text-gray-800">{row.country}</td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">{row.continent}</span>
                    </td>
                    <td className="px-4 py-3.5 text-right">
                      <span className="font-bold text-emerald-600">${min.toFixed(2)}</span>
                    </td>
                    <td className="px-4 py-3.5 text-right text-gray-700 font-medium">${max.toFixed(2)}</td>
                    <td className="px-6 py-3.5 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <div className="w-20 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-emerald-400 rounded-full"
                            style={{ width: `${Math.min(100, (spread / 1.5) * 100)}%` }}
                          ></div>
                        </div>
                        <span className="text-xs text-gray-400">${spread.toFixed(2)}</span>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between px-6 py-4 border-t border-gray-100">
          <p className="text-xs text-gray-500">
            Showing {(page - 1) * PER_PAGE + 1}–{Math.min(page * PER_PAGE, filtered.length)} of {filtered.length} countries
          </p>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setPage(Math.max(1, page - 1))}
              disabled={page === 1}
              className="w-8 h-8 flex items-center justify-center rounded-lg border border-gray-200 text-gray-500 hover:border-emerald-400 hover:text-emerald-500 disabled:opacity-40 disabled:cursor-not-allowed transition cursor-pointer"
            >
              <i className="ri-arrow-left-s-line text-sm"></i>
            </button>
            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              const p = page <= 3 ? i + 1 : page - 2 + i;
              if (p < 1 || p > totalPages) return null;
              return (
                <button
                  key={p}
                  onClick={() => setPage(p)}
                  className={`w-8 h-8 flex items-center justify-center rounded-lg text-xs font-semibold transition cursor-pointer ${
                    p === page ? 'bg-emerald-500 text-white' : 'border border-gray-200 text-gray-600 hover:border-emerald-400 hover:text-emerald-500'
                  }`}
                >
                  {p}
                </button>
              );
            })}
            <button
              onClick={() => setPage(Math.min(totalPages, page + 1))}
              disabled={page === totalPages}
              className="w-8 h-8 flex items-center justify-center rounded-lg border border-gray-200 text-gray-500 hover:border-emerald-400 hover:text-emerald-500 disabled:opacity-40 disabled:cursor-not-allowed transition cursor-pointer"
            >
              <i className="ri-arrow-right-s-line text-sm"></i>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
