import Navbar from '@/components/feature/Navbar';
import Footer from '@/components/feature/Footer';
import { Link } from 'react-router-dom';

const STEPS = [
  {
    num: '01',
    icon: 'ri-map-pin-add-line',
    title: 'Enter Your Route',
    desc: 'Type your pickup location, destination, travel date, and number of passengers. Our smart search supports cities, airports, hotels, and exact addresses in 150+ countries.',
    detail: 'GetTranzport\'s AI instantly analyses your route — checking traffic patterns, border wait times (for cross-border trips), and available drivers in the area.',
  },
  {
    num: '02',
    icon: 'ri-auction-line',
    title: 'Receive Driver Offers',
    desc: 'Verified drivers in your area submit competitive bids for your trip. You see each driver\'s rating, vehicle class, photo, and price — all before committing.',
    detail: 'Our tender-based pricing means drivers compete for your booking. For ride bookings, prices are calculated per kilometer (base fare + distance rate). For hourly bookings, you pay a flat hourly rate. You\'re never locked into a single price — choose the best combination of value and quality.',
  },
  {
    num: '03',
    icon: 'ri-user-search-line',
    title: 'Choose Your Driver',
    desc: 'Compare offers side by side. Read verified reviews from past passengers on the same route. Select the driver and vehicle class that fits your needs and budget.',
    detail: 'Every driver profile shows their trip history, vehicle photos, languages spoken, and specialisations (airport transfers, cross-border, long-haul, etc.).',
  },
  {
    num: '04',
    icon: 'ri-bank-card-line',
    title: 'Book & Pay Securely',
    desc: 'Confirm your booking with secure payment. Your card is only charged after the driver accepts. Get instant confirmation with driver contact details.',
    detail: 'All payments are processed with 256-bit SSL encryption. We support credit/debit cards, PayPal, Apple Pay, Google Pay, and local payment methods in 80+ countries. Pricing is fully transparent — see the per-km or per-hour breakdown before you pay.',
  },
  {
    num: '05',
    icon: 'ri-map-pin-time-line',
    title: 'Track Your Ride Live',
    desc: 'On the day of travel, track your driver\'s live location on the map. Share a live trip link with family or colleagues — no app required for viewers.',
    detail: 'Our SafeGuard™ system monitors your trip in real time. Driver identity is verified at pickup via face-match photo. Panic button available throughout the journey.',
  },
  {
    num: '06',
    icon: 'ri-star-line',
    title: 'Arrive & Rate',
    desc: 'Arrive at your destination safely. Rate your driver and leave a review to help future passengers. Your feedback directly impacts driver rankings on the platform.',
    detail: 'Payments are released to the driver only after trip completion. If anything goes wrong, our 24/7 support team and dispute resolution process has you covered.',
  },
];

const SAFETY = [
  { icon: 'ri-shield-check-line',    title: 'Driver Screening',       desc: 'Criminal background checks, licence verification, and vehicle inspection for every driver.' },
  { icon: 'ri-fingerprint-line',     title: 'Identity Verification',  desc: 'Face-match photo verification at pickup. No match, no ride.' },
  { icon: 'ri-record-circle-line',   title: 'Trip Recording',         desc: 'GPS route logging and trip recording for every journey.' },
  { icon: 'ri-alarm-warning-line',   title: 'Panic Button',           desc: 'One-tap emergency alert with live location sharing to our response team.' },
  { icon: 'ri-customer-service-2-line', title: '24/7 Support',        desc: 'Round-the-clock support via chat, phone (+1 431-334-2841), and email in 20+ languages.' },
  { icon: 'ri-refund-2-line',        title: 'Money-Back Guarantee',   desc: 'Full refund if your driver cancels or doesn\'t show up.' },
];

export default function HowItWorksPage() {
  return (
    <div className="min-h-screen flex flex-col bg-white" style={{ fontFamily: 'Inter, sans-serif' }}>
      <Navbar />

      {/* Hero */}
      <section className="pt-32 pb-16 bg-gray-950 text-center px-6">
        <span className="text-emerald-400 text-xs font-bold tracking-widest uppercase">Simple Process</span>
        <h1 className="text-4xl md:text-5xl font-extrabold text-white mt-3 mb-4" style={{ fontFamily: 'Syne, sans-serif' }}>
          How GetTranzport Works
        </h1>
        <p className="text-gray-400 text-base max-w-xl mx-auto">
          From booking to arrival — a transparent, safe, and seamless long-distance ride experience in 6 simple steps.
        </p>
      </section>

      {/* Steps */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="flex flex-col gap-0">
            {STEPS.map((step, i) => (
              <div key={step.num} className="flex gap-6 md:gap-10">
                {/* Timeline */}
                <div className="flex flex-col items-center flex-shrink-0">
                  <div className="w-12 h-12 flex items-center justify-center rounded-2xl bg-emerald-500 text-white font-extrabold text-sm flex-shrink-0" style={{ fontFamily: 'Syne, sans-serif' }}>
                    {step.num}
                  </div>
                  {i < STEPS.length - 1 && <div className="w-px flex-1 bg-gray-100 my-2"></div>}
                </div>
                {/* Content */}
                <div className={`flex-1 ${i < STEPS.length - 1 ? 'pb-10' : 'pb-0'}`}>
                  <div className="flex items-center gap-2 mb-2">
                    <i className={`${step.icon} text-emerald-500 text-lg`}></i>
                    <h3 className="text-lg font-bold text-gray-900">{step.title}</h3>
                  </div>
                  <p className="text-gray-600 text-sm leading-relaxed mb-2">{step.desc}</p>
                  <p className="text-gray-400 text-xs leading-relaxed bg-gray-50 rounded-xl px-4 py-3 border border-gray-100">{step.detail}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Safety */}
      <section className="py-16 bg-gray-50/60 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <span className="text-rose-500 text-xs font-bold tracking-widest uppercase">SafeGuard™</span>
            <h2 className="text-3xl font-extrabold text-gray-900 mt-2 mb-3" style={{ fontFamily: 'Syne, sans-serif' }}>Built-In Safety at Every Step</h2>
            <p className="text-gray-500 text-sm max-w-lg mx-auto">Every GetTranzport ride is protected by our multi-layer SafeGuard™ system.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {SAFETY.map((s) => (
              <div key={s.title} className="bg-white rounded-2xl border border-gray-100 p-5 flex gap-4 hover:border-emerald-200 transition-colors">
                <div className="w-10 h-10 flex items-center justify-center rounded-xl bg-emerald-50 flex-shrink-0">
                  <i className={`${s.icon} text-emerald-500 text-lg`}></i>
                </div>
                <div>
                  <h3 className="text-sm font-bold text-gray-900 mb-1">{s.title}</h3>
                  <p className="text-xs text-gray-500 leading-relaxed">{s.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-emerald-500 text-center px-6">
        <h2 className="text-3xl font-extrabold text-white mb-3" style={{ fontFamily: 'Syne, sans-serif' }}>Ready to Book Your Ride?</h2>
        <p className="text-emerald-100 text-sm mb-6 max-w-md mx-auto">Join 5 million passengers who trust GetTranzport for their long-distance journeys.</p>
        <Link to="/" className="inline-flex items-center gap-2 bg-white text-emerald-700 hover:bg-emerald-50 font-bold text-sm px-6 py-3 rounded-xl transition-colors cursor-pointer whitespace-nowrap">
          Search Available Rides <i className="ri-arrow-right-line"></i>
        </Link>
      </section>

      <Footer />
    </div>
  );
}
