# Tranzport — Long-Distance Ride-Hire Platform

## 1. Project Description
Tranzport (gettranzport.com) is a worldwide long-distance passenger ride-hire marketplace. It connects passengers with professional drivers for city-to-city rides, across-state/province trips, airport pick-up & drop-off, and cross-border passenger transfers.

**Target Users:** Travellers needing reliable, pre-booked long-distance private transfers worldwide.
**Core Value:** Transparent pricing, vetted drivers, wide vehicle class selection, global coverage, AI-powered safety & tracking.

## 2. Page Structure
- `/` — Homepage
- `/services` — All service types
- `/how-it-works` — Process + safety features
- `/for-drivers` — Driver registration landing
- `/for-business` — Corporate travel landing
- `/for-agents` — Agent/reseller landing
- `/faq` — FAQ accordion
- `/destinations` — Popular routes
- `/support` — Support page
- `/careers` — Careers & jobs
- `/press` — Press & media
- `/contact` — Contact page
- `/blog` — Blog
- `/terms` — Terms of Service
- `/privacy` — Privacy Policy
- `*` — 404 Not Found

## 3. Core Features
- [x] Homepage with booking search form
- [x] Service type tabs
- [x] Vehicle class selector
- [x] Traveller reviews carousel
- [x] Stats bar
- [x] App download banner
- [x] Responsive navbar + footer
- [x] Live tracking innovation section
- [x] Safety & trust section
- [x] /services page
- [x] /how-it-works page
- [x] /for-drivers page
- [x] /for-business page
- [x] /for-agents page
- [x] /faq page
- [x] /destinations page
- [x] /support page
- [x] /contact page
- [x] /blog page
- [x] /careers page
- [x] /press page
- [x] /terms page
- [x] /privacy page
- [x] Floating WhatsApp button
- [ ] Booking flow / search results (Phase 3)
- [ ] User auth / dashboard (Phase 4)
- [ ] Fare ranges database (Phase 4 — IN PROGRESS)

## 4. Development Phase Plan

### Phase 1: Homepage & Core UI ✅
### Phase 2: Inner Pages & Innovation Features ✅
### Phase 3: Booking Flow (search results, vehicle selection, booking form)
### Phase 4: Backend Integration (Supabase) ← Current
- Supabase connected ✅
- Fare ranges database schema (IN PROGRESS — waiting for data)
- Fare ranges data import (PENDING)
- Frontend integration with fare data (PENDING)
